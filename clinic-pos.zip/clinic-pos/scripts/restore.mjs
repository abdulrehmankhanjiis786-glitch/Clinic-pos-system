// Restore from a backup file made by the app (Download backup) or by scripts/backup.mjs.
// Safe by default: without --apply it only shows what it WOULD write.
//
//   node scripts/restore.mjs backup.json            (preview)
//   node scripts/restore.mjs backup.json --apply    (writes; same-ID documents are overwritten)
//
// Needs: FIREBASE_SERVICE_ACCOUNT (service-account JSON text) in the environment.
// Run it yourself on a trusted computer. Never commit the key or the backup file.
import { readFileSync } from 'node:fs';
import { initializeApp, cert } from 'firebase-admin/app';
import { getFirestore, Timestamp, FieldValue } from 'firebase-admin/firestore';

const [file, flag] = process.argv.slice(2);
if (!file) { console.error('Usage: node scripts/restore.mjs <backup.json> [--apply]'); process.exit(1); }
const apply = flag === '--apply';
if (!process.env.FIREBASE_SERVICE_ACCOUNT) { console.error('FIREBASE_SERVICE_ACCOUNT is not set.'); process.exit(1); }
initializeApp({ credential: cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT)) });
const db = getFirestore();

const decode = (v) => {
  if (v && typeof v === 'object' && !Array.isArray(v)) {
    if (Object.keys(v).length === 1 && typeof v.__ts === 'string') return Timestamp.fromDate(new Date(v.__ts));
    return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, decode(x)]));
  }
  return Array.isArray(v) ? v.map(decode) : v;
};

const backup = JSON.parse(readFileSync(file, 'utf8'));
if (backup.app !== 'clinic-pos') { console.error('This is not a Clinic POS backup file.'); process.exit(1); }
let total = 0;
for (const [name, docs] of Object.entries(backup.collections)) {
  console.log(`${name}: ${docs.length} documents`);
  total += docs.length;
  if (!apply) continue;
  for (let i = 0; i < docs.length; i += 400) {
    const batch = db.batch();
    docs.slice(i, i + 400).forEach((d) => batch.set(db.collection(name).doc(d.id), decode(d.data)));
    await batch.commit();
  }
}
if (apply) {
  await db.collection('auditLogs').add({
    uid: 'restore-script', role: 'admin', action: 'backup.restore', entityType: 'system', entityId: 'restore',
    details: { file, documents: total }, createdAt: FieldValue.serverTimestamp(),
  });
  console.log(`Restored ${total} documents.`);
} else {
  console.log(`Preview only (${total} documents). Add --apply to write.`);
}
