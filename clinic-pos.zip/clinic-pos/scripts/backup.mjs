// Automatic backup (run by GitHub Actions). Saves every Firestore collection to backup.json
// and records the result in meta/backupStatus so the Admin and Developer screens can show it.
// Needs: FIREBASE_SERVICE_ACCOUNT (the whole service-account JSON, stored as a GitHub secret).
import { writeFileSync } from 'node:fs';
import { initializeApp, cert } from 'firebase-admin/app';
import { getFirestore, Timestamp, FieldValue } from 'firebase-admin/firestore';

const raw = process.env.FIREBASE_SERVICE_ACCOUNT;
if (!raw) { console.error('FIREBASE_SERVICE_ACCOUNT is not set.'); process.exit(1); }
initializeApp({ credential: cert(JSON.parse(raw)) });
const db = getFirestore();

const encode = (v) => {
  if (v instanceof Timestamp) return { __ts: v.toDate().toISOString() };
  if (Array.isArray(v)) return v.map(encode);
  if (v && typeof v === 'object') return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, encode(x)]));
  return v;
};

try {
  const out = { app: 'clinic-pos', format: 1, createdAt: new Date().toISOString(), collections: {} };
  const counts = {};
  for (const col of await db.listCollections()) {
    const snap = await col.get();
    out.collections[col.id] = snap.docs.map((d) => ({ id: d.id, data: encode(d.data()) }));
    counts[col.id] = snap.size;
  }
  writeFileSync('backup.json', JSON.stringify(out));
  await db.doc('meta/backupStatus').set(
    { autoAt: FieldValue.serverTimestamp(), autoStatus: 'ok', autoCounts: counts }, { merge: true });
  console.log('Backup complete:', JSON.stringify(counts));
} catch (e) {
  console.error('Backup failed:', e.message);
  try { await db.doc('meta/backupStatus').set({ autoAt: FieldValue.serverTimestamp(), autoStatus: 'FAILED' }, { merge: true }); } catch { /* ignore */ }
  process.exit(1);
}
