# Setup Guide (Chromebook, no installs, $0)

**[YOU]** = needs your own account or approval. Never share passwords, keys, codes or backup files with
anyone, including the AI. If any screen asks you to "Upgrade", "Blaze" or add a card, close it. You do not need it.

## Phase 1: Project and GitHub
1. github.com > **New repository**, name `clinic-pos`, **Private**.  [YOU]
2. Unzip the project (Files app > right-click > Extract all).
3. Easiest upload: on the repository page click **uploading an existing file** and drag in the files and folders.
   The folder `.github` is hidden; in the Files app press Ctrl+. to show hidden files, or add it later from
   Codespaces (Step 4 below). Commit.
4. Check that the repository has NO file named `.env`.
5. Open the editor in your browser: **Code > Codespaces > Create codespace**. Keep GitHub's spending limit at $0.
6. In the Codespace terminal:
```
npm install
cp .env.example .env
```
   Commit the new `package-lock.json` (Source Control icon > Commit > Sync).

## Phase 2: Firebase (stay on the free Spark plan)  [YOU]
1. Console > Project settings > General > **Your apps** > web icon `</>`. Register, skip Hosting setup, copy the
   config values into `.env`.
2. **Build > Authentication > Get started > Email/Password > Enable**.
3. **Build > Firestore Database > Create database > production mode**, nearby location (cannot be changed later).
4. Publish the security rules and the index:
```
npx firebase-tools login --no-localhost
npx firebase-tools use --add
npx firebase-tools deploy --only firestore
```
   The audit-log index can take a few minutes. Until it is ready, Audit Logs may show an error.

## Phase 3: First Admin and Developer, by hand  [YOU]
**Admin:** Console > Authentication > Users > **Add user**: email `yourname@clinicpos.local` (or your real email,
if you want Firebase's password-reset email), strong password. Copy the **User UID**.
Then Firestore Database > **Start collection** `users` > Document ID = the UID, fields:
`username` (string), `displayName` (string), `role` = `admin`, `recoveryEmail` (string), `disabled` = false (boolean).

**Developer (optional):** same steps with `role` = `developer`. Admins can never see or manage this account.

## Phase 4: Run, then publish
```
npm run dev          (try it; add the page hostname to Authentication > Settings > Authorized domains)
npm run build
npx firebase-tools deploy --only hosting
```
Your site: `https://YOUR-PROJECT-ID.web.app`. Update later by running the last two lines again.
Logs: the terminal shows build and deploy messages; Firebase console > Hosting shows release history.
Common fix: "auth/unauthorized-domain" means the site address is missing from Authorized domains.

## Phase 5: First-use setup in the app (Admin)
1. Settings: hospital details and currency label; add payment methods (tick **Physical cash** for cash);
   set each receptionist's discount limits and Cash Out permission.
2. Doctors and Services: add them (Fees changes prices; the price list is kept in step automatically).
3. Receptionists: create accounts (username 3-30 characters; letters, numbers, . - _ ; no spaces).

## Phase 6: App Check (optional, free)  [YOU]
1. console.cloud.google.com > Security > reCAPTCHA (or firebase console > App Check > Apps > register web app >
   reCAPTCHA v3) and copy the **site key**.
2. Put it in `.env` as `VITE_RECAPTCHA_SITE_KEY`, rebuild and redeploy.
3. In App Check, look at the "metrics" for a day; only then switch on **Enforce** for Firestore.
   (Enforcing too early locks everyone out; you can switch it off again.)

## Phase 7: Automatic backups (free, GitHub Actions)  [YOU]
Full steps are in `BACKUP_RESTORE.md`.

## Phase 8: Check everything
Follow `SECURITY_TESTING.md` line by line and note each result.
