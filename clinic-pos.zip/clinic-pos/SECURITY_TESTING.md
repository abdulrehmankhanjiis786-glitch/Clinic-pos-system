# Security and function tests (do these after deploying; write down each result)

Use two browsers or private windows (one Admin, one Receptionist). Keep notes: PASS / FAIL / what you saw.

## Roles
1. Receptionist cannot see Admin screens; Admin cannot see Receptionist billing screens.
2. Developer on the normal login form is rejected; Developer sign-in works only via Ctrl+Shift+Alt+D (click an empty
   spot first; it does nothing while typing in a box, or while signed in).
3. Admin > Receptionists lists only Admin and Receptionist accounts. No Developer name anywhere
   (Staff, Audit Logs, Dashboard, Security & Backup).
4. Developer dashboard shows "Hospital data blocked for Developer: Yes".
5. Disable a receptionist: they are signed out / cannot sign in again. Enable: they can.

## Billing
6. Without an open shift, New Bill, Cash and Balance payments say to open a shift.
7. Doctor selection loads the fee; changing the price in Fees updates the next bill.
8. Discount above limit: Post is refused until Admin approves in Discount Approvals; the approval can be used once.
9. Partial payment: outstanding is net minus received. Full payment: outstanding 0.
10. Double-click Post: only one bill is created. Receipt numbers rise by one.
11. Hold, then Resume under Held Bills: patient, doctor, services and discount come back. Held bills do not appear in
    Today's Slips or the shift report.
12. Reprint does not create a bill or payment (only an audit line "receipt.reprint").
13. Collect an outstanding balance: balance drops, payment receipt prints, shift report lists it. Paying more than
    the balance is refused.
14. Request cancellation (Today's Slips), approve it in Cancelled Slips with a cash refund: bill shows Cancelled,
    the refund appears in that till's shift report.
15. Cash Out is refused for a receptionist without permission or above the limit.
16. Close a shift: expected cash, counted cash, difference, signature lines; the report prints. Changes after closing
    are refused; Admin can reopen only with a reason (see audit log).

## Direct-access tests (security rules)
17. In the browser console (F12), as Receptionist, try to edit a posted bill's `net` with the Firestore SDK:
    it must be refused. Same for deleting a bill or an audit log entry, and for changing your own role.
18. As Receptionist, read `/users` of another user or `auditLogs`: refused.
19. Signed out, open the site and try to read any collection: refused.

## Backups
20. Download a manual backup; the file opens and the Admin screen shows the time.
21. Run the automatic backup once (Actions > Run workflow); then do one restore preview (BACKUP_RESTORE.md).

Anything that does not pass: send the exact message to the developer; do not go live until it is fixed.
