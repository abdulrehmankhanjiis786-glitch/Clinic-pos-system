# Clinic POS & Hospital Management System (free-plan edition)

Desktop-first web app for clinic billing. Plain JavaScript (Vite) + Firebase Authentication
and Cloud Firestore on the free **Spark** plan, hosted on Firebase Hosting.
No Cloud Functions, no Cloud Storage, no payment method.

## Status (all five phases written; nothing has been run or tested yet)

| Area | Written | Tested | Deployed |
|---|---|---|---|
| Login, hidden Developer login (Ctrl+Shift+Alt+D), idle sign-out | Yes | No | No |
| Developer isolation (rules + screens) | Yes | No | No |
| Admin: dashboard, receptionists, doctors, services, fees, settings, limits | Yes | No | No |
| New Bill, receipts (58/80 mm), Hold / Resume, Today's Slips, reprint | Yes | No | No |
| Discounts with limits and Admin approval | Yes | No | No |
| Outstanding balances and payment receipts | Yes | No | No |
| Cash In / Out, reversals, shifts, till reconciliation, closing report | Yes | No | No |
| Cancellation and refund workflow, Cancelled Slips | Yes | No | No |
| Audit log (add-only) | Yes | No | No |
| Keyboard shortcuts (Alt+N/D/S/C/P, Ctrl+Enter/S/F, Esc) | Yes | No | No |
| Developer dashboard: status, error log, configuration | Yes | No | No |
| Manual backup + daily automatic backup (GitHub Actions) + restore script | Yes | No | No |
| App Check | Hook ready, needs your key | No | No |

## Things the master specification asks for that cannot be done at $0

| Requirement | Why not | What the project does instead |
|---|---|---|
| Server-side validation (Cloud Functions) | Needs the Blaze plan | Firestore security rules re-check prices, totals, discounts, payments, shifts |
| Developer MFA | Needs a paid Firebase plan | Strong password, 15-minute idle sign-out, minimal Developer data access |
| Failed-login records | Needs unauthenticated writes (abuse risk) or a server | Firebase's own login throttling; successful logins are audited |
| Email OTP password recovery | Needs a server and an email sender | Admin can use Firebase's free reset email (real-email login); receptionist: Admin sets up a new login |
| Firebase scheduled exports | Needs billing | Daily GitHub Actions backup, encrypted, kept 30 days |
| Hospital email as OTP sender | No server | Not applicable |

## Other limits
- Bills may have up to 12 different service lines. Free daily quota: 50,000 reads / 20,000 writes.
- Receipt numbers are sequential through a counter; a tampered browser could skip numbers but not repeat one.
- A rejected cancellation request cannot be re-submitted for the same slip.
- Without a build/emulator run, expect a few small fixes on first deployment.

## Folder map
`src/` app, `firestore.rules` security rules, `scripts/` backup and restore, `.github/workflows/` daily backup,
`SETUP_GUIDE.md`, `BACKUP_RESTORE.md`, `SECURITY_TESTING.md`.
