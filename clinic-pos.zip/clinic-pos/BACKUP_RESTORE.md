# Backups and restore ($0)

Firebase's own scheduled exports need a paid plan, so this project uses two free methods.

## A. Manual backup (Admin)
Admin > **Security & Backup > Download backup now**. A `.json` file downloads to the Chromebook. It contains
patient and money data: keep it in a private place (for example a private Google Drive folder); never email it.
Do this at least once a week and before any big change. (Reads count toward the free daily quota.)

## B. Automatic daily backup (GitHub Actions)  [YOU]
1. Google Cloud console (console.cloud.google.com) > pick your Firebase project > **IAM & Admin > Service accounts**.
   Open `firebase-adminsdk-...` > **Keys > Add key > Create new key > JSON**. A file downloads.
   (If key creation is blocked by your Google account's policy, use method A only.)
2. GitHub repository > **Settings > Secrets and variables > Actions > New repository secret**:
   - `FIREBASE_SERVICE_ACCOUNT` = open the downloaded file and paste ALL of its text.
   - `BACKUP_PASSPHRASE` = a long passphrase you invent. Write it down somewhere safe; without it the backups cannot be opened.
3. Delete the downloaded key file from the Chromebook. Never commit it.
4. Repository > **Actions > Daily database backup > Run workflow** to test. A green tick means it worked, and the
   Admin screen "Last automatic backup" will show the time. If it fails GitHub emails you.
5. Each run keeps one encrypted file for 30 days (Actions run page > Artifacts).

Free limits: GitHub gives private repositories 2,000 Actions minutes per month (this uses about 1 minute a day), and
Firestore allows 50,000 reads per day (a backup reads every document once).

## Restore (practice it once before you need it!)
1. Download the artifact, unzip it, then decrypt (in Codespaces terminal):
```
openssl enc -d -aes-256-cbc -pbkdf2 -in backup.json.enc -out backup.json
```
   (it asks for the passphrase; for a manual backup skip this step).
2. Upload `backup.json` and your service-account key text into the Codespace environment only for this task:
```
npm install --no-save firebase-admin@12
export FIREBASE_SERVICE_ACCOUNT='PASTE THE JSON TEXT HERE'
node scripts/restore.mjs backup.json            # preview: shows counts only
node scripts/restore.mjs backup.json --apply    # writes; same-ID documents are overwritten
```
3. Delete `backup.json` and close the Codespace. The restore adds an entry to the Audit Log.

Restoring user *profiles* does not recreate sign-in passwords (those live in Firebase Authentication). If an
Authentication user was deleted, create it again by hand with the same UID is not possible; create a new account
and update the profile.

Status: written, not yet run. A backup is only trustworthy after you have completed one restore test.
