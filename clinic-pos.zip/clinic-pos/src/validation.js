// Username rules: 3-30 characters; letters, numbers, dot, dash, underscore; no spaces.
export const USERNAME_RE = /^[A-Za-z0-9._-]{3,30}$/;

// Returns '' when valid, otherwise a message. Checks the text exactly as typed.
export function checkUsername(raw) {
  const v = String(raw ?? '');
  if (/\s/.test(v)) return 'Username cannot contain spaces.';
  if (v.length < 3 || v.length > 30) return 'Username must be 3-30 characters.';
  if (!USERNAME_RE.test(v)) return 'Use only letters, numbers, dot (.), dash (-) and underscore (_).';
  return '';
}
