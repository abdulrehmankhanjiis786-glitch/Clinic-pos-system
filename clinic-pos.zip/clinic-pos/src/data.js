// Shared helpers for money, shifts and the shift ledger.
//
// Bill documents (written by the billing screen, Phase 3) must contain:
//   receiptNo, patientName, net, initialPaid, received, outstanding, isCash,
//   paymentMethodName, status ('posted' | 'cancelled'), shiftId,
//   receptionistUid, receptionistName, createdAt.
import { collection, doc, getDoc, getDocs, query, where } from 'firebase/firestore';
import { db } from './firebase.js';

export const round2 = (n) => Math.round((Number(n) + Number.EPSILON) * 100) / 100;

// Accepts "12", "12.5", "12.50". Returns a number or null when invalid.
export function parseAmount(v, allowZero = false) {
  const s = String(v ?? '').trim();
  if (!/^\d{1,9}(\.\d{1,2})?$/.test(s)) return null;
  const n = round2(Number(s));
  if (!allowZero && n <= 0) return null;
  return n;
}

let currency = '';
export const money = (n) => (currency ? currency + ' ' : '') + round2(n).toFixed(2);
export const shortId = (id) => String(id || '').slice(0, 6).toUpperCase();
export const payNo = (seq) => 'PAY-' + String(seq).padStart(6, '0');

export async function getHospital() {
  const s = await getDoc(doc(db, 'settings', 'hospital'));
  const h = s.exists() ? s.data() : { hospitalName: 'Hospital', address: '', phone: '', currency: '' };
  currency = h.currency || '';
  return h;
}

export async function list(coll, ...constraints) {
  const s = await getDocs(query(collection(db, coll), ...constraints));
  return s.docs.map((d) => ({ id: d.id, ...d.data() }));
}

// The receptionist's currently open shift, or null.
export async function getOpenShift(uid) {
  const p = await getDoc(doc(db, 'openShifts', uid));
  if (!p.exists()) return null;
  const s = await getDoc(doc(db, 'shifts', p.data().shiftId));
  return s.exists() ? { id: s.id, ...s.data() } : null;
}

// Everything that belongs to one shift's cash ledger.
export async function loadLedger(shift) {
  const [txs, bills, payments, refundBills] = await Promise.all([
    list('cashTransactions', where('shiftId', '==', shift.id), where('receptionistUid', '==', shift.receptionistUid)),
    list('bills', where('shiftId', '==', shift.id)),
    list('payments', where('shiftId', '==', shift.id)),
    list('bills', where('refundShiftId', '==', shift.id)),
  ]);
  const byTime = (a, b) => (a.createdAt?.seconds || 0) - (b.createdAt?.seconds || 0);
  return { txs: txs.sort(byTime), bills, payments: payments.sort(byTime), refundBills };
}

// Accounting formula (physical cash only):
// Expected = Opening + Cash sales + Cash balance payments + Cash In - Cash Out - Cash refunds
// Card / bank / wallet amounts are listed separately and never change expected cash.
export function computeTotals(shift, L) {
  const sum = (arr, f) => round2(arr.reduce((t, x) => t + (Number(f(x)) || 0), 0));
  const cashSales = sum(L.bills.filter((b) => b.isCash), (b) => b.initialPaid);
  const cashOutstanding = sum(L.payments.filter((p) => p.isCash), (p) => p.amount);
  const cashIn = sum(L.txs.filter((t) => t.type === 'in'), (t) => t.amount);
  const cashOut = sum(L.txs.filter((t) => t.type === 'out'), (t) => t.amount);
  const cashRefunds = sum(
    L.refundBills.filter((b) => b.status === 'cancelled' && b.refundIsCash && b.refundShiftId === shift.id),
    (b) => b.refundAmount,
  );
  const nonCash = {};
  L.bills.filter((b) => !b.isCash).forEach((b) => {
    const k = b.paymentMethodName || 'Other';
    nonCash[k] = round2((nonCash[k] || 0) + (Number(b.initialPaid) || 0));
  });
  L.payments.filter((p) => !p.isCash).forEach((p) => {
    const k = p.methodName || 'Other';
    nonCash[k] = round2((nonCash[k] || 0) + (Number(p.amount) || 0));
  });
  const expected = round2(Number(shift.openingCash) + cashSales + cashOutstanding + cashIn - cashOut - cashRefunds);
  return { cashSales, cashOutstanding, cashIn, cashOut, cashRefunds, nonCash, expected };
}
