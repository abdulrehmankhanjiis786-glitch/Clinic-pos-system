import { mountShell } from '../shell.js';
import { getOpenShift, list, money, round2 } from '../data.js';
import { where } from 'firebase/firestore';
import { balancesPage } from './balances.js';
import { cashRecepPage } from './cash.js';
import { currentShiftPage } from './shift.js';
import { newBillPage, heldPage } from './bill.js';
import { slipsPage } from './slips.js';
import { esc, setBaseShortcuts } from '../util.js';

export function renderReceptionist(root, name, uid) {
  const ctx = { uid, name, role: 'receptionist', pendingDraft: null, go: () => {} };
  const shell = mountShell(root, {
    brand: 'Clinic POS',
    roleLabel: 'Receptionist',
    name,
    nav: [
      { id: 'home', label: 'Dashboard' },
      { id: 'bill', label: 'New Bill' },
      { id: 'slips', label: "Today's Slips" },
      { id: 'held', label: 'Held Bills' },
      { id: 'outstanding', label: 'Outstanding Balances' },
      { id: 'cash', label: 'Cash In / Out' },
      { id: 'shift', label: 'Current Shift' },
    ],
    pages: {
      home: async (c) => {
        c.innerHTML = '<p class="muted">Loading…</p>';
        let shift = null, held = [], owing = [];
        try {
          shift = await getOpenShift(uid);
          [held, owing] = await Promise.all([list('heldBills', where('receptionistUid', '==', uid)), list('bills', where('outstanding', '>', 0))]);
        } catch { /* partial info is fine */ }
        const owed = round2(owing.filter((b) => b.status === 'posted').reduce((t, b) => t + b.outstanding, 0));
        const card = (n, l) => `<div class="card stat"><span class="num">${n}</span><span>${l}</span></div>`;
        c.innerHTML = `<div class="card"><h2>Welcome, ${esc(name)}</h2>
          <p>Shift: <strong>${shift ? `${esc(shift.shiftName)} — open` : 'not opened'}</strong></p></div>
          <div class="cards">${card(held.length, 'Held bills')}${card(owing.filter((b) => b.status === 'posted').length, 'Patients with a balance')}${card(money(owed), 'Total outstanding')}</div>`;
      },
      bill: (c) => newBillPage(c, ctx),
      slips: (c) => slipsPage(c, ctx),
      held: (c) => heldPage(c, ctx),
      outstanding: (c) => balancesPage(c, ctx),
      cash: (c) => cashRecepPage(c, ctx),
      shift: (c) => currentShiftPage(c, ctx),
    },
  });
  ctx.go = shell.go;
  setBaseShortcuts({ 'Alt+N': () => shell.go('bill'), 'Ctrl+F': () => shell.go('slips') });
}
