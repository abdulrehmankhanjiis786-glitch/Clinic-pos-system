// Phase 4: Cash In / Cash Out.
import { collection, doc, getDoc, writeBatch, serverTimestamp, orderBy, limit } from 'firebase/firestore';
import { db } from '../firebase.js';
import { auditData } from '../auth.js';
import { esc, $, fmtTime } from '../util.js';
import { getOpenShift, loadLedger, computeTotals, list, money, parseAmount, shortId } from '../data.js';

const errCard = '<div class="card error">Could not load data. Check your connection and try again.</div>';

// ---------- Receptionist ----------
export async function cashRecepPage(c, ctx) {
  c.innerHTML = '<p class="muted">Loading…</p>';
  let shift, limits = null;
  try {
    shift = await getOpenShift(ctx.uid);
    if (shift) { const s = await getDoc(doc(db, 'staffLimits', ctx.uid)); limits = s.exists() ? s.data() : null; }
  } catch { c.innerHTML = errCard; return; }
  if (!shift) {
    c.innerHTML = '<div class="card"><h2>Cash In / Out</h2><p class="muted">Open your shift first (Current Shift) before recording cash.</p></div>';
    return;
  }
  let L;
  try { L = await loadLedger(shift); } catch { c.innerHTML = errCard; return; }
  const t = computeTotals(shift, L);
  const canOut = Boolean(limits?.canCashOut);
  c.innerHTML = `
    <div class="card"><h2>Record cash</h2>
      <form id="f" class="grid2">
        <label>Type<select name="type"><option value="in">Cash In</option>
          <option value="out" ${canOut ? '' : 'disabled'}>Cash Out${canOut ? '' : ' (not permitted)'}</option></select></label>
        <label>Amount<input name="amount" required inputmode="decimal" autocomplete="off"></label>
        <label>Reason<input name="reason" required minlength="3" maxlength="200" autocomplete="off"></label>
        <label>Reference (optional)<input name="reference" maxlength="60" autocomplete="off"></label>
        <div class="row-end"><span id="msg" class="error"></span><button class="btn primary">Save</button></div>
      </form>
      <p class="muted">${canOut ? `Cash Out limit per entry: ${money(limits.cashOutLimit)}. ` : ''}Saved entries cannot be edited or deleted; ask the Admin to reverse a mistake.</p></div>
    <div class="card"><h2>This shift</h2>
      <p>Cash In total: <strong>${money(t.cashIn)}</strong> &nbsp; Cash Out total: <strong>${money(t.cashOut)}</strong></p>
      ${L.txs.length ? `<table><thead><tr><th>Time</th><th>Type</th><th class="right">Amount</th><th>Reason</th><th>Reference</th></tr></thead><tbody>
        ${[...L.txs].reverse().map((x) => `<tr><td>${esc(fmtTime(x.createdAt))}</td><td>${x.type === 'in' ? 'Cash In' : 'Cash Out'}</td>
          <td class="right">${money(x.amount)}</td><td>${esc(x.reason)}</td><td>${esc(x.reference)}</td></tr>`).join('')}</tbody></table>`
        : '<p class="muted">No cash entries yet.</p>'}</div>`;
  $('#f', c).onsubmit = async (e) => {
    e.preventDefault();
    const f = e.target;
    const msg = $('#msg', c);
    const amount = parseAmount(f.amount.value);
    const type = f.type.value;
    const reason = f.reason.value.trim();
    if (amount === null) { msg.textContent = 'Enter a valid amount greater than 0.'; return; }
    if (reason.length < 3) { msg.textContent = 'Enter a reason.'; return; }
    if (type === 'out' && (!canOut || amount > limits.cashOutLimit)) { msg.textContent = 'This Cash Out is above your permitted limit.'; return; }
    $('button', f).disabled = true;
    const ref = doc(collection(db, 'cashTransactions'));
    const batch = writeBatch(db);
    batch.set(ref, {
      type, amount, reason, reference: f.reference.value.trim(), shiftId: shift.id,
      receptionistUid: ctx.uid, receptionistName: ctx.name, createdAt: serverTimestamp(),
    });
    batch.set(doc(collection(db, 'auditLogs')),
      auditData(ctx.uid, 'receptionist', type === 'in' ? 'cash.in' : 'cash.out', 'cashTransaction', ref.id, { amount, shiftId: shift.id }));
    try { await batch.commit(); cashRecepPage(c, ctx); }
    catch { msg.textContent = 'Could not save. Your shift may have been closed.'; $('button', f).disabled = false; }
  };
}

// ---------- Admin: review and reverse ----------
export async function cashAdminPage(c, ctx) {
  c.innerHTML = '<p class="muted">Loading…</p>';
  let txs, open;
  try {
    [txs, open] = await Promise.all([list('cashTransactions', orderBy('createdAt', 'desc'), limit(150)), list('openShifts')]);
  } catch { c.innerHTML = errCard; return; }
  const openShiftIds = new Set(open.map((o) => o.shiftId));
  const reversed = new Set(txs.filter((x) => x.reversalOf).map((x) => x.reversalOf));
  c.innerHTML = `<div class="card"><div class="row-gap" style="justify-content:space-between;margin-bottom:8px">
      <h2 style="margin:0">Cash transactions (latest 150)</h2>
      <input id="q" class="search" placeholder="Search receptionist, reason, reference"></div>
      <div id="out"></div><div id="rmsg" class="error"></div></div>`;
  const render = () => {
    const q = $('#q', c).value.trim().toLowerCase();
    const rows = txs.filter((x) => !q || [x.receptionistName, x.reason, x.reference].some((v) => String(v || '').toLowerCase().includes(q)));
    $('#out', c).innerHTML = rows.length
      ? `<table><thead><tr><th>Time</th><th>Receptionist</th><th>Type</th><th class="right">Amount</th><th>Reason</th><th>Reference</th><th>Shift</th><th></th></tr></thead><tbody>
        ${rows.map((x) => {
          const status = x.reversalOf ? '<span class="pill warn">Reversal</span>' : reversed.has(x.id) ? '<span class="pill off">Reversed</span>' : '';
          const canRev = !x.reversalOf && !reversed.has(x.id) && openShiftIds.has(x.shiftId);
          return `<tr><td>${esc(fmtTime(x.createdAt))}</td><td>${esc(x.receptionistName)}</td><td>${x.type === 'in' ? 'Cash In' : 'Cash Out'}</td>
            <td class="right">${money(x.amount)}</td><td>${esc(x.reason)}</td><td>${esc(x.reference)}</td><td>${esc(shortId(x.shiftId))}</td>
            <td>${status}${canRev ? `<button class="btn small" data-rev="${esc(x.id)}">Reverse</button>` : ''}</td></tr>`;
        }).join('')}</tbody></table>`
      : '<p class="muted">No cash transactions found.</p>';
    c.querySelectorAll('button[data-rev]').forEach((b) => {
      b.onclick = async () => {
        const x = txs.find((t) => t.id === b.dataset.rev);
        const why = (prompt('Reason for reversing this entry (at least 5 characters):') || '').trim();
        if (why.length < 5) return;
        const batch = writeBatch(db);
        batch.set(doc(db, 'cashTransactions', 'rev_' + x.id), {
          type: x.type === 'in' ? 'out' : 'in', amount: x.amount, reason: why.slice(0, 200), reference: ('Reversal of ' + x.id).slice(0, 60),
          shiftId: x.shiftId, receptionistUid: x.receptionistUid, receptionistName: x.receptionistName,
          createdAt: serverTimestamp(), reversalOf: x.id, createdBy: ctx.uid,
        });
        batch.set(doc(collection(db, 'auditLogs')), auditData(ctx.uid, 'admin', 'cash.reverse', 'cashTransaction', x.id, { reason: why, amount: x.amount }));
        try { await batch.commit(); cashAdminPage(c, ctx); }
        catch { $('#rmsg', c).textContent = 'Could not reverse. Reversals are only allowed while the shift is open.'; }
      };
    });
  };
  $('#q', c).oninput = render;
  render();
}
