// Admin: discount approvals (requests from receptionists whose discount is above their limit).
import { collection, doc, writeBatch, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase.js';
import { auditData } from '../auth.js';
import { esc, fmtTime } from '../util.js';
import { list, money } from '../data.js';

export async function approvalsPage(c, ctx) {
  c.innerHTML = '<p class="muted">Loading…</p>';
  let rows;
  try { rows = await list('discountApprovals'); }
  catch { c.innerHTML = '<div class="card error">Could not load data.</div>'; return; }
  rows.sort((a, b) => (b.requestedAt?.seconds || 0) - (a.requestedAt?.seconds || 0));
  const pending = rows.filter((r) => r.status === 'pending');
  const rest = rows.filter((r) => r.status !== 'pending').slice(0, 50);
  c.innerHTML = `<div class="card"><h2>Waiting for approval</h2>${pending.length
    ? `<table><thead><tr><th>Requested</th><th>Receptionist</th><th>Patient</th><th class="right">Gross</th><th class="right">Discount</th><th>Reason</th><th></th></tr></thead><tbody>
      ${pending.map((r) => `<tr><td>${esc(fmtTime(r.requestedAt))}</td><td>${esc(r.receptionistName)}</td><td>${esc(r.patientName)}</td>
        <td class="right">${money(r.grossTotal)}</td><td class="right">${money(r.discountAmount)}</td><td>${esc(r.reason)}</td>
        <td class="row-gap"><button class="btn small primary" data-a="${esc(r.id)}">Approve</button><button class="btn small" data-r="${esc(r.id)}">Reject</button></td></tr>`).join('')}</tbody></table><div id="m" class="error"></div>`
    : '<p class="muted">No requests waiting.</p>'}</div>
    <div class="card"><h2>History (latest 50)</h2>${rest.length
      ? `<table><thead><tr><th>Requested</th><th>Receptionist</th><th>Patient</th><th class="right">Discount</th><th>Result</th><th>Decided by</th></tr></thead><tbody>
        ${rest.map((r) => `<tr><td>${esc(fmtTime(r.requestedAt))}</td><td>${esc(r.receptionistName)}</td><td>${esc(r.patientName)}</td><td class="right">${money(r.discountAmount)}</td>
          <td><span class="pill ${r.status === 'rejected' ? 'off' : r.status === 'used' ? 'on' : 'warn'}">${esc(r.status)}</span></td><td>${esc(r.decidedByName)}</td></tr>`).join('')}</tbody></table>`
      : '<p class="muted">Nothing yet.</p>'}</div>`;
  const decide = async (id, status) => {
    const batch = writeBatch(db);
    batch.update(doc(db, 'discountApprovals', id), { status, decidedBy: ctx.uid, decidedByName: ctx.name, decidedAt: serverTimestamp() });
    batch.set(doc(collection(db, 'auditLogs')), auditData(ctx.uid, 'admin', `discount.${status}`, 'discountApproval', id));
    try { await batch.commit(); approvalsPage(c, ctx); }
    catch { const m = c.querySelector('#m'); if (m) m.textContent = 'Could not save. Try again.'; }
  };
  c.querySelectorAll('[data-a]').forEach((b) => (b.onclick = () => decide(b.dataset.a, 'approved')));
  c.querySelectorAll('[data-r]').forEach((b) => (b.onclick = () => decide(b.dataset.r, 'rejected')));
}
