// Phase 3: Today's Slips (Receptionist: current shift; Admin: everything billed today).
import { Timestamp, where, orderBy } from 'firebase/firestore';
import { auth } from '../firebase.js';
import { writeAudit } from '../auth.js';
import { esc, $, fmtTime, setPageShortcuts } from '../util.js';
import { list, getOpenShift, getHospital, money } from '../data.js';
import { billStatus, statusClass, printBillReceipt } from './receipt.js';
import { requestCancellation } from './cancellations.js';

const errCard = '<div class="card error">Could not load data. Check your connection and try again.</div>';

export async function slipsPage(c, ctx) {
  const isRecep = ctx.role === 'receptionist';
  c.innerHTML = '<p class="muted">Loading…</p>';
  let bills = [], requested = new Set(), shift = null, hospital;
  try {
    hospital = await getHospital();
    if (isRecep) {
      shift = await getOpenShift(ctx.uid);
      if (shift) bills = await list('bills', where('shiftId', '==', shift.id));
      const mine = await list('cancellationRequests', where('requestedBy', '==', ctx.uid));
      requested = new Set(mine.filter((r) => r.status !== 'rejected').map((r) => r.id));
    } else {
      const start = Timestamp.fromDate(new Date(new Date().setHours(0, 0, 0, 0)));
      bills = await list('bills', where('createdAt', '>=', start), orderBy('createdAt', 'desc'));
    }
  } catch { c.innerHTML = errCard; return; }
  bills.sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));

  c.innerHTML = `<div class="card">
    <div class="row-gap" style="justify-content:space-between;margin-bottom:8px">
      <h2 style="margin:0">${isRecep ? 'Slips of your current shift' : "Today's slips (all receptionists)"}</h2>
      <input id="q" class="search" placeholder="Receipt no. or patient name (Ctrl+F)"></div>
    ${isRecep && !shift ? '<p class="muted">You have no open shift. You can still look up a receipt by its number below.</p>' : ''}
    <div id="out"></div><div id="find" class="row-gap" style="margin-top:8px"></div></div><div id="panel"></div>`;

  let shown = bills;
  const draw = () => {
    const q = $('#q', c).value.trim().toLowerCase();
    shown = bills.filter((b) => !q || [b.receiptNo, b.patientName].some((v) => String(v || '').toLowerCase().includes(q)));
    $('#out', c).innerHTML = shown.length
      ? `<table><thead><tr><th>Receipt</th><th>Time</th><th>Patient</th><th class="right">Net</th><th class="right">Received</th><th class="right">Outstanding</th><th>Status</th><th></th></tr></thead><tbody>
        ${shown.map((b) => `<tr><td>${esc(b.receiptNo)}</td><td>${esc(fmtTime(b.createdAt))}</td><td>${esc(b.patientName)}</td>
          <td class="right">${money(b.net)}</td><td class="right">${money(b.received)}</td><td class="right">${money(b.outstanding)}</td>
          <td><span class="pill ${statusClass(b)}">${billStatus(b)}</span></td>
          <td><button class="btn small" data-id="${esc(b.id)}">Open</button></td></tr>`).join('')}</tbody></table>`
      : '<p class="muted">No slips found.</p>';
    c.querySelectorAll('button[data-id]').forEach((b) => (b.onclick = () => openBill(bills.find((x) => x.id === b.dataset.id))));
    // Exact lookup of an older receipt (authorized staff only).
    const f = $('#find', c);
    f.innerHTML = '';
    if (q && !shown.length && /^r-\d+$/i.test(q)) {
      f.innerHTML = '<button class="btn small" id="lk">Look up this receipt number</button><span id="lm" class="error"></span>';
      $('#lk', c).onclick = async () => {
        try {
          const r = await list('bills', where('receiptNo', '==', q.toUpperCase()));
          if (!r.length) { $('#lm', c).textContent = 'No such receipt.'; return; }
          bills = [...bills, ...r.filter((x) => !bills.some((y) => y.id === x.id))];
          draw();
        } catch { $('#lm', c).textContent = 'Could not look it up.'; }
      };
    }
  };

  async function openBill(b) {
    const panel = $('#panel', c);
    panel.innerHTML = '<div class="card muted">Loading…</div>';
    let pays = [];
    try { pays = (await list('payments', where('billId', '==', b.id))).sort((x, y) => (x.createdAt?.seconds || 0) - (y.createdAt?.seconds || 0)); }
    catch { /* history shown empty */ }
    const canCancel = isRecep && b.status === 'posted' && !requested.has(b.id);
    panel.innerHTML = `<div class="card"><h2>${esc(b.receiptNo)} <span class="pill ${statusClass(b)}">${billStatus(b)}</span></h2>
      <p>${esc(b.patientName)}, ${esc(b.age)} / ${esc(b.gender)} · Doctor: ${esc(b.doctorName || '-')} · ${esc(fmtTime(b.createdAt))} · by ${esc(b.receptionistName)}</p>
      <table><thead><tr><th>Item</th><th class="right">Price</th><th class="right">Qty</th><th class="right">Total</th></tr></thead><tbody>
        ${b.doctorId ? `<tr><td>Consultation: ${esc(b.doctorName)}</td><td class="right">${money(b.doctorFee)}</td><td class="right">1</td><td class="right">${money(b.doctorFee)}</td></tr>` : ''}
        ${(b.items || []).map((i) => `<tr><td>${esc(i.name)}</td><td class="right">${money(i.price)}</td><td class="right">${i.qty}</td><td class="right">${money(i.lineTotal)}</td></tr>`).join('')}
      </tbody></table>
      <table class="tot"><tbody><tr><td>Gross</td><td class="right">${money(b.gross)}</td></tr><tr><td>Discount</td><td class="right">${money(b.discount)}</td></tr>
        <tr class="big"><td>Net</td><td class="right">${money(b.net)}</td></tr><tr><td>Received</td><td class="right">${money(b.received)} (${esc(b.paymentMethodName)} at billing${pays.length ? `, ${pays.length} later payment(s)` : ''})</td></tr>
        <tr><td>Outstanding</td><td class="right">${money(b.outstanding)}</td></tr></tbody></table>
      ${b.status === 'cancelled' ? `<p class="error">Cancelled ${esc(fmtTime(b.cancelledAt))} by ${esc(b.cancelledByName)}. Reason: ${esc(b.cancelReason)}</p>` : ''}
      <div class="row-gap"><button class="btn primary" id="p80">Reprint 80 mm</button><button class="btn" id="p58">Reprint 58 mm</button>
        ${canCancel ? '<button class="btn" id="cx">Request cancellation</button>' : requested.has(b.id) ? '<span class="pill warn">Cancellation requested</span>' : ''}
        <span id="pm" class="muted"></span></div></div>`;
    const reprint = (w) => {
      printBillReceipt(hospital, b, w);
      writeAudit(auth.currentUser.uid, ctx.role, 'receipt.reprint', 'bill', b.id, { receiptNo: b.receiptNo }).catch(() => {});
    };
    $('#p80', panel).onclick = () => reprint('80');
    $('#p58', panel).onclick = () => reprint('58');
    const cx = $('#cx', panel);
    if (cx) {
      cx.onclick = async () => {
        const why = (prompt('Reason for cancelling this slip (at least 5 characters):') || '').trim();
        if (why.length < 5) return;
        try { await requestCancellation(b, why, ctx); requested.add(b.id); $('#pm', panel).textContent = 'Request sent to the Admin.'; cx.disabled = true; }
        catch { $('#pm', panel).className = 'error'; $('#pm', panel).textContent = 'Could not send the request.'; }
      };
    }
  }

  $('#q', c).oninput = draw;
  setPageShortcuts({ 'Ctrl+F': () => $('#q', c).focus() });
  draw();
}
