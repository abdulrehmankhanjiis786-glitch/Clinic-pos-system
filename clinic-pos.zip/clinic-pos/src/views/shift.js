// Phase 4: shifts, till reconciliation and the shift closing report.
import { collection, doc, getDoc, writeBatch, serverTimestamp, orderBy, limit } from 'firebase/firestore';
import { db } from '../firebase.js';
import { auditData } from '../auth.js';
import { esc, $, fmtTime, printHtml } from '../util.js';
import { getOpenShift, loadLedger, computeTotals, getHospital, list, money, parseAmount, round2, shortId } from '../data.js';

const errCard = '<div class="card error">Could not load data. Check your connection and try again.</div>';
const SHIFT_NAMES = ['Morning', 'Evening', 'Night'];

function summaryTable(shift, t) {
  const row = (label, v, strong) => `<tr${strong ? ' style="font-weight:700"' : ''}><td>${label}</td><td class="right">${money(v)}</td></tr>`;
  const nc = Object.entries(t.nonCash);
  return `<table><tbody>
    ${row('Opening cash', shift.openingCash)}
    ${row('+ Cash sales received', t.cashSales)}
    ${row('+ Cash outstanding payments received', t.cashOutstanding)}
    ${row('+ Cash In', t.cashIn)}
    ${row('− Cash Out', t.cashOut)}
    ${row('− Cash refunds / reversals', t.cashRefunds)}
    ${row('= Expected cash', t.expected, true)}
  </tbody></table>
  ${nc.length ? `<h3 class="sec-title">Not in the cash drawer (card / bank / wallet)</h3><table><tbody>
    ${nc.map(([k, v]) => `<tr><td>${esc(k)}</td><td class="right">${money(v)}</td></tr>`).join('')}</tbody></table>` : ''}`;
}

// ---------- Receptionist: current shift ----------
export async function currentShiftPage(c, ctx) {
  c.innerHTML = '<p class="muted">Loading…</p>';
  let shift;
  try { shift = await getOpenShift(ctx.uid); } catch { c.innerHTML = errCard; return; }
  if (!shift) { openForm(c, ctx); return; }
  let L;
  try { L = await loadLedger(shift); } catch { c.innerHTML = errCard; return; }
  const t = computeTotals(shift, L);
  c.innerHTML = `
    <div class="card"><h2>${esc(shift.shiftName)} shift — open</h2>
      <p class="muted">Opened ${esc(fmtTime(shift.openedAt))}</p>${summaryTable(shift, t)}</div>
    <div class="card"><h2>Close shift</h2>
      <p class="muted">Count the cash in your drawer and enter the total. After closing, this shift cannot be changed.</p>
      <form id="f" class="grid2">
        <label>Counted cash<input name="counted" required inputmode="decimal" autocomplete="off"></label>
        <label>Notes (optional)<input name="notes" maxlength="300" autocomplete="off"></label>
        <div class="row-end"><span id="msg" class="error"></span><button class="btn primary">Close shift</button></div>
      </form></div>`;
  $('#f', c).onsubmit = async (e) => {
    e.preventDefault();
    const f = e.target;
    const msg = $('#msg', c);
    const counted = parseAmount(f.counted.value, true);
    if (counted === null) { msg.textContent = 'Enter the counted cash, for example 12500 or 12500.50.'; return; }
    if (!confirm('Close this shift? You will not be able to change it afterwards.')) return;
    $('button', f).disabled = true;
    try {
      const fresh = await loadLedger(shift);
      const t2 = computeTotals(shift, fresh);
      const diff = round2(counted - t2.expected);
      const batch = writeBatch(db);
      batch.update(doc(db, 'shifts', shift.id), {
        status: 'closed', closedAt: serverTimestamp(), countedCash: counted, expectedCash: t2.expected,
        difference: diff, closeNotes: f.notes.value.trim(), totals: t2,
      });
      batch.delete(doc(db, 'openShifts', ctx.uid));
      batch.set(doc(collection(db, 'auditLogs')),
        auditData(ctx.uid, 'receptionist', 'shift.close', 'shift', shift.id, { expected: t2.expected, counted, difference: diff }));
      await batch.commit();
      const closed = await getDoc(doc(db, 'shifts', shift.id));
      c.innerHTML = '';
      await shiftReport(c, { id: closed.id, ...closed.data() });
    } catch {
      msg.textContent = 'Could not close the shift. Try again.';
      $('button', f).disabled = false;
    }
  };
}

function openForm(c, ctx) {
  c.innerHTML = `<div class="card"><h2>Open your shift</h2>
    <p class="muted">You have no open shift. Count the cash in your drawer and enter it as the opening cash.</p>
    <form id="f" class="grid2">
      <label>Shift<select name="shiftName">${SHIFT_NAMES.map((n) => `<option>${n}</option>`).join('')}</select></label>
      <label>Opening cash<input name="cash" required inputmode="decimal" autocomplete="off"></label>
      <div class="row-end"><span id="msg" class="error"></span><button class="btn primary">Open shift</button></div>
    </form></div>`;
  $('#f', c).onsubmit = async (e) => {
    e.preventDefault();
    const f = e.target;
    const msg = $('#msg', c);
    const cash = parseAmount(f.cash.value, true);
    if (cash === null) { msg.textContent = 'Enter the opening cash, for example 5000 or 0.'; return; }
    $('button', f).disabled = true;
    const ref = doc(collection(db, 'shifts'));
    const batch = writeBatch(db);
    batch.set(ref, {
      receptionistUid: ctx.uid, receptionistName: ctx.name, shiftName: f.shiftName.value,
      openingCash: cash, status: 'open', openedAt: serverTimestamp(),
    });
    batch.set(doc(db, 'openShifts', ctx.uid), { shiftId: ref.id, openedAt: serverTimestamp() });
    batch.set(doc(collection(db, 'auditLogs')),
      auditData(ctx.uid, 'receptionist', 'shift.open', 'shift', ref.id, { shiftName: f.shiftName.value, openingCash: cash }));
    try { await batch.commit(); currentShiftPage(c, ctx); }
    catch { msg.textContent = 'Could not open the shift. You may already have one open.'; $('button', f).disabled = false; }
  };
}

// ---------- The shift closing report (used by Receptionist and Admin) ----------
export async function shiftReport(c, shift) {
  const box = document.createElement('div');
  box.innerHTML = '<p class="muted">Loading report…</p>';
  c.appendChild(box);
  let L, hospital;
  try { [L, hospital] = await Promise.all([loadLedger(shift), getHospital()]); }
  catch { box.innerHTML = errCard; return; }
  const t = computeTotals(shift, L);
  const closed = shift.status === 'closed';
  const diff = closed ? round2(shift.countedCash - t.expected) : null;
  const diffLabel = diff === null ? '' : diff > 0 ? 'Excess' : diff < 0 ? 'Short' : 'Balanced';
  const changed = closed && Math.abs(round2(shift.expectedCash) - t.expected) > 0.004;
  const cancelled = L.bills.filter((b) => b.status === 'cancelled');
  const ins = L.txs.filter((x) => x.type === 'in');
  const outs = L.txs.filter((x) => x.type === 'out');
  const txTable = (arr) => arr.length
    ? `<table><thead><tr><th>Time</th><th class="right">Amount</th><th>Reason</th><th>Reference</th></tr></thead><tbody>${arr.map((x) =>
      `<tr><td>${esc(fmtTime(x.createdAt))}</td><td class="right">${money(x.amount)}</td><td>${esc(x.reason)}</td><td>${esc(x.reference)}</td></tr>`).join('')}</tbody></table>`
    : '<p class="muted">None.</p>';

  box.className = 'card report';
  box.innerHTML = `
    <div class="no-print row-gap" style="justify-content:flex-end;margin-bottom:8px"><button class="btn" id="pr">Print report</button></div>
    <div id="rp">
    <h2>${esc(hospital.hospitalName)}</h2>
    <div class="sub">Shift closing report</div>
    <table><tbody>
      <tr><td>Report date and time</td><td>${esc(new Date().toLocaleString())}</td></tr>
      <tr><td>Receptionist</td><td>${esc(shift.receptionistName)}</td></tr>
      <tr><td>Shift</td><td>${esc(shift.shiftName)} (ID ${esc(shortId(shift.id))})</td></tr>
      <tr><td>Opened</td><td>${esc(fmtTime(shift.openedAt))}</td></tr>
      <tr><td>Closed</td><td>${closed ? esc(fmtTime(shift.closedAt)) : 'Still open'}</td></tr>
    </tbody></table>
    <h3 class="sec-title">Cash In</h3>${txTable(ins)}
    <h3 class="sec-title">Cash Out</h3>${txTable(outs)}
    <h3 class="sec-title">Patient outstanding payments</h3>
    ${L.payments.length ? `<table><thead><tr><th>Patient</th><th>Receipt</th><th>Method</th><th class="right">Amount</th></tr></thead><tbody>
      ${L.payments.map((p) => `<tr><td>${esc(p.patientName)}</td><td>${esc(p.receiptNo)}</td><td>${esc(p.methodName)}</td><td class="right">${money(p.amount)}</td></tr>`).join('')}</tbody></table>`
      : '<p class="muted">None.</p>'}
    <h3 class="sec-title">Cancelled slips</h3>
    ${cancelled.length ? `<table><thead><tr><th>Receipt</th><th>Patient</th><th class="right">Original amount</th><th>Reason</th><th>Approved by</th><th>Date</th></tr></thead><tbody>
      ${cancelled.map((b) => `<tr><td>${esc(b.receiptNo)}</td><td>${esc(b.patientName)}</td><td class="right">${money(b.net)}</td><td>${esc(b.cancelReason)}</td><td>${esc(b.cancelledByName)}</td><td>${esc(fmtTime(b.cancelledAt))}</td></tr>`).join('')}</tbody></table>`
      : '<p class="muted">None.</p>'}
    <h3 class="sec-title">Cash reconciliation</h3>
    ${summaryTable(shift, t)}
    ${closed ? `<table style="margin-top:8px"><tbody>
      <tr><td>Counted cash</td><td class="right">${money(shift.countedCash)}</td></tr>
      <tr style="font-weight:700"><td>Difference (${diffLabel})</td><td class="right">${money(diff)}</td></tr></tbody></table>
      ${shift.closeNotes ? `<p>Notes: ${esc(shift.closeNotes)}</p>` : ''}
      ${changed ? `<p class="error">Note: the ledger changed after closing (expected cash at closing was ${money(shift.expectedCash)}). A correction was posted.</p>` : ''}`
      : '<p class="muted">Counted cash and difference appear after the shift is closed.</p>'}
    <div class="sign"><div>Receptionist</div><div>Admin — checking report</div><div>Accountant — reviewing report</div></div>
    </div>`;
  $('#pr', box).onclick = () => printHtml(`<!doctype html><html><head><meta charset="utf-8"><title>Shift report</title>
    <style>body{font:13px Arial,sans-serif;margin:18px;color:#000}table{width:100%;border-collapse:collapse;margin-bottom:6px}
    th,td{text-align:left;padding:4px 6px;border-bottom:1px solid #999}.right{text-align:right}h2{text-align:center;margin:0}
    .sub{text-align:center;margin-bottom:12px}.sec-title{margin:16px 0 6px;font-size:14px}.muted{color:#555}.error{color:#b00}
    .sign{display:grid;grid-template-columns:repeat(3,1fr);gap:24px;margin-top:56px}.sign div{border-top:1px solid #000;padding-top:4px;text-align:center}</style>
    </head><body>${$('#rp', box).innerHTML}</body></html>`);
}

// ---------- Admin: shift reports, with authorized reopening ----------
export async function adminShiftsPage(c, ctx) {
  c.innerHTML = '<p class="muted">Loading…</p>';
  let shifts;
  try { shifts = await list('shifts', orderBy('openedAt', 'desc'), limit(50)); } catch { c.innerHTML = errCard; return; }
  c.innerHTML = `<div class="card"><h2>Shifts (latest 50)</h2>${shifts.length
    ? `<table><thead><tr><th>Opened</th><th>Receptionist</th><th>Shift</th><th>Status</th><th class="right">Opening cash</th><th class="right">Difference</th><th></th></tr></thead><tbody>
      ${shifts.map((s) => `<tr><td>${esc(fmtTime(s.openedAt))}</td><td>${esc(s.receptionistName)}</td><td>${esc(s.shiftName)}</td>
        <td><span class="pill ${s.status === 'open' ? 'warn' : 'on'}">${s.status === 'open' ? 'Open' : 'Closed'}</span></td>
        <td class="right">${money(s.openingCash)}</td>
        <td class="right">${s.status === 'closed' ? money(s.difference) : ''}</td>
        <td><button class="btn small" data-id="${esc(s.id)}">Report</button></td></tr>`).join('')}</tbody></table>`
    : '<p class="muted">No shifts yet.</p>'}</div><div id="detail"></div>`;
  c.querySelectorAll('button[data-id]').forEach((b) => {
    b.onclick = async () => {
      const shift = shifts.find((s) => s.id === b.dataset.id);
      const d = $('#detail', c);
      d.innerHTML = '';
      if (shift.status === 'closed') {
        const bar = document.createElement('div');
        bar.className = 'card no-print';
        bar.innerHTML = `<div class="row-gap"><strong>Reopen this shift</strong>
          <input class="inline" style="max-width:340px" id="why" placeholder="Reason (required, at least 5 characters)" maxlength="200">
          <button class="btn small" id="re">Reopen</button><span id="rm" class="error"></span></div>`;
        d.appendChild(bar);
        $('#re', bar).onclick = async () => {
          const why = $('#why', bar).value.trim();
          const rm = $('#rm', bar);
          if (why.length < 5) { rm.textContent = 'Enter a reason of at least 5 characters.'; return; }
          if (!confirm('Reopen this shift? The receptionist will be able to change it again.')) return;
          const batch = writeBatch(db);
          batch.update(doc(db, 'shifts', shift.id), { status: 'open', reopenedAt: serverTimestamp(), reopenedBy: ctx.uid, reopenReason: why });
          batch.set(doc(db, 'openShifts', shift.receptionistUid), { shiftId: shift.id, openedAt: serverTimestamp() });
          batch.set(doc(collection(db, 'auditLogs')), auditData(ctx.uid, 'admin', 'shift.reopen', 'shift', shift.id, { reason: why }));
          try { await batch.commit(); adminShiftsPage(c, ctx); }
          catch { rm.textContent = 'Could not reopen. That receptionist may already have an open shift.'; }
        };
      }
      await shiftReport(d, shift);
      d.scrollIntoView({ behavior: 'smooth' });
    };
  });
}
