// Thermal receipt for a posted bill (58 mm or 80 mm). Printing never creates a transaction.
import { esc, printHtml, fmtTime } from '../util.js';
import { money } from '../data.js';

export function billStatus(b) {
  if (b.status === 'cancelled') return 'CANCELLED';
  if (b.outstanding <= 0.004) return 'PAID';
  if ((b.received || 0) <= 0.004) return 'UNPAID';
  return 'PARTIALLY PAID';
}
export const statusClass = (b) => ({ PAID: 'paid', 'PARTIALLY PAID': 'part', UNPAID: 'unpaid', CANCELLED: 'off' }[billStatus(b)]);

export function billReceiptHtml(h, b, width = '80') {
  const w = width === '58' ? { page: '58mm', body: '52mm', font: '10px' } : { page: '80mm', body: '74mm', font: '12px' };
  const row = (a, v, bold) => `<tr${bold ? ' class="b"' : ''}><td>${esc(a)}</td><td class="r">${esc(v)}</td></tr>`;
  const lines = [];
  if (b.doctorId) lines.push(`<tr><td>Consultation: ${esc(b.doctorName)}</td><td class="r">${money(b.doctorFee)}</td></tr>`);
  (b.items || []).forEach((i) =>
    lines.push(`<tr><td>${esc(i.name)}${i.qty > 1 ? ` x${i.qty} @ ${money(i.price)}` : ''}</td><td class="r">${money(i.lineTotal)}</td></tr>`));
  return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(b.receiptNo)}</title>
    <style>@page{size:${w.page} auto;margin:2mm}body{font:${w.font} monospace;width:${w.body};margin:0;color:#000}
    h1{font-size:1.25em;text-align:center;margin:0}p{margin:2px 0;text-align:center}table{width:100%;border-collapse:collapse;margin-top:4px}
    td{padding:1px 0;vertical-align:top}.r{text-align:right;white-space:nowrap;padding-left:6px}.b td{font-weight:bold}hr{border:0;border-top:1px dashed #000;margin:5px 0}</style></head><body>
    <h1>${esc(h.hospitalName)}</h1><p>${esc(h.address)}</p><p>${esc(h.phone)}</p><hr>
    <table>${row('Receipt no.', b.receiptNo, true)}${row('Date', fmtTime(b.createdAt))}${row('Patient', b.patientName)}
    ${row('Age / Gender', `${b.age} / ${b.gender}`)}${row('Doctor', b.doctorName || '-')}</table><hr>
    <table>${lines.join('')}</table><hr>
    <table>${row('Gross total', money(b.gross))}${row('Discount', money(b.discount))}${row('Net total', money(b.net), true)}
    ${row('Amount received', money(b.received))}${row('Outstanding', money(b.outstanding), true)}${row('Payment method', b.paymentMethodName)}
    ${row('Status', billStatus(b), true)}${row('Receptionist', b.receptionistName)}</table><hr>
    ${b.status === 'cancelled' ? '<p><strong>*** CANCELLED ***</strong></p>' : ''}<p>Thank you. Get well soon.</p></body></html>`;
}
export const printBillReceipt = (h, b, width) => printHtml(billReceiptHtml(h, b, width));
