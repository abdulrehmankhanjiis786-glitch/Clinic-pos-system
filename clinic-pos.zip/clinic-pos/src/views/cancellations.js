// Phase 4: cancellation requests (Receptionist) and approvals / cancelled slips (Admin).
import { collection, doc, getDoc, writeBatch, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase.js';
import { auditData } from '../auth.js';
import { esc, $, fmtTime } from '../util.js';
import { list, money, parseAmount, round2, shortId } from '../data.js';

const errCard = '<div class="card error">Could not load data. Check your connection and try again.</div>';

// Receptionist asks the Admin to cancel a posted slip. One request per slip.
export async function requestCancellation(bill, reason, ctx) {
  const batch = writeBatch(db);
  batch.set(doc(db, 'cancellationRequests', bill.id), {
    billId: bill.id, receiptNo: bill.receiptNo, patientName: bill.patientName, originalAmount: bill.net,
    reason, requestedBy: ctx.uid, requestedByName: ctx.name, requestedAt: serverTimestamp(), status: 'pending',
  });
  batch.set(doc(collection(db, 'auditLogs')),
    auditData(ctx.uid, 'receptionist', 'cancel.request', 'bill', bill.id, { receiptNo: bill.receiptNo, reason }));
  await batch.commit();
}

// ---------- Admin ----------
export async function cancelledPage(c, ctx) {
  c.innerHTML = '<p class="muted">Loading…</p>';
  let reqs;
  try { reqs = await list('cancellationRequests'); } catch { c.innerHTML = errCard; return; }
  const byTime = (a, b) => (b.requestedAt?.seconds || 0) - (a.requestedAt?.seconds || 0);
  const pending = reqs.filter((r) => r.status === 'pending').sort(byTime);
  const done = reqs.filter((r) => r.status !== 'pending').sort(byTime);

  c.innerHTML = `
    <div class="card"><h2>Waiting for approval</h2>${pending.length
      ? `<table><thead><tr><th>Requested</th><th>Receipt</th><th>Patient</th><th class="right">Amount</th><th>By</th><th>Reason</th><th></th></tr></thead><tbody>
        ${pending.map((r) => `<tr><td>${esc(fmtTime(r.requestedAt))}</td><td>${esc(r.receiptNo)}</td><td>${esc(r.patientName)}</td>
          <td class="right">${money(r.originalAmount)}</td><td>${esc(r.requestedByName)}</td><td>${esc(r.reason)}</td>
          <td><button class="btn small" data-id="${esc(r.id)}">Review</button></td></tr>`).join('')}</tbody></table>`
      : '<p class="muted">No requests waiting.</p>'}</div>
    <div id="review"></div>
    <div class="card"><h2>Cancelled and rejected slips</h2>${done.length
      ? `<table><thead><tr><th>Decided</th><th>Receipt</th><th>Patient</th><th class="right">Amount</th><th>Result</th><th>Reason</th><th>Decided by</th></tr></thead><tbody>
        ${done.map((r) => `<tr><td>${esc(fmtTime(r.decidedAt))}</td><td>${esc(r.receiptNo)}</td><td>${esc(r.patientName)}</td>
          <td class="right">${money(r.originalAmount)}</td>
          <td><span class="pill ${r.status === 'approved' ? 'off' : 'warn'}">${r.status === 'approved' ? 'Cancelled' : 'Rejected'}</span></td>
          <td>${esc(r.reason)}</td><td>${esc(r.decidedByName)}</td></tr>`).join('')}</tbody></table>`
      : '<p class="muted">Nothing yet.</p>'}</div>`;

  c.querySelectorAll('button[data-id]').forEach((b) => {
    b.onclick = () => review(pending.find((r) => r.id === b.dataset.id));
  });

  async function review(req) {
    const box = $('#review', c);
    box.innerHTML = '<div class="card muted">Loading…</div>';
    let bill, shifts = [];
    try {
      const s = await getDoc(doc(db, 'bills', req.billId));
      bill = { id: s.id, ...s.data() };
      const open = await list('openShifts');
      for (const o of open) {
        const sh = await getDoc(doc(db, 'shifts', o.shiftId));
        if (sh.exists()) shifts.push({ id: sh.id, ...sh.data() });
      }
    } catch { box.innerHTML = errCard; return; }
    if (bill.status !== 'posted') { box.innerHTML = '<div class="card error">This slip is no longer active.</div>'; return; }

    box.innerHTML = `<div class="card"><h2>Review: ${esc(req.receiptNo)} — ${esc(req.patientName)}</h2>
      <p>Requested by ${esc(req.requestedByName)}. Reason: <em>${esc(req.reason)}</em></p>
      <p>Total received on this slip so far: <strong>${money(bill.received)}</strong></p>
      <form id="af" class="grid2">
        <label>Amount to refund (0 for none)<input name="refund" inputmode="decimal" value="${esc(round2(bill.received))}" required></label>
        <label>Refund paid as<select name="kind"><option value="cash">Physical cash from a till</option><option value="other">Card / bank / wallet</option></select></label>
        <label id="shl">Till (open shift) paying the cash<select name="shift">${shifts.length
          ? shifts.map((s) => `<option value="${esc(s.id)}">${esc(s.receptionistName)} — ${esc(s.shiftName)} (${esc(shortId(s.id))})</option>`).join('')
          : '<option value="">No open shift</option>'}</select></label>
        <label>Note (optional)<input name="note" maxlength="200"></label>
        <div class="row-end"><span id="am" class="error"></span>
          <button class="btn" type="button" id="rej">Reject</button><button class="btn primary">Approve cancellation</button></div>
      </form></div>`;
    const f = $('#af', box);
    const am = $('#am', box);
    const sync = () => { $('#shl', box).style.display = f.kind.value === 'cash' ? '' : 'none'; };
    f.kind.onchange = sync; sync();

    const decide = async (approve) => {
      const note = f.note.value.trim();
      const base = { decidedBy: ctx.uid, decidedByName: ctx.name, decidedAt: serverTimestamp(), decisionNote: note };
      const batch = writeBatch(db);
      let details = { receiptNo: req.receiptNo };
      if (approve) {
        const refund = parseAmount(f.refund.value, true);
        if (refund === null || refund > round2(bill.received) + 0.004) { am.textContent = 'Refund must be between 0 and the amount received.'; return; }
        const isCash = f.kind.value === 'cash';
        const shiftId = isCash && refund > 0 ? f.shift.value : '';
        if (isCash && refund > 0 && !shiftId) { am.textContent = 'A cash refund needs an open shift. Choose card/bank/wallet or wait for a shift to open.'; return; }
        batch.update(doc(db, 'cancellationRequests', req.id), { status: 'approved', ...base });
        batch.update(doc(db, 'bills', req.billId), {
          status: 'cancelled', cancelledAt: serverTimestamp(), cancelledBy: ctx.uid, cancelledByName: ctx.name,
          cancelReason: req.reason, refundAmount: refund, refundIsCash: isCash, refundShiftId: shiftId,
        });
        details = { ...details, refund, isCash };
      } else {
        batch.update(doc(db, 'cancellationRequests', req.id), { status: 'rejected', ...base });
      }
      batch.set(doc(collection(db, 'auditLogs')),
        auditData(ctx.uid, 'admin', approve ? 'cancel.approve' : 'cancel.reject', 'bill', req.billId, details));
      try { await batch.commit(); cancelledPage(c, ctx); }
      catch { am.textContent = 'Could not save. The slip may have changed; reload and try again.'; }
    };
    f.onsubmit = (e) => { e.preventDefault(); decide(true); };
    $('#rej', box).onclick = () => decide(false);
  }
}
