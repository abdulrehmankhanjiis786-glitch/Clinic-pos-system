// Developer dashboard: technical status only. No hospital, patient or financial data.
import { collection, doc, getDoc, limit, orderBy, writeBatch } from 'firebase/firestore';
import { auth, db, firebaseConfig, appCheckEnabled } from '../firebase.js';
import { auditData, writeAudit } from '../auth.js';
import { mountShell } from '../shell.js';
import { esc, $, fmtTime } from '../util.js';
import { list } from '../data.js';

/* global __APP_VERSION__, __BUILD_TIME__ */
const version = typeof __APP_VERSION__ !== 'undefined' ? __APP_VERSION__ : 'dev';
const buildTime = typeof __BUILD_TIME__ !== 'undefined' ? __BUILD_TIME__ : 'unknown';

export function renderDeveloper(root, name, role) {
  mountShell(root, {
    brand: 'Developer',
    roleLabel: 'Developer',
    name,
    nav: [
      { id: 'status', label: 'System status' },
      { id: 'diag', label: 'Error diagnostics' },
      { id: 'config', label: 'Configuration' },
    ],
    pages: { status: (c) => status(c, role), diag, config },
  });
}

async function status(c, role) {
  const uid = auth.currentUser.uid;
  let dbOk = false;
  try { dbOk = (await getDoc(doc(db, 'users', uid))).exists(); } catch { /* shown as failed */ }
  // Security check: a Developer must NOT be able to read hospital data. Permission-denied is the good result.
  let isolated = false;
  try { await getDoc(doc(db, 'settings', 'hospital')); } catch (e) { isolated = e?.code === 'permission-denied'; }
  let backup = null;
  try { const s = await getDoc(doc(db, 'meta', 'backupStatus')); backup = s.exists() ? s.data() : null; } catch { /* unknown */ }
  const t = await auth.currentUser.getIdTokenResult();
  const rows = [
    ['App version', version],
    ['Build time', buildTime],
    ['Deployment host', location.hostname],
    ['Firebase project', firebaseConfig.projectId || 'not set'],
    ['Authentication', `Signed in as ${role}`],
    ['Session token expires', new Date(t.expirationTime).toLocaleString()],
    ['Idle sign-out', '15 minutes'],
    ['Database connection', dbOk ? 'Connected' : 'Failed'],
    ['Hospital data blocked for Developer', isolated ? 'Yes (rules working)' : 'NO - check the security rules'],
    ['App Check', appCheckEnabled ? 'Enabled in app' : 'Not enabled yet'],
    ['Developer MFA', 'Not available on the free plan'],
    ['Last manual backup', backup?.manualAt ? fmtTime(backup.manualAt) : 'never'],
    ['Last automatic backup', backup?.autoAt ? `${fmtTime(backup.autoAt)} (${backup.autoStatus || ''})` : 'not set up'],
  ];
  c.innerHTML = `<div class="card"><h2>System status</h2><table><tbody>${rows
    .map(([k, v]) => `<tr><td>${esc(k)}</td><td>${esc(v)}</td></tr>`).join('')}</tbody></table></div>`;
}

async function diag(c) {
  c.innerHTML = '<p class="muted">Loading…</p>';
  writeAudit(auth.currentUser.uid, 'developer', 'developer.diagnostics.view', 'system', 'errorLogs').catch(() => {});
  let rows;
  try { rows = await list('errorLogs', orderBy('createdAt', 'desc'), limit(50)); }
  catch { c.innerHTML = '<div class="card error">Could not load the error log.</div>'; return; }
  c.innerHTML = `<div class="card"><div class="row-gap" style="justify-content:space-between"><h2 style="margin:0">Latest errors</h2>
    ${rows.length ? '<button class="btn small" id="clr">Clear log</button>' : ''}</div>
    ${rows.length ? `<table><thead><tr><th>Time</th><th>Role</th><th>Message</th><th>Source</th></tr></thead><tbody>
      ${rows.map((r) => `<tr><td>${esc(fmtTime(r.createdAt))}</td><td>${esc(r.role)}</td><td>${esc(r.message)}</td><td>${esc(r.source)}</td></tr>`).join('')}</tbody></table>`
      : '<p class="muted">No errors recorded.</p>'}</div>`;
  const clr = $('#clr', c);
  if (clr) {
    clr.onclick = async () => {
      if (!confirm('Delete these error records?')) return;
      const batch = writeBatch(db);
      rows.forEach((r) => batch.delete(doc(db, 'errorLogs', r.id)));
      batch.set(doc(collection(db, 'auditLogs')), auditData(auth.currentUser.uid, 'developer', 'developer.errorlog.clear', 'system', 'errorLogs', { count: rows.length }));
      try { await batch.commit(); diag(c); } catch { alert('Could not clear the log.'); }
    };
  }
}

function config(c) {
  const rows = [
    ['Project ID', firebaseConfig.projectId], ['Auth domain', firebaseConfig.authDomain], ['App ID', firebaseConfig.appId],
    ['Mode', import.meta.env.MODE], ['Page address', location.origin],
  ];
  c.innerHTML = `<div class="card"><h2>Configuration (non-secret values only)</h2><table><tbody>${rows
    .map(([k, v]) => `<tr><td>${esc(k)}</td><td>${esc(v || 'not set')}</td></tr>`).join('')}</tbody></table>
    <p class="muted">Keys, passwords and service accounts are never shown or stored in this app.</p></div>`;
}
