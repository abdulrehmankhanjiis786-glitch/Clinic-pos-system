// Admin: security status and manual backup download.
import { collection, doc, getDoc, getDocs, query, where, writeBatch, serverTimestamp, Timestamp } from 'firebase/firestore';
import { db, firebaseConfig, appCheckEnabled } from '../firebase.js';
import { auditData } from '../auth.js';
import { esc, $, fmtTime } from '../util.js';

// Collections that are saved in a backup. Audit logs and users are read through the same
// role filters the screens use, so a backup taken by the Admin never contains Developer data.
const PLAIN = ['doctors', 'services', 'paymentMethods', 'settings', 'staffLimits', 'openShifts', 'shifts', 'bills', 'payments',
  'cashTransactions', 'counters', 'cancellationRequests', 'discountApprovals'];

const encode = (v) => {
  if (v instanceof Timestamp) return { __ts: v.toDate().toISOString() };
  if (Array.isArray(v)) return v.map(encode);
  if (v && typeof v === 'object') return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, encode(x)]));
  return v;
};
const dump = async (name, ...cons) => {
  const s = await getDocs(query(collection(db, name), ...cons));
  return s.docs.map((d) => ({ id: d.id, data: encode(d.data()) }));
};

export async function securityPage(c, ctx) {
  c.innerHTML = '<p class="muted">Loading…</p>';
  let status = null;
  try { const s = await getDoc(doc(db, 'meta', 'backupStatus')); status = s.exists() ? s.data() : null; } catch { /* shown as unknown */ }
  const ageDays = (ts) => (ts?.toDate ? (Date.now() - ts.toDate().getTime()) / 86400000 : null);
  const autoAge = ageDays(status?.autoAt);
  const autoText = !status?.autoAt ? 'Not set up yet (see BACKUP_RESTORE.md)'
    : `${fmtTime(status.autoAt)} — ${esc(status.autoStatus || '')}${autoAge > 2 ? ' (older than 2 days: check GitHub Actions)' : ''}`;

  c.innerHTML = `
    <div class="card"><h2>Security status</h2><table><tbody>
      <tr><td>Signed-in role</td><td>Admin</td></tr>
      <tr><td>Automatic sign-out when idle</td><td>30 minutes</td></tr>
      <tr><td>Firebase project</td><td>${esc(firebaseConfig.projectId || 'not set')}</td></tr>
      <tr><td>App Check (browser)</td><td>${appCheckEnabled ? 'Enabled in this app' : 'Not enabled (see SETUP_GUIDE.md)'}</td></tr>
      <tr><td>Database rules</td><td>Published from firestore.rules (check the Rules tab in the Firebase console)</td></tr>
      <tr><td>Developer accounts</td><td>Managed outside this screen by design</td></tr></tbody></table></div>
    <div class="card"><h2>Backups</h2>
      <p>Last manual backup: <strong>${status?.manualAt ? esc(fmtTime(status.manualAt)) : 'never'}</strong></p>
      <p>Last automatic backup: <strong>${autoText}</strong></p>
      <p class="muted">A backup file contains patient and financial data. Keep it private; never email it or put it in a public place.</p>
      <div class="row-gap"><button class="btn primary" id="bk">Download backup now</button><span id="bm" class="muted"></span></div></div>`;

  $('#bk', c).onclick = async () => {
    const m = $('#bm', c);
    m.className = 'muted';
    m.textContent = 'Reading data…';
    $('#bk', c).disabled = true;
    try {
      const out = { app: 'clinic-pos', format: 1, createdAt: new Date().toISOString(), project: firebaseConfig.projectId, collections: {} };
      for (const n of PLAIN) out.collections[n] = await dump(n);
      out.collections.users = [
        ...(await dump('users', where('role', '==', 'admin'))), ...(await dump('users', where('role', '==', 'receptionist'))),
      ];
      out.collections.auditLogs = [
        ...(await dump('auditLogs', where('role', '==', 'admin'))), ...(await dump('auditLogs', where('role', '==', 'receptionist'))),
      ];
      const counts = {};
      Object.entries(out.collections).forEach(([k, v]) => (counts[k] = v.length));
      const blob = new Blob([JSON.stringify(out)], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `clinic-pos-backup-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      const batch = writeBatch(db);
      batch.set(doc(db, 'meta', 'backupStatus'), { manualAt: serverTimestamp(), manualBy: ctx.uid, manualCounts: counts }, { merge: true });
      batch.set(doc(collection(db, 'auditLogs')), auditData(ctx.uid, 'admin', 'backup.manual', 'system', 'backup', { counts }));
      await batch.commit();
      m.textContent = 'Backup downloaded. Move the file to a safe private place.';
      securityPage(c, ctx);
    } catch {
      m.className = 'error';
      m.textContent = 'Backup failed. Nothing was saved; try again.';
      $('#bk', c).disabled = false;
    }
  };
}
