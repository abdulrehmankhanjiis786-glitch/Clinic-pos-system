// Phase 3: New Bill, Hold / Resume.
import { collection, doc, getDoc, writeBatch, serverTimestamp, where } from 'firebase/firestore';
import { db } from '../firebase.js';
import { auditData } from '../auth.js';
import { esc, $, modal, fmtTime, setPageShortcuts } from '../util.js';
import { list, getOpenShift, getHospital, money, parseAmount, round2 } from '../data.js';
import { printBillReceipt } from './receipt.js';

const errCard = '<div class="card error">Could not load data. Check your connection and try again.</div>';
const byName = (a, b) => a.name.localeCompare(b.name);
const MAX_LINES = 12; // the security rules check up to 12 service lines against the price list
let flash = '';

export async function newBillPage(c, ctx) {
  c.innerHTML = '<p class="muted">Loading…</p>';
  let shift, doctors, services, methods, limitsSnap, hospital;
  try {
    shift = await getOpenShift(ctx.uid);
    if (!shift) {
      c.innerHTML = '<div class="card"><h2>New Bill</h2><p class="muted">Open your shift first (Current Shift), then you can bill patients.</p></div>';
      return;
    }
    [doctors, services, methods, limitsSnap, hospital] = await Promise.all([
      list('doctors'), list('services'), list('paymentMethods'), getDoc(doc(db, 'staffLimits', ctx.uid)), getHospital(),
    ]);
  } catch { c.innerHTML = errCard; return; }
  doctors = doctors.filter((d) => d.active).sort(byName);
  services = services.filter((s) => s.active).sort(byName);
  methods = methods.filter((m) => m.active).sort(byName);
  if (!methods.length) {
    c.innerHTML = '<div class="card"><h2>New Bill</h2><p class="muted">The Admin has not added any payment methods yet (Settings).</p></div>';
    return;
  }
  const limits = limitsSnap.exists() ? limitsSnap.data() : { maxDiscountPercent: 0, maxDiscountFixed: 0 };

  const st = {
    billId: doc(collection(db, 'bills')).id, heldId: null, patientName: '', age: '', gender: '', doctorId: '',
    items: [], discountType: 'none', discountValue: '', paid: '', methodId: methods[0].id, approvalId: '', approvalAmount: 0,
  };
  const draft = ctx.pendingDraft;
  ctx.pendingDraft = null;
  if (draft) {
    st.heldId = draft.id;
    Object.assign(st, {
      patientName: draft.patientName || '', age: draft.age || '', gender: draft.gender || '',
      discountType: draft.discountType || 'none', discountValue: draft.discountValue || '', paid: draft.paid || '',
    });
    if (doctors.some((d) => d.id === draft.doctorId)) st.doctorId = draft.doctorId;
    if (methods.some((m) => m.id === draft.paymentMethodId)) st.methodId = draft.paymentMethodId;
    // Prices are always re-read from the current price list.
    st.items = (draft.items || []).filter((i) => services.some((s) => s.id === i.id)).map((i) => ({ id: i.id, qty: i.qty }));
  }
  const message = flash;
  flash = '';

  const doctorOf = () => doctors.find((d) => d.id === st.doctorId);
  const hasContent = () => Boolean(st.patientName || st.age || st.gender || st.doctorId || st.items.length);

  function calc() {
    const doctor = doctorOf();
    const doctorFee = doctor ? doctor.fee : 0;
    const lines = st.items.map((it) => {
      const s = services.find((x) => x.id === it.id);
      return { id: s.id, name: s.name, price: s.price, qty: it.qty, lineTotal: round2(s.price * it.qty) };
    });
    const gross = round2(doctorFee + lines.reduce((t, l) => t + l.lineTotal, 0));
    const val = Number(st.discountValue) || 0;
    let discount = 0;
    if (st.discountType === 'percent') discount = round2((gross * val) / 100);
    if (st.discountType === 'fixed') discount = round2(val);
    const net = round2(gross - discount);
    const paid = parseAmount(st.paid, true) ?? 0;
    return { doctor, doctorFee, lines, gross, discount, net, paid, outstanding: round2(net - paid) };
  }
  function limitState(t) {
    if (t.discount <= 0) return 'ok';
    const v = Number(st.discountValue) || 0;
    if ((st.discountType === 'percent' && v <= limits.maxDiscountPercent) ||
        (st.discountType === 'fixed' && v <= limits.maxDiscountFixed)) return 'ok';
    if (st.approvalId && st.approvalAmount >= t.discount - 0.004) return 'approved';
    return 'needs';
  }

  c.innerHTML = `
    ${message ? `<div class="card" style="border-color:var(--ok)">${esc(message)}</div>` : ''}
    <div class="bill-grid">
      <div>
        <div class="card"><h2>Patient</h2><div class="grid3">
          <label>Patient name<input id="pn" maxlength="80" autocomplete="off" value="${esc(st.patientName)}"></label>
          <label>Age<input id="pa" inputmode="numeric" maxlength="3" autocomplete="off" value="${esc(st.age)}"></label>
          <label>Gender<select id="pg"><option value="">Select</option>${['Male', 'Female', 'Other'].map((g) => `<option ${st.gender === g ? 'selected' : ''}>${g}</option>`).join('')}</select></label>
        </div></div>
        <div class="card"><h2>Doctor and services</h2>
          <label>Doctor (Alt+D) <span class="hint">type to search</span>
            <input id="doc" list="dl-doc" autocomplete="off" value="${esc(doctorOf()?.name || '')}"></label>
          <datalist id="dl-doc">${doctors.map((d) => `<option value="${esc(d.name)}"></option>`).join('')}</datalist>
          <div class="row-gap" style="margin-bottom:10px">
            <input id="svc" list="dl-svc" class="inline" style="max-width:320px" placeholder="Search service (Alt+S)" autocomplete="off">
            <input id="qty" class="num-in" style="width:70px" value="1" inputmode="numeric" aria-label="Quantity">
            <button class="btn" id="add" type="button">Add service</button><span id="svcmsg" class="error"></span>
          </div>
          <datalist id="dl-svc">${services.map((s) => `<option value="${esc(s.name)}"></option>`).join('')}</datalist>
          <div id="inv"></div>
          <div class="row-gap" style="margin-top:12px"><button class="btn" id="hold" type="button">Hold bill (Ctrl+S)</button><span id="holdmsg" class="error"></span></div>
        </div>
      </div>
      <div class="card"><h2>Totals and payment</h2>
        <table class="tot"><tbody>
          <tr><td>Gross total</td><td class="right" id="tg"></td></tr>
          <tr><td>Discount</td><td class="right" id="td"></td></tr>
          <tr class="big"><td>Net total</td><td class="right" id="tn"></td></tr></tbody></table>
        <div class="row-gap" style="margin:8px 0">
          <select id="dtype" class="inline" style="max-width:150px" aria-label="Discount type (Alt+C)">
            <option value="none">No discount</option><option value="percent">Percent %</option><option value="fixed">Fixed amount</option></select>
          <input id="dval" class="num-in" inputmode="decimal" placeholder="Value" aria-label="Discount value">
        </div>
        <div id="dmsg" class="hint"></div>
        <label style="margin-top:10px">Payment method<select id="pm">${methods.map((m) => `<option value="${esc(m.id)}">${esc(m.name)}</option>`).join('')}</select></label>
        <div class="row-gap"><label style="margin:0;flex:1">Amount received (Alt+P)
          <input id="paid" inputmode="decimal" autocomplete="off" value="${esc(st.paid)}"></label>
          <button class="btn small" id="full" type="button">Full</button></div>
        <table class="tot"><tbody><tr class="big"><td>Outstanding</td><td class="right" id="to"></td></tr></tbody></table>
        <div id="perr" class="error"></div>
        <button class="btn primary" id="post" style="width:100%;margin-top:6px" type="button">Post bill (Ctrl+Enter)</button>
      </div>
    </div>`;
  $('#dtype', c).value = st.discountType;
  $('#dval', c).value = st.discountValue;
  $('#pm', c).value = st.methodId;

  // ----- drawing -----
  function drawInvoice() {
    const t = calc();
    const rows = [];
    if (t.doctor) rows.push(`<tr><td>Consultation: ${esc(t.doctor.name)}</td><td class="right">${money(t.doctorFee)}</td><td class="right">1</td><td class="right">${money(t.doctorFee)}</td><td></td></tr>`);
    t.lines.forEach((l, i) => rows.push(`<tr><td>${esc(l.name)}</td><td class="right">${money(l.price)}</td>
      <td class="right"><input class="num-in" style="width:64px" value="${l.qty}" data-q="${i}" inputmode="numeric" aria-label="Quantity"></td>
      <td class="right">${money(l.lineTotal)}</td><td><button class="btn small" data-rm="${i}" type="button">Remove</button></td></tr>`));
    $('#inv', c).innerHTML = rows.length
      ? `<table><thead><tr><th>Item</th><th class="right">Price</th><th class="right">Qty</th><th class="right">Total</th><th></th></tr></thead><tbody>${rows.join('')}</tbody></table>`
      : '<p class="muted">Select a doctor and/or add services.</p>';
    c.querySelectorAll('[data-rm]').forEach((b) => (b.onclick = () => { st.items.splice(Number(b.dataset.rm), 1); drawAll(); }));
    c.querySelectorAll('[data-q]').forEach((inp) => {
      inp.onchange = () => {
        const q = Number(inp.value);
        if (Number.isInteger(q) && q >= 1 && q <= 99) st.items[Number(inp.dataset.q)].qty = q;
        drawAll();
      };
    });
  }
  function drawTotals() {
    const t = calc();
    $('#tg', c).textContent = money(t.gross);
    $('#td', c).textContent = money(t.discount);
    $('#tn', c).textContent = money(t.net);
    $('#to', c).textContent = money(t.outstanding);
    const ls = limitState(t);
    const d = $('#dmsg', c);
    if (ls === 'ok') d.innerHTML = t.discount > 0 ? 'Within your permitted limit.' : `Your limit: ${limits.maxDiscountPercent}% or ${money(limits.maxDiscountFixed)}.`;
    else if (ls === 'approved') d.innerHTML = '<span style="color:var(--ok)">Admin approval attached.</span>';
    else d.innerHTML = `<span class="error">Above your limit (${limits.maxDiscountPercent}% / ${money(limits.maxDiscountFixed)}).</span>
      <button class="btn small" id="req" type="button">Request approval</button> <button class="btn small" id="chk" type="button">Check approval</button>`;
    const req = $('#req', c);
    if (req) {
      req.onclick = requestApproval;
      $('#chk', c).onclick = checkApproval;
    }
  }
  function drawAll() { drawInvoice(); drawTotals(); }

  // ----- inputs -----
  $('#pn', c).oninput = (e) => (st.patientName = e.target.value);
  $('#pa', c).oninput = (e) => (st.age = e.target.value);
  $('#pg', c).onchange = (e) => (st.gender = e.target.value);
  $('#doc', c).oninput = (e) => {
    const v = e.target.value.trim().toLowerCase();
    st.doctorId = doctors.find((d) => d.name.toLowerCase() === v)?.id || '';
    drawAll();
  };
  const addService = () => {
    const m = $('#svcmsg', c);
    m.textContent = '';
    const name = $('#svc', c).value.trim().toLowerCase();
    const s = services.find((x) => x.name.toLowerCase() === name);
    const q = Number($('#qty', c).value);
    if (!s) { m.textContent = 'Choose a service from the list.'; return; }
    if (!Number.isInteger(q) || q < 1 || q > 99) { m.textContent = 'Quantity must be 1-99.'; return; }
    const existing = st.items.find((i) => i.id === s.id);
    if (existing) existing.qty = Math.min(99, existing.qty + q);
    else if (st.items.length >= MAX_LINES) { m.textContent = `A bill can have at most ${MAX_LINES} different services.`; return; }
    else st.items.push({ id: s.id, qty: q });
    $('#svc', c).value = '';
    $('#qty', c).value = '1';
    $('#svc', c).focus();
    drawAll();
  };
  $('#add', c).onclick = addService;
  $('#svc', c).onkeydown = (e) => { if (e.key === 'Enter') { e.preventDefault(); addService(); } };
  $('#dtype', c).onchange = (e) => { st.discountType = e.target.value; st.approvalId = ''; st.approvalAmount = 0; drawTotals(); };
  $('#dval', c).oninput = (e) => { st.discountValue = e.target.value; drawTotals(); };
  $('#pm', c).onchange = (e) => (st.methodId = e.target.value);
  $('#paid', c).oninput = (e) => { st.paid = e.target.value; drawTotals(); };
  $('#full', c).onclick = () => { st.paid = String(calc().net); $('#paid', c).value = st.paid; drawTotals(); };

  // ----- discount approval -----
  async function requestApproval() {
    const t = calc();
    const reason = (prompt('Reason for this discount (at least 5 characters):') || '').trim();
    if (reason.length < 5) return;
    const ref = doc(collection(db, 'discountApprovals'));
    const batch = writeBatch(db);
    batch.set(ref, {
      receptionistUid: ctx.uid, receptionistName: ctx.name, patientName: st.patientName.trim().slice(0, 80),
      grossTotal: t.gross, discountAmount: t.discount, reason: reason.slice(0, 200), status: 'pending', requestedAt: serverTimestamp(),
    });
    batch.set(doc(collection(db, 'auditLogs')), auditData(ctx.uid, 'receptionist', 'discount.request', 'discountApproval', ref.id, { amount: t.discount }));
    try { await batch.commit(); $('#dmsg', c).innerHTML = 'Request sent. When the Admin approves it, press "Check approval".'; }
    catch { $('#dmsg', c).innerHTML = '<span class="error">Could not send the request.</span>'; }
  }
  async function checkApproval() {
    const t = calc();
    try {
      const all = await list('discountApprovals', where('receptionistUid', '==', ctx.uid), where('status', '==', 'approved'));
      const ok = all.filter((a) => a.discountAmount >= t.discount - 0.004).sort((a, b) => a.discountAmount - b.discountAmount)[0];
      if (!ok) { $('#dmsg', c).innerHTML = '<span class="error">No approval found yet for this amount.</span>'; return; }
      st.approvalId = ok.id; st.approvalAmount = ok.discountAmount;
      drawTotals();
    } catch { $('#dmsg', c).innerHTML = '<span class="error">Could not check. Try again.</span>'; }
  }

  // ----- hold -----
  async function hold() {
    const m = $('#holdmsg', c);
    m.textContent = '';
    if (!hasContent()) { m.textContent = 'Nothing to hold yet.'; return; }
    const ref = st.heldId ? doc(db, 'heldBills', st.heldId) : doc(collection(db, 'heldBills'));
    const batch = writeBatch(db);
    batch.set(ref, {
      receptionistUid: ctx.uid, receptionistName: ctx.name, shiftId: shift.id,
      patientName: st.patientName.slice(0, 80), age: String(st.age).slice(0, 3), gender: st.gender, doctorId: st.doctorId,
      items: st.items.map((i) => ({ id: i.id, qty: i.qty })), discountType: st.discountType,
      discountValue: String(st.discountValue).slice(0, 12), paymentMethodId: st.methodId, paid: String(st.paid).slice(0, 12),
      savedAt: serverTimestamp(),
    });
    batch.set(doc(collection(db, 'auditLogs')), auditData(ctx.uid, 'receptionist', 'bill.hold', 'heldBill', ref.id));
    try { await batch.commit(); flash = 'Bill held. Find it under Held Bills.'; newBillPage(c, ctx); }
    catch { m.textContent = 'Could not hold the bill. Try again.'; }
  }
  $('#hold', c).onclick = hold;

  // ----- post -----
  function validate(t) {
    if (st.patientName.trim().length < 2) return 'Enter the patient name.';
    if (!/^\d{1,3}$/.test(String(st.age).trim()) || Number(st.age) > 150) return 'Enter a valid age.';
    if (!st.gender) return 'Select the gender.';
    if (t.gross <= 0) return 'Add a doctor and/or services with a price.';
    if (st.discountType !== 'none' && !(Number(st.discountValue) > 0)) return 'Enter the discount value or choose No discount.';
    if (st.discountType === 'percent' && Number(st.discountValue) > 100) return 'Percent discount cannot exceed 100.';
    if (t.discount > t.gross) return 'Discount cannot be more than the gross total.';
    if (limitState(t) === 'needs') return 'The discount is above your limit. Request Admin approval.';
    if (st.paid !== '' && parseAmount(st.paid, true) === null) return 'Enter a valid amount received.';
    if (t.paid > t.net + 0.004) return 'Amount received cannot be more than the net total.';
    return '';
  }
  function startPost() {
    const t = calc();
    const err = validate(t);
    $('#perr', c).textContent = err;
    if (err) return;
    const method = methods.find((m) => m.id === st.methodId);
    const m = modal(`<h2>Confirm and post</h2>
      <table><tbody>
        <tr><td>Patient</td><td class="right">${esc(st.patientName.trim())}, ${esc(st.age)} / ${esc(st.gender)}</td></tr>
        <tr><td>Doctor</td><td class="right">${esc(t.doctor?.name || '-')}</td></tr>
        <tr><td>Services</td><td class="right">${t.lines.length ? t.lines.map((l) => `${esc(l.name)} x${l.qty}`).join(', ') : '-'}</td></tr>
        <tr><td>Gross total</td><td class="right">${money(t.gross)}</td></tr>
        <tr><td>Discount</td><td class="right">${money(t.discount)}</td></tr>
        <tr><td><strong>Net total</strong></td><td class="right"><strong>${money(t.net)}</strong></td></tr>
        <tr><td>Amount received</td><td class="right">${money(t.paid)}</td></tr>
        <tr><td><strong>Outstanding</strong></td><td class="right"><strong>${money(t.outstanding)}</strong></td></tr>
        <tr><td>Payment method</td><td class="right">${esc(method.name)}</td></tr></tbody></table>
      <p class="muted">A posted bill cannot be edited or deleted.</p>
      <div class="row-gap" style="justify-content:flex-end"><span id="mm" class="error"></span>
        <button class="btn" id="mc" type="button">Back (Esc)</button><button class="btn primary" id="mo" type="button">Confirm and post</button></div>`);
    $('#mc', m.el).onclick = m.close;
    $('#mo', m.el).onclick = () => doPost(t, method, m);
  }
  let posting = false;
  async function doPost(t, method, m) {
    if (posting) return; // blocks double clicks
    posting = true;
    $('#mo', m.el).disabled = true;
    const billRef = doc(db, 'bills', st.billId);
    const useApproval = t.discount > 0 && limitState(t) === 'approved';
    try {
      for (let attempt = 0; attempt < 2; attempt++) {
        const counterRef = doc(db, 'counters', 'receipt');
        const cs = await getDoc(counterRef);
        const seq = (cs.exists() ? cs.data().value : 0) + 1;
        const bill = {
          receiptNo: 'R-' + String(seq).padStart(6, '0'), seq,
          patientName: st.patientName.trim(), age: Number(st.age), gender: st.gender,
          doctorId: t.doctor ? t.doctor.id : '', doctorName: t.doctor ? t.doctor.name : '', doctorFee: t.doctorFee,
          items: t.lines, gross: t.gross, discountType: st.discountType,
          discountValue: st.discountType === 'none' ? 0 : Number(st.discountValue), discount: t.discount,
          approvalId: useApproval ? st.approvalId : '', net: t.net, initialPaid: t.paid, received: t.paid, outstanding: t.outstanding,
          paymentMethodId: method.id, paymentMethodName: method.name, isCash: method.isCash, status: 'posted',
          shiftId: shift.id, receptionistUid: ctx.uid, receptionistName: ctx.name, createdAt: serverTimestamp(),
        };
        const batch = writeBatch(db);
        batch.set(counterRef, { value: seq });
        batch.set(billRef, bill);
        if (useApproval) batch.update(doc(db, 'discountApprovals', st.approvalId), { status: 'used', usedAt: serverTimestamp(), billId: st.billId });
        if (st.heldId) batch.delete(doc(db, 'heldBills', st.heldId));
        batch.set(doc(collection(db, 'auditLogs')), auditData(ctx.uid, 'receptionist', 'bill.post', 'bill', st.billId,
          { receiptNo: bill.receiptNo, net: t.net, discount: t.discount, shiftId: shift.id }));
        try {
          await batch.commit();
          m.close();
          const saved = { id: st.billId, ...(await getDoc(billRef)).data() };
          showPosted(saved);
          return;
        } catch (e) {
          if (attempt === 1) throw e;
        }
      }
    } catch {
      posting = false;
      $('#mo', m.el).disabled = false;
      $('#mm', m.el).textContent = 'Could not post. Check the shift is open and try again.';
    }
  }
  function showPosted(bill) {
    setPageShortcuts({ 'Alt+N': () => newBillPage(c, ctx) });
    c.innerHTML = `<div class="card"><h2>Bill posted — ${esc(bill.receiptNo)}</h2>
      <p>${esc(bill.patientName)} · Net ${money(bill.net)} · Received ${money(bill.received)} · Outstanding ${money(bill.outstanding)}</p>
      <div class="row-gap"><button class="btn primary" id="p80">Print 80 mm</button><button class="btn" id="p58">Print 58 mm</button>
        <button class="btn" id="nb">New bill (Alt+N)</button></div></div>`;
    $('#p80', c).onclick = () => printBillReceipt(hospital, bill, '80');
    $('#p58', c).onclick = () => printBillReceipt(hospital, bill, '58');
    $('#nb', c).onclick = () => newBillPage(c, ctx);
    printBillReceipt(hospital, bill, '80');
  }
  $('#post', c).onclick = startPost;

  setPageShortcuts({
    'Alt+N': () => { if (!hasContent() || confirm('Discard this bill and start a new one?')) newBillPage(c, ctx); },
    'Alt+D': () => $('#doc', c).focus(),
    'Alt+S': () => $('#svc', c).focus(),
    'Alt+C': () => $('#dtype', c).focus(),
    'Alt+P': () => $('#paid', c).focus(),
    'Ctrl+Enter': startPost,
    'Ctrl+S': hold,
  });
  drawAll();
  $('#pn', c).focus();
}

// ---------- Held bills ----------
export async function heldPage(c, ctx) {
  c.innerHTML = '<p class="muted">Loading…</p>';
  let held, doctors;
  try { [held, doctors] = await Promise.all([list('heldBills', where('receptionistUid', '==', ctx.uid)), list('doctors')]); }
  catch { c.innerHTML = errCard; return; }
  held.sort((a, b) => (b.savedAt?.seconds || 0) - (a.savedAt?.seconds || 0));
  c.innerHTML = `<div class="card"><h2>Held bills</h2>
    <p class="muted">Held bills are drafts. They are not sales and no money is counted for them.</p>
    ${held.length ? `<table><thead><tr><th>Saved</th><th>Patient</th><th>Doctor</th><th>Services</th><th></th></tr></thead><tbody>
      ${held.map((h) => `<tr><td>${esc(fmtTime(h.savedAt))}</td><td>${esc(h.patientName || '(no name yet)')}</td>
        <td>${esc(doctors.find((d) => d.id === h.doctorId)?.name || '-')}</td><td>${(h.items || []).length}</td>
        <td class="row-gap"><button class="btn small primary" data-res="${esc(h.id)}">Resume</button>
          <button class="btn small" data-del="${esc(h.id)}">Discard</button></td></tr>`).join('')}</tbody></table>`
      : '<p class="muted">No held bills.</p>'}</div>`;
  c.querySelectorAll('[data-res]').forEach((b) => {
    b.onclick = () => { ctx.pendingDraft = held.find((h) => h.id === b.dataset.res); ctx.go('bill'); };
  });
  c.querySelectorAll('[data-del]').forEach((b) => {
    b.onclick = async () => {
      if (!confirm('Discard this held bill?')) return;
      const batch = writeBatch(db);
      batch.delete(doc(db, 'heldBills', b.dataset.del));
      batch.set(doc(collection(db, 'auditLogs')), auditData(ctx.uid, 'receptionist', 'bill.hold.discard', 'heldBill', b.dataset.del));
      try { await batch.commit(); heldPage(c, ctx); } catch { alert('Could not discard. Try again.'); }
    };
  });
}
