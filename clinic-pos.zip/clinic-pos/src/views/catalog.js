// Phase 2 (Admin): Doctors, Services, Fees and Settings.
import { collection, doc, writeBatch, serverTimestamp, where } from 'firebase/firestore';
import { db } from '../firebase.js';
import { auditData } from '../auth.js';
import { esc, $ } from '../util.js';
import { getDoc } from 'firebase/firestore';
import { list, parseAmount, money, getHospital } from '../data.js';

const CFG = {
  doctors: { coll: 'doctors', field: 'fee', singular: 'doctor', title: 'Doctors', amountLabel: 'Consultation fee' },
  services: { coll: 'services', field: 'price', singular: 'service', title: 'Services', amountLabel: 'Price' },
};
const errLine = (m) => `<span class="error">${esc(m)}</span>`;
const auditSet = (batch, ctx, action, type, id, details) =>
  batch.set(doc(collection(db, 'auditLogs')), auditData(ctx.uid, 'admin', action, type, id, details));

// settings/priceList mirrors doctors + services so bills can be checked against it. Every change is saved in the same batch.
const entry = (cfg, i) => ({ name: i.name, [cfg.field]: i[cfg.field], active: i.active });
const priceListRef = () => doc(db, 'settings', 'priceList');
const mirror = (batch, ctx, cfg, id, data) =>
  batch.set(priceListRef(), { [cfg.coll]: { [id]: entry(cfg, data) }, updatedAt: serverTimestamp(), updatedBy: ctx.uid }, { merge: true });

// Rebuilds the whole price list from the current doctors and services (also repairs older data).
export async function syncPriceList(ctx) {
  const [doctors, services] = await Promise.all([list('doctors'), list('services')]);
  const build = (cfg, arr) => Object.fromEntries(arr.map((i) => [i.id, entry(cfg, i)]));
  const want = { doctors: build(CFG.doctors, doctors), services: build(CFG.services, services) };
  const cur = await getDoc(priceListRef());
  const same = cur.exists() && JSON.stringify(cur.data().doctors || {}) === JSON.stringify(want.doctors)
    && JSON.stringify(cur.data().services || {}) === JSON.stringify(want.services);
  if (same) return false;
  const batch = writeBatch(db);
  batch.set(priceListRef(), { ...want, updatedAt: serverTimestamp(), updatedBy: ctx.uid });
  auditSet(batch, ctx, 'pricelist.rebuild', 'settings', 'priceList', { doctors: doctors.length, services: services.length });
  await batch.commit();
  return true;
}

async function updateItem(ctx, cfg, item, changes, action) {
  const batch = writeBatch(db);
  batch.update(doc(db, cfg.coll, item.id), { ...changes, updatedAt: serverTimestamp(), updatedBy: ctx.uid });
  mirror(batch, ctx, cfg, item.id, { ...item, ...changes });
  const before = {};
  Object.keys(changes).forEach((k) => (before[k] = item[k]));
  auditSet(batch, ctx, action, cfg.singular, item.id, { name: item.name, before, after: changes });
  await batch.commit();
}

// ---------- Doctors and Services (same screen, different collection) ----------
export function catalogPage(c, ctx, key) {
  const cfg = CFG[key];
  c.innerHTML = `
    <div class="card"><h2>Add ${cfg.singular}</h2>
      <form id="f" class="grid2">
        <label>Name<input name="name" required minlength="2" maxlength="80" autocomplete="off"></label>
        <label>${cfg.amountLabel}<input name="amount" required inputmode="decimal" autocomplete="off"></label>
        <div class="row-end"><span id="msg" class="muted"></span><button class="btn primary">Add ${cfg.singular}</button></div>
      </form></div>
    <div class="card"><h2>${cfg.title}</h2>
      <p class="muted">To change a ${cfg.amountLabel.toLowerCase()}, use the Fees screen.</p>
      <div id="list" class="muted">Loading…</div></div>`;
  const box = $('#list', c);
  let items = [];

  async function refresh() {
    try {
      items = (await list(cfg.coll)).sort((a, b) => a.name.localeCompare(b.name));
    } catch { box.innerHTML = errLine('Could not load the list.'); return; }
    box.className = '';
    if (!items.length) { box.innerHTML = `<span class="muted">No ${cfg.title.toLowerCase()} yet.</span>`; return; }
    box.innerHTML = `<table><thead><tr><th>Name</th><th class="right">${cfg.amountLabel}</th><th>Status</th><th></th></tr></thead><tbody>
      ${items.map((i) => `<tr data-id="${esc(i.id)}">
        <td><input class="inline" value="${esc(i.name)}" maxlength="80" data-name></td>
        <td class="right">${money(i[cfg.field])}</td>
        <td><span class="pill ${i.active ? 'on' : 'off'}">${i.active ? 'Active' : 'Inactive'}</span></td>
        <td class="row-gap"><button class="btn small" data-save>Save name</button>
          <button class="btn small" data-toggle>${i.active ? 'Deactivate' : 'Activate'}</button></td></tr>`).join('')}
      </tbody></table><div id="rowmsg" class="error"></div>`;
    box.querySelectorAll('tr[data-id]').forEach((tr) => {
      const item = items.find((x) => x.id === tr.dataset.id);
      const fail = (e) => { $('#rowmsg', box).textContent = 'Could not save. ' + (e?.code === 'permission-denied' ? 'Not allowed.' : 'Try again.'); };
      $('[data-save]', tr).onclick = async () => {
        const name = $('[data-name]', tr).value.trim();
        if (name.length < 2) { $('#rowmsg', box).textContent = 'Name must be at least 2 characters.'; return; }
        if (name === item.name) return;
        if (items.some((x) => x.id !== item.id && x.name.toLowerCase() === name.toLowerCase())) {
          $('#rowmsg', box).textContent = 'That name already exists.'; return;
        }
        try { await updateItem(ctx, cfg, item, { name }, `${cfg.singular}.rename`); refresh(); } catch (e) { fail(e); }
      };
      $('[data-toggle]', tr).onclick = async () => {
        try { await updateItem(ctx, cfg, item, { active: !item.active }, `${cfg.singular}.${item.active ? 'deactivate' : 'activate'}`); refresh(); }
        catch (e) { fail(e); }
      };
    });
  }

  $('#f', c).onsubmit = async (e) => {
    e.preventDefault();
    const f = e.target;
    const msg = $('#msg', c);
    const name = f.name.value.trim();
    const amount = parseAmount(f.amount.value, true);
    msg.className = 'error';
    if (name.length < 2) { msg.textContent = 'Enter a name.'; return; }
    if (amount === null) { msg.textContent = 'Enter a valid amount, for example 500 or 500.50.'; return; }
    if (items.some((x) => x.name.toLowerCase() === name.toLowerCase())) { msg.textContent = 'That name already exists.'; return; }
    const ref = doc(collection(db, cfg.coll));
    const batch = writeBatch(db);
    batch.set(ref, { name, [cfg.field]: amount, active: true, createdAt: serverTimestamp(), createdBy: ctx.uid });
    mirror(batch, ctx, cfg, ref.id, { name, [cfg.field]: amount, active: true });
    auditSet(batch, ctx, `${cfg.singular}.create`, cfg.singular, ref.id, { name, [cfg.field]: amount });
    try { await batch.commit(); f.reset(); msg.className = 'muted'; msg.textContent = 'Added.'; refresh(); }
    catch { msg.textContent = 'Could not save. Try again.'; }
  };
  refresh();
}

// ---------- Fees: change doctor fees and service prices, with history in the audit log ----------
export async function feesPage(c, ctx) {
  c.innerHTML = '<p class="muted">Loading…</p>';
  let doctors, services;
  try {
    await syncPriceList(ctx);
    [doctors, services] = await Promise.all([list('doctors'), list('services')]);
  } catch { c.innerHTML = '<div class="card error">Could not load fees.</div>'; return; }
  const byName = (a, b) => a.name.localeCompare(b.name);
  const table = (title, items, key) => `<div class="card"><h2>${title}</h2>${items.length
    ? `<table><thead><tr><th>Name</th><th>Status</th><th class="right">Current</th><th>New amount</th><th></th></tr></thead><tbody>
      ${items.sort(byName).map((i) => `<tr data-key="${key}" data-id="${esc(i.id)}">
        <td>${esc(i.name)}</td><td><span class="pill ${i.active ? 'on' : 'off'}">${i.active ? 'Active' : 'Inactive'}</span></td>
        <td class="right">${money(i[CFG[key].field])}</td>
        <td><input class="num-in" inputmode="decimal" value="${esc(i[CFG[key].field])}" data-amt></td>
        <td><button class="btn small" data-save>Save</button></td></tr>`).join('')}</tbody></table>`
    : '<p class="muted">Nothing to show yet. Add items first.</p>'}</div>`;
  c.innerHTML = table('Doctor consultation fees', doctors, 'doctors') + table('Service prices', services, 'services')
    + '<div id="msg" class="error"></div>';
  const msg = $('#msg', c);
  c.querySelectorAll('tr[data-id]').forEach((tr) => {
    const key = tr.dataset.key;
    const cfg = CFG[key];
    const item = (key === 'doctors' ? doctors : services).find((x) => x.id === tr.dataset.id);
    $('[data-save]', tr).onclick = async () => {
      const amount = parseAmount($('[data-amt]', tr).value, true);
      if (amount === null) { msg.textContent = 'Enter a valid amount, for example 500 or 500.50.'; return; }
      if (amount === item[cfg.field]) { msg.textContent = 'No change to save.'; return; }
      try {
        await updateItem(ctx, cfg, item, { [cfg.field]: amount }, `${cfg.singular}.${cfg.field}.change`);
        feesPage(c, ctx);
      } catch { msg.textContent = 'Could not save. Try again.'; }
    };
  });
}

// ---------- Settings: hospital details, payment methods, receptionist limits ----------
export async function settingsPage(c, ctx) {
  c.innerHTML = '<p class="muted">Loading…</p>';
  let hospital, methods, receptionists, limits;
  try {
    [hospital, methods, receptionists, limits] = await Promise.all([
      getHospital(), list('paymentMethods'), list('users', where('role', '==', 'receptionist')), list('staffLimits'),
    ]);
  } catch { c.innerHTML = '<div class="card error">Could not load settings.</div>'; return; }
  methods.sort((a, b) => a.name.localeCompare(b.name));
  receptionists.sort((a, b) => a.username.localeCompare(b.username));
  const lim = (uid) => limits.find((l) => l.id === uid) || { maxDiscountPercent: 0, maxDiscountFixed: 0, canCashOut: false, cashOutLimit: 0 };

  c.innerHTML = `
    <div class="card"><h2>Hospital details</h2>
      <form id="hf" class="grid2">
        <label>Hospital name<input name="hospitalName" required minlength="2" maxlength="100" value="${esc(hospital.hospitalName)}"></label>
        <label>Phone<input name="phone" maxlength="40" value="${esc(hospital.phone)}"></label>
        <label>Address<input name="address" maxlength="200" value="${esc(hospital.address)}"></label>
        <label>Currency label (for example Rs)<input name="currency" maxlength="8" value="${esc(hospital.currency)}"></label>
        <div class="row-end"><span id="hmsg" class="muted"></span><button class="btn primary">Save details</button></div>
      </form></div>

    <div class="card"><h2>Payment methods</h2>
      <form id="mf" class="row-gap" style="margin-bottom:12px">
        <input name="name" class="inline" style="max-width:240px" placeholder="Name, for example Cash" required minlength="2" maxlength="40" autocomplete="off">
        <label style="margin:0;font-weight:400"><input type="checkbox" name="isCash" style="display:inline;width:auto;margin:0 6px 0 0">Physical cash</label>
        <button class="btn primary">Add method</button><span id="mmsg" class="error"></span>
      </form>
      ${methods.length ? `<table><thead><tr><th>Name</th><th>Type</th><th>Status</th><th></th></tr></thead><tbody>
        ${methods.map((m) => `<tr data-mid="${esc(m.id)}"><td>${esc(m.name)}</td><td>${m.isCash ? 'Physical cash' : 'Card / bank / wallet'}</td>
          <td><span class="pill ${m.active ? 'on' : 'off'}">${m.active ? 'Active' : 'Inactive'}</span></td>
          <td><button class="btn small" data-mt>${m.active ? 'Deactivate' : 'Activate'}</button></td></tr>`).join('')}</tbody></table>`
        : '<p class="muted">No payment methods yet. Add at least one (for example Cash).</p>'}</div>

    <div class="card"><h2>Receptionist limits</h2>
      <p class="muted">Discount limits and Cash Out permission for each receptionist. Leave at 0 to allow none.</p>
      ${receptionists.length ? `<table><thead><tr><th>Receptionist</th><th>Max discount %</th><th>Max fixed discount</th><th>Cash Out</th><th>Cash Out limit</th><th></th></tr></thead><tbody>
        ${receptionists.map((r) => { const l = lim(r.id); return `<tr data-uid="${esc(r.id)}">
          <td>${esc(r.displayName)} <span class="muted">(${esc(r.username)})</span></td>
          <td><input class="num-in" inputmode="decimal" value="${esc(l.maxDiscountPercent)}" data-pct></td>
          <td><input class="num-in" inputmode="decimal" value="${esc(l.maxDiscountFixed)}" data-fix></td>
          <td><input type="checkbox" data-co ${l.canCashOut ? 'checked' : ''} style="width:auto;margin:0"></td>
          <td><input class="num-in" inputmode="decimal" value="${esc(l.cashOutLimit)}" data-col></td>
          <td><button class="btn small" data-ls>Save</button></td></tr>`; }).join('')}</tbody></table><div id="lmsg" class="error"></div>`
        : '<p class="muted">No receptionists yet.</p>'}</div>`;

  // Hospital details
  $('#hf', c).onsubmit = async (e) => {
    e.preventDefault();
    const f = e.target;
    const data = {
      hospitalName: f.hospitalName.value.trim(), address: f.address.value.trim(),
      phone: f.phone.value.trim(), currency: f.currency.value.trim(),
    };
    const batch = writeBatch(db);
    batch.set(doc(db, 'settings', 'hospital'), { ...data, updatedAt: serverTimestamp(), updatedBy: ctx.uid });
    auditSet(batch, ctx, 'settings.hospital.update', 'settings', 'hospital', { before: hospital, after: data });
    const m = $('#hmsg', c);
    try { await batch.commit(); m.className = 'muted'; m.textContent = 'Saved.'; getHospital(); }
    catch { m.className = 'error'; m.textContent = 'Could not save. Try again.'; }
  };

  // Payment methods
  $('#mf', c).onsubmit = async (e) => {
    e.preventDefault();
    const f = e.target;
    const name = f.name.value.trim();
    const m = $('#mmsg', c);
    if (methods.some((x) => x.name.toLowerCase() === name.toLowerCase())) { m.textContent = 'That method already exists.'; return; }
    const ref = doc(collection(db, 'paymentMethods'));
    const batch = writeBatch(db);
    batch.set(ref, { name, isCash: f.isCash.checked, active: true, createdAt: serverTimestamp(), createdBy: ctx.uid });
    auditSet(batch, ctx, 'paymentMethod.create', 'paymentMethod', ref.id, { name, isCash: f.isCash.checked });
    try { await batch.commit(); settingsPage(c, ctx); } catch { m.textContent = 'Could not save. Try again.'; }
  };
  c.querySelectorAll('tr[data-mid]').forEach((tr) => {
    const m = methods.find((x) => x.id === tr.dataset.mid);
    $('[data-mt]', tr).onclick = async () => {
      const batch = writeBatch(db);
      batch.update(doc(db, 'paymentMethods', m.id), { active: !m.active, updatedAt: serverTimestamp(), updatedBy: ctx.uid });
      auditSet(batch, ctx, m.active ? 'paymentMethod.deactivate' : 'paymentMethod.activate', 'paymentMethod', m.id, { name: m.name });
      try { await batch.commit(); settingsPage(c, ctx); } catch { $('#mmsg', c).textContent = 'Could not save. Try again.'; }
    };
  });

  // Receptionist limits
  c.querySelectorAll('tr[data-uid]').forEach((tr) => {
    $('[data-ls]', tr).onclick = async () => {
      const uid = tr.dataset.uid;
      const pct = parseAmount($('[data-pct]', tr).value, true);
      const fix = parseAmount($('[data-fix]', tr).value, true);
      const col = parseAmount($('[data-col]', tr).value, true);
      const msg = $('#lmsg', c);
      if (pct === null || pct > 100) { msg.textContent = 'Max discount % must be between 0 and 100.'; return; }
      if (fix === null || col === null) { msg.textContent = 'Enter valid amounts.'; return; }
      const canCashOut = $('[data-co]', tr).checked;
      const data = { maxDiscountPercent: pct, maxDiscountFixed: fix, canCashOut, cashOutLimit: col };
      const batch = writeBatch(db);
      batch.set(doc(db, 'staffLimits', uid), { ...data, updatedAt: serverTimestamp(), updatedBy: ctx.uid });
      auditSet(batch, ctx, 'staffLimits.update', 'user', uid, { before: lim(uid), after: data });
      try { await batch.commit(); msg.className = 'muted'; msg.textContent = 'Saved.'; limits = [...limits.filter((l) => l.id !== uid), { id: uid, ...data }]; }
      catch { msg.className = 'error'; msg.textContent = 'Could not save. Try again.'; }
    };
  });
}
