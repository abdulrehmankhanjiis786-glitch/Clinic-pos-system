import { collection, getDocs, query, orderBy, limit, where, doc, writeBatch, serverTimestamp, Timestamp } from 'firebase/firestore';
import { initializeApp, deleteApp } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword, signOut } from 'firebase/auth';
import { db, firebaseConfig } from '../firebase.js';
import { toEmail, auditData } from '../auth.js';
import { checkUsername } from '../validation.js';
import { mountShell } from '../shell.js';
import { esc, $, fmtTime } from '../util.js';
import { list, money, round2 } from '../data.js';
import { catalogPage, feesPage, settingsPage } from './catalog.js';
import { balancesPage } from './balances.js';
import { cashAdminPage } from './cash.js';
import { adminShiftsPage } from './shift.js';
import { cancelledPage } from './cancellations.js';
import { slipsPage } from './slips.js';
import { approvalsPage } from './approvals.js';
import { securityPage } from './security.js';

let myUid = null;

// Creates the sign-in with a temporary second app connection, so the Admin
// stays signed in, then saves the profile + audit entry together.
// Admin can only create Receptionist accounts. Developer accounts are not managed here.
async function createStaff(f) {
  const problem = checkUsername(f.username);
  if (problem) throw new Error(problem);
  const username = f.username.toLowerCase();
  if (f.password.length < 10) throw new Error('Password must be at least 10 characters.');
  const tmp = initializeApp(firebaseConfig, 'tmp-' + Date.now());
  let uid;
  try {
    const a = getAuth(tmp);
    const cred = await createUserWithEmailAndPassword(a, toEmail(username), f.password);
    uid = cred.user.uid;
    await signOut(a);
  } catch (e) {
    if (e.code === 'auth/email-already-in-use') throw new Error('That username is already taken.');
    throw new Error('Could not create the sign-in. Check the details and try again.');
  } finally {
    await deleteApp(tmp);
  }
  const batch = writeBatch(db);
  batch.set(doc(db, 'users', uid), {
    username, displayName: f.displayName.trim(), role: 'receptionist', recoveryEmail: f.recoveryEmail.trim().toLowerCase(),
    disabled: false, createdAt: serverTimestamp(), createdBy: myUid,
  });
  batch.set(doc(collection(db, 'auditLogs')), auditData(myUid, 'admin', 'user.create', 'user', uid, { newRole: 'receptionist', username }));
  try { await batch.commit(); }
  catch { throw new Error('The sign-in was created but the profile was not saved. Use a different username and try again.'); }
}

async function setRecoveryEmail(uid, email) {
  const batch = writeBatch(db);
  batch.update(doc(db, 'users', uid), { recoveryEmail: email });
  batch.set(doc(collection(db, 'auditLogs')), auditData(myUid, 'admin', 'user.recoveryEmail.update', 'user', uid));
  await batch.commit();
}

async function setDisabled(uid, disabled) {
  const batch = writeBatch(db);
  batch.update(doc(db, 'users', uid), { disabled });
  batch.set(doc(collection(db, 'auditLogs')), auditData(myUid, 'admin', disabled ? 'user.disable' : 'user.enable', 'user', uid));
  await batch.commit();
}

export function renderAdmin(root, name, uid) {
  myUid = uid;
  const ctx = { uid, name, role: 'admin' };
  mountShell(root, {
    brand: 'Clinic POS',
    roleLabel: 'Admin',
    name,
    nav: [
      { id: 'dashboard', label: 'Dashboard' },
      { id: 'slips', label: "Today's Slips" },
      { id: 'staff', label: 'Receptionists' },
      { id: 'doctors', label: 'Doctors' },
      { id: 'services', label: 'Services' },
      { id: 'fees', label: 'Fees' },
      { id: 'outstanding', label: 'Outstanding Balances' },
      { id: 'cash', label: 'Cash Transactions' },
      { id: 'shifts', label: 'Shift Reports' },
      { id: 'cancelled', label: 'Cancelled Slips' },
      { id: 'approvals', label: 'Discount Approvals' },
      { id: 'audit', label: 'Audit Logs' },
      { id: 'settings', label: 'Settings' },
      { id: 'security', label: 'Security & Backup' },
    ],
    pages: {
      dashboard,
      staff,
      audit,
      doctors: (c) => catalogPage(c, ctx, 'doctors'),
      services: (c) => catalogPage(c, ctx, 'services'),
      fees: (c) => feesPage(c, ctx),
      settings: (c) => settingsPage(c, ctx),
      outstanding: (c) => balancesPage(c, ctx),
      cash: (c) => cashAdminPage(c, ctx),
      shifts: (c) => adminShiftsPage(c, ctx),
      cancelled: (c) => cancelledPage(c, ctx),
      slips: (c) => slipsPage(c, ctx),
      approvals: (c) => approvalsPage(c, ctx),
      security: (c) => securityPage(c, ctx),
    },
  });
}

// Hospital staff only. Developer accounts are never requested or shown here
// (the security rules also refuse to return them).
async function loadUsers() {
  const [admins, recs] = await Promise.all([
    list('users', where('role', '==', 'admin')),
    list('users', where('role', '==', 'receptionist')),
  ]);
  return recs.map((u) => ({ uid: u.id, ...u })).concat(admins.map((u) => ({ uid: u.id, ...u })));
}

async function dashboard(c) {
  c.innerHTML = '<p class="muted">Loading…</p>';
  try {
    const start = Timestamp.fromDate(new Date(new Date().setHours(0, 0, 0, 0)));
    const [users, open, bills, pays, owing, cancelled] = await Promise.all([
      loadUsers(), list('openShifts'), list('bills', where('createdAt', '>=', start)), list('payments', where('createdAt', '>=', start)),
      list('bills', where('outstanding', '>', 0)), list('bills', where('cancelledAt', '>=', start)),
    ]);
    const sum = (arr, f) => round2(arr.reduce((t, x) => t + (Number(f(x)) || 0), 0));
    const activeRecs = users.filter((u) => u.role === 'receptionist' && !u.disabled).length;
    const card = (n, label) => `<div class="card stat"><span class="num">${n}</span><span>${label}</span></div>`;
    c.innerHTML = `<div class="cards">
      ${card(money(sum(bills.filter((b) => b.status === 'posted'), (b) => b.net)), "Today's total billing")}
      ${card(money(sum(bills, (b) => b.initialPaid) + sum(pays, (p) => p.amount)), 'Payments received today')}
      ${card(money(sum(owing.filter((b) => b.status === 'posted'), (b) => b.outstanding)), 'Outstanding balance')}
      ${card(activeRecs, 'Active receptionists')}
      ${card(open.length, 'Open shifts')}
      ${card(cancelled.length, 'Cancelled receipts today')}</div>`;
  } catch {
    c.innerHTML = '<div class="card error">Could not load data. Check your connection and rules.</div>';
  }
}

async function staff(c) {
  c.innerHTML = `
    <div class="card"><h2>Add receptionist</h2>
      <form id="f" class="grid2">
        <label>Username<input name="username" required minlength="3" maxlength="30" pattern="[A-Za-z0-9._\\-]{3,30}"
          title="3-30 characters: letters, numbers, dot, dash or underscore. No spaces." autocomplete="off"></label>
        <label>Full name<input name="displayName" required autocomplete="off"></label>
        <label>Recovery email<input name="recoveryEmail" type="email" required autocomplete="off"></label>
        <label>Temporary password (10+ characters)<input name="password" type="password" minlength="10" required autocomplete="new-password"></label>
        <div class="row-end"><span id="msg" class="muted"></span><button class="btn primary">Create account</button></div>
      </form></div>
    <div class="card"><h2>Accounts</h2><div id="list" class="muted">Loading…</div></div>`;

  const list_ = $('#list', c);
  async function refresh() {
    try {
      const users = (await loadUsers()).sort((a, b) => a.username.localeCompare(b.username));
      list_.className = '';
      list_.innerHTML = `<table><thead><tr><th>Username</th><th>Name</th><th>Role</th><th>Recovery email</th><th>Status</th><th></th></tr></thead>
        <tbody>${users.map((u) => `<tr>
          <td>${esc(u.username)}</td><td>${esc(u.displayName)}</td><td>${esc(u.role)}</td><td>${esc(u.recoveryEmail)}</td>
          <td><span class="pill ${u.disabled ? 'off' : 'on'}">${u.disabled ? 'Disabled' : 'Active'}</span></td>
          <td class="row-gap">${u.role === 'admin' ? '' : `<button class="btn small" data-uid="${esc(u.uid)}" data-dis="${!u.disabled}">${u.disabled ? 'Enable' : 'Disable'}</button>
            <button class="btn small" data-mail="${esc(u.uid)}">Recovery email</button>`}</td>
        </tr>`).join('')}</tbody></table>`;
      list_.querySelectorAll('button[data-uid]').forEach((b) => {
        b.onclick = async () => {
          b.disabled = true;
          try { await setDisabled(b.dataset.uid, b.dataset.dis === 'true'); }
          catch (e) { alert(e.message); }
          refresh();
        };
      });
      list_.querySelectorAll('button[data-mail]').forEach((b) => {
        b.onclick = async () => {
          const email = (prompt('New recovery email for this receptionist:') || '').trim().toLowerCase();
          if (!email) return;
          if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) { alert('Enter a valid email address.'); return; }
          try { await setRecoveryEmail(b.dataset.mail, email); refresh(); } catch { alert('Could not save. Try again.'); }
        };
      });
    } catch {
      list_.innerHTML = '<span class="error">Could not load accounts.</span>';
    }
  }

  $('#f', c).onsubmit = async (e) => {
    e.preventDefault();
    const f = e.target;
    const msg = $('#msg', c);
    msg.className = 'muted';
    msg.textContent = 'Creating…';
    try {
      await createStaff({
        username: f.username.value, displayName: f.displayName.value,
        recoveryEmail: f.recoveryEmail.value, password: f.password.value,
      });
      f.reset();
      msg.textContent = 'Account created.';
      refresh();
    } catch (ex) {
      msg.className = 'error';
      msg.textContent = ex.message || 'Could not create the account.';
    }
  };
  refresh();
}

async function audit(c) {
  c.innerHTML = '<div class="card"><h2>Latest 50 events</h2><div id="a" class="muted">Loading…</div></div>';
  try {
    const q = (role) => getDocs(query(collection(db, 'auditLogs'), where('role', '==', role), orderBy('createdAt', 'desc'), limit(50)));
    const [users, a, r] = await Promise.all([loadUsers(), q('admin'), q('receptionist')]);
    const known = new Set(users.map((u) => u.uid));
    const rows = [...a.docs, ...r.docs].map((d) => ({ id: d.id, ...d.data() }))
      // Entries about a user account are shown only for hospital staff accounts.
      .filter((x) => x.entityType !== 'user' || known.has(x.entityId))
      .sort((x, y) => (y.createdAt?.seconds || 0) - (x.createdAt?.seconds || 0))
      .slice(0, 50);
    $('#a', c).className = '';
    $('#a', c).innerHTML = rows.length
      ? `<table><thead><tr><th>Time</th><th>Action</th><th>Role</th><th>Item</th></tr></thead><tbody>${rows.map((x) =>
          `<tr><td>${esc(fmtTime(x.createdAt))}</td><td>${esc(x.action)}</td><td>${esc(x.role)}</td>
           <td>${esc(x.entityType)} ${esc(x.entityId)}</td></tr>`).join('')}</tbody></table>`
      : 'No events yet.';
  } catch {
    $('#a', c).innerHTML = '<span class="error">Could not load the audit log.</span>';
  }
}
