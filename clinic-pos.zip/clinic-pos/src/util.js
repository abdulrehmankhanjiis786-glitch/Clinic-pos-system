export const esc = (s) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const $ = (sel, root = document) => root.querySelector(sel);
export const fmtTime = (ts) => (ts && ts.toDate ? ts.toDate().toLocaleString() : '');

// Prints a small HTML document (used for receipts and reports) without leaving the page.
export function printHtml(html) {
  const f = document.createElement('iframe');
  f.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0';
  document.body.appendChild(f);
  const d = f.contentWindow.document;
  d.open();
  d.write(html);
  d.close();
  setTimeout(() => { f.contentWindow.focus(); f.contentWindow.print(); }, 150);
  setTimeout(() => f.remove(), 60000);
}

// ---------- Keyboard shortcuts ----------
// Only modifier combinations (Alt+..., Ctrl+...) are registered, so typing is never disturbed.
// Ctrl+Shift+Alt is reserved for the hidden Developer login (handled in main.js).
let baseMap = {};
let pageMap = {};
const keyName = (e) =>
  (e.ctrlKey ? 'Ctrl+' : '') + (e.altKey ? 'Alt+' : '') + (e.shiftKey ? 'Shift+' : '') +
  (e.code && e.code.startsWith('Key') ? e.code.slice(3) : e.key);
window.addEventListener('keydown', (e) => {
  if (e.ctrlKey && e.shiftKey && e.altKey) return;
  const name = keyName(e);
  const fn = pageMap[name] || baseMap[name];
  if (fn) { e.preventDefault(); fn(e); }
});
export const setBaseShortcuts = (m) => { baseMap = m || {}; };
export const setPageShortcuts = (m) => { pageMap = m || {}; };

// ---------- Popup (Esc closes it) ----------
export function modal(html) {
  const o = document.createElement('div');
  o.className = 'modal-bg';
  o.innerHTML = `<div class="modal" role="dialog" aria-modal="true">${html}</div>`;
  document.body.appendChild(o);
  const onKey = (e) => { if (e.key === 'Escape') { e.stopPropagation(); close(); } };
  const close = () => { o.remove(); window.removeEventListener('keydown', onKey, true); };
  window.addEventListener('keydown', onKey, true);
  return { el: o, close };
}
