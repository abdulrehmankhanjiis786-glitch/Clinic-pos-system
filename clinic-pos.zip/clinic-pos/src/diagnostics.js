// Records unexpected browser errors so the Developer can see them (no patient data is included).
import { addDoc, collection, serverTimestamp } from 'firebase/firestore';
import { auth, db } from './firebase.js';
import { getProfile } from './auth.js';

let sent = 0;
let role = null;
export function installErrorCapture() {
  const send = async (message, source) => {
    if (sent >= 5 || !auth.currentUser) return; // at most 5 per page load
    sent += 1;
    try {
      role = role || (await getProfile(auth.currentUser.uid))?.role;
      await addDoc(collection(db, 'errorLogs'), {
        uid: auth.currentUser.uid, role, message: String(message).slice(0, 300), source: String(source || '').slice(0, 100),
        createdAt: serverTimestamp(),
      });
    } catch { /* never throw from the error handler */ }
  };
  window.addEventListener('error', (e) => send(e.message, `${e.filename || ''}:${e.lineno || ''}`));
  window.addEventListener('unhandledrejection', (e) => send(e.reason?.message || e.reason || 'Unhandled promise rejection', 'promise'));
}
