# Tests to do on the real system (write down each result: PASS / FAIL / what you saw)

Use two browsers (or private windows): Admin and Receptionist. First run the offline checks in the Codespace:
`node scripts/selftest.mjs && node scripts/shifttest.mjs && node scripts/rulestest.mjs`.

## Accounts and roles
1. Receptionist sees only the POS; Admin only the admin screens. A receptionist cannot open admin pages by typing addresses.
2. The system account is not listed anywhere for Admin (receptionist list, dashboard, reports, backup). The word "Developer" appears nowhere after sign-in as Admin or Receptionist.
3. Ctrl+Shift+Alt+D on the sign-in page opens the technical sign-in (Esc goes back). It asks for the security code. The normal form rejects that account.
4. Disable a receptionist who is signed in: their open screen keeps working; after sign-out they cannot sign in. Enable again: they can.
5. Usernames: "ali khan", " ali", "al", "ali!" are rejected; "ali.k-1_x" is accepted.

## Billing
6. No open shift: New Slip, Cash and balance payments say so. After opening the shift they work, also after a refresh and a sign-out / sign-in.
7. Doctor selection loads the fee; a fixed fee cannot be changed; a negotiable fee can only be changed inside the allowed range and only with the permission.
8. A service with 3 prices shows P1 / P2 / P3; the chosen price appears on the slip. A fixed service rate cannot be changed; a negotiable one only inside its range with permission.
9. Discounts: without permission the discount boxes are off; above the limit the slip is refused with a clear message.
10. Partial payment: balance = total - paid; overpayment shows change. Double-click Post: one slip only. Receipt numbers rise by one for that receptionist.
11. Post saves only; Print posts and prints; Print again never makes a second slip. Switch the printer off: the slip is still saved.
12. Hold, close the browser, sign in again: unsaved slips are back as tabs; held slips are under Held. Logout with held slips is blocked until they are removed.
13. Complimentary (with permission): net 0, no cash, listed under Complimentary and on the Till Close Report.

## Outstanding, cash, cancel
14. Receive a balance: payment reference, receipt, balance drops, shift report lists it. More than the balance is refused. Another receptionist's balance only with that permission.
15. Cash In / Cash Out get automatic references and cannot be changed. Cash Out above the limit or without permission is refused.
16. Cancel a slip of the open shift with a reason and a refund: the till shows the refund. After the shift is closed, Cancel is refused. Restore needs a reason and an open shift.

## Offline
17. Disconnect the internet: the top bar says "Internet connection unavailable. Your data will sync automatically when the internet is restored." Post slips, hold, take a balance payment, Cash In. Reconnect: they appear in Admin reports with their own numbers, no duplicates.
18. Offline, Cancel / Refund / closing the shift say that the internet is needed.

## Shifts and reports
19. Close the shift: expected cash, counted cash, difference, signatures; the report prints. Admin sees it in Shift / Till Reports and can reopen only with a reason.
20. Reports load one page at a time ("Load more"); search by receipt number and by patient name works; the dashboard tiles open the matching report.

## Direct-access tests (security rules; use F12 console)
21. As Receptionist try to edit a posted slip, delete a slip or a cash entry, change your own permissions, read another user: all refused.
22. Signed out, or as the system account, try to read any slip, shift or cash entry: refused.

## Backup
23. Download a manual backup; run the daily backup once from GitHub Actions; do one restore preview (BACKUP_RESTORE.md).
