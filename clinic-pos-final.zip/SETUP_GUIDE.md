# Setup / update guide ($0, Chromebook, no installs)

**[YOU]** = needs your own account. Never share passwords, keys, codes or backup files with anyone. If a screen asks you to upgrade or add a card, close it.

## A. You already have the project running: update it (one block)
1. Upload `clinic-pos-final.zip` to the Codespace (drag it into the file list) and extract it over the project. It does not contain `.env` or `.firebaserc`, so yours stay.
2. In the Codespace terminal run this one block:
```
unzip -o clinic-pos-final.zip && rm clinic-pos-final.zip && npm run build && npx firebase-tools deploy --only firestore,hosting
```
3. Wait about 5 minutes (the new database indexes build in the background).
4. Sign in as **Admin** once. The app then upgrades itself: it builds the price list, gives every receptionist a receipt code and converts their permissions
   (nothing is deleted). Then open **Permissions** and check each receptionist.
5. Hard refresh the site once (Ctrl+Shift+R).

## B. First-time setup (new installation)
1. GitHub: new **private** repository; upload the project; make sure no `.env` file is in it.  [YOU]
2. Codespace: Code > Codespaces > Create. Terminal: `npm install` then `cp .env.example .env`.
3. Firebase console (stay on Spark):  [YOU]
   - Project settings > Your apps > web `</>`: copy the config values into `.env`.
   - Authentication > Get started > Email/Password > Enable.
   - Firestore Database > Create database > production mode, nearby location.
4. `npx firebase-tools login --no-localhost`, then `npx firebase-tools use --add` (choose your project).
5. Create the first Admin by hand:  [YOU] Authentication > Users > Add user (`name@clinicpos.local` + strong password; copy the UID). Firestore > start collection `users`,
   document ID = the UID, fields: `username`, `displayName`, `role` = `admin`, `recoveryEmail`, `disabled` = false (**boolean**).
6. The technical account (optional): the same way with `role` = `developer`. Admins can never see or manage it. Sign in with Ctrl+Shift+Alt+D on the sign-in page; the first time you choose a security code.
7. `npm run build` and `npx firebase-tools deploy --only firestore,hosting`. The site is `https://YOUR-PROJECT-ID.web.app`.

## C. First use (Admin)
Settings (currency, receipt prefix) · Payment Methods (add Cash, tick Physical cash) · Doctors · Services · Lab / Tests · Receptionists · Permissions.
The system account enters the hospital heading, address, footer, logo and the print paper size (Hospital & printing).

## D. Reset a forgotten receptionist password
Receptionists can change their own password (top bar). For a forgotten one: `FIREBASE_SERVICE_ACCOUNT='<json>' node scripts/reset-password.mjs <username>` (service account steps are in BACKUP_RESTORE.md).

## E. Optional: App Check (free)
Register the web app under App Check with reCAPTCHA v3, put the site key in `.env` as `VITE_RECAPTCHA_SITE_KEY`, rebuild and redeploy; watch the metrics for a day before pressing Enforce.

## F. Backups
See BACKUP_RESTORE.md (Admin > Backup for the manual download; GitHub Actions for the daily one).
