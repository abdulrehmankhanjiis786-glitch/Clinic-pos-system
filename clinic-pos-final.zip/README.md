# Clinic POS & Hospital Management System

Desktop-first web app for hospital reception billing. Plain JavaScript (Vite) on the free Firebase Spark plan
(Authentication + Cloud Firestore + Hosting). No Cloud Functions, no Cloud Storage, no payment method.

## What it does

- **Receptionist POS:** icon rail on the left, invoice in the centre, patient panel on the right. Patient name / age / gender (M or F fills the word), doctor
  with fee, services and lab tests with up to 5 price options, line discounts, paid / balance / change, Post, Print (posts then prints), Hold,
  held invoices, invoice tabs that survive a closed browser, Today's Slips, search, cancel / refund / restore, complimentary slips,
  outstanding balances and payment receipts, Cash In / Cash Out, shift opening and closing with the Till Close Report, Shortcut Help.
- **Offline-first:** slips, hold, balance payments and cash entries keep working without internet and sync by themselves. Cancel and refund need the internet.
- **Admin:** live dashboard (till, slips, outstanding, cancelled, complimentary, online status), reports with their own filters, doctors (profile, fixed / negotiable fee),
  services and lab tests (1-5 prices, fixed / negotiable), payment methods, per-receptionist permissions and limits, receptionists, shortcuts, receipt prefix, backups.
- **System account (separate, hidden from Admin):** hospital heading / address / footer / logo, print format, licence and expiry, installation IDs, version and updates,
  configuration export / import, error log. Opened with **Ctrl + Shift + Alt + D** on the sign-in page.

## Status

| Area | Written | Automatic checks | Run against Firebase |
|---|---|---|---|
| Everything above | Yes | Syntax, imports, billing maths, "why was my slip refused", app-versus-rules field names and arithmetic (see scripts/) | **No** (not possible where this was written) |
| Production build | - | **Not run** (no internet where this was written) | - |

Run `node scripts/selftest.mjs`, `node scripts/shifttest.mjs` and `node scripts/rulestest.mjs` any time (no Firebase needed).
Then follow SECURITY_TESTING.md on the real system before relying on it.

## Free-plan limits (what cannot be done at $0, and what is done instead)

| Requirement | Why not | Instead |
|---|---|---|
| Server-side validation | Cloud Functions need a paid plan | The Firestore security rules re-check prices, price option, negotiable ranges, discounts, permissions, totals, payments, shifts and numbering on every save |
| Email OTP password recovery | Needs a server and an email sender | Receptionists change their own password in the app; a forgotten one is reset with `scripts/reset-password.mjs`; the Admin can use Firebase's free reset email if signing in with a real email address |
| Developer MFA | Needs a paid plan | Password + a security code + 15-minute idle sign-out; no access to patient or money data |
| Separate database per hospital | One free Firebase project = one database | Each hospital gets its own free Firebase project; the Installations screen creates the IDs and a package to import |
| Enforced licence | No server | The rules refuse new slips, payments and cash entries when a "block" licence has expired; a "warn" licence only shows a message |
| Scheduled managed backups | Needs billing | Daily GitHub Actions backup (encrypted, kept 30 days) + manual download |
| Daily quota | Free plan | 50,000 reads and 20,000 writes per day; the app uses targeted queries, totals counted on the server, pagination and cached settings to stay far below |

## Folder map

`src/` app · `firestore.rules` and `firestore.indexes.json` · `scripts/` tests, backup, restore, reset-password · `.github/workflows/` daily backup ·
`SETUP_GUIDE.md` · `BACKUP_RESTORE.md` · `SECURITY_TESTING.md`
