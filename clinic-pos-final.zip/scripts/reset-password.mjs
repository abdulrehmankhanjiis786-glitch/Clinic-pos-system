// Sets a new password for a receptionist who forgot it (the only thing the browser cannot do).
//   FIREBASE_SERVICE_ACCOUNT='<service-account JSON text>' node scripts/reset-password.mjs <username>
// The new password is typed when asked and is never stored in a file. Run it yourself on a trusted computer.
import { createInterface } from 'node:readline/promises';
import { initializeApp, cert } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';

const username = (process.argv[2] || '').trim().toLowerCase();
if (!/^[a-z0-9._-]{3,30}$/.test(username)) { console.error('Usage: node scripts/reset-password.mjs <username>'); process.exit(1); }
if (!process.env.FIREBASE_SERVICE_ACCOUNT) { console.error('FIREBASE_SERVICE_ACCOUNT is not set.'); process.exit(1); }
initializeApp({ credential: cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT)) });
const rl = createInterface({ input: process.stdin, output: process.stdout });
const pw = await rl.question(`New password for ${username} (10+ characters): `);
rl.close();
if (pw.length < 10) { console.error('Too short.'); process.exit(1); }
const u = await getAuth().getUserByEmail(`${username}@clinicpos.local`);
await getAuth().updateUser(u.uid, { password: pw });
await getAuth().revokeRefreshTokens(u.uid);
console.log('Password changed. The receptionist can sign in with the new password.');
