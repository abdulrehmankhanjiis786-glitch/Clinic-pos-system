// Logic self-test (no Firebase needed):  node scripts/selftest.mjs
import assert from 'node:assert/strict';
import { computeBill, normService, normDoctor, rowDiscount, makeNumber, parseMoney, billRows, round2 } from '../src/calc.js';

const look = (k, id) => ({ name: id });
let n = 0; const t = (name, fn) => { fn(); n++; console.log('ok -', name); };

t('old service becomes Price 1, fixed', () => {
  const s = normService({ name: 'Dressing', price: 100, active: true });
  assert.deepEqual(s.options, [100]); assert.equal(s.mode, 'fixed'); assert.equal(s.min, 100);
});
t('service with 3 prices', () => {
  const s = normService({ name: 'Dressing', price: 100, priceOptions: [100, 150, 200], priceMode: 'negotiable', minRate: 90, maxRate: 220 });
  assert.equal(s.options[1], 150); assert.equal(s.mode, 'negotiable'); assert.equal(s.max, 220);
});
t('old doctor is fixed', () => { const d = normDoctor({ name: 'A', fee: 500 }); assert.equal(d.mode, 'fixed'); assert.equal(d.min, 500); });
t('discounts', () => {
  assert.equal(rowDiscount(200, 'percent', 10), 20); assert.equal(rowDiscount(200, 'fixed', 500), 200); assert.equal(rowDiscount(200, 'none', 9), 0);
});
t('bill totals, partial payment', () => {
  const b = computeBill({ rows: [
    { kind: 'doctor', refId: 'd', option: 0, rate: 500, qty: 1, discType: 'none', discValue: 0 },
    { kind: 'service', refId: 's', option: 2, rate: 150, qty: 2, discType: 'percent', discValue: 10 }], paid: 600, comp: false }, look);
  assert.equal(b.gross, 800); assert.equal(b.discount, 30); assert.equal(b.net, 770); assert.equal(b.initialPaid, 600);
  assert.equal(b.outstanding, 170); assert.equal(b.change, 0);
});
t('overpayment gives change', () => {
  const b = computeBill({ rows: [{ kind: 'service', refId: 's', option: 1, rate: 100, qty: 1, discType: 'none', discValue: 0 }], paid: 150 }, look);
  assert.equal(b.initialPaid, 100); assert.equal(b.change, 50); assert.equal(b.outstanding, 0);
});
t('complimentary is free and takes no money', () => {
  const b = computeBill({ rows: [{ kind: 'service', refId: 's', option: 1, rate: 100, qty: 3, discType: 'none', discValue: 0 }], paid: 500, comp: true }, look);
  assert.equal(b.compAmount, 300); assert.equal(b.net, 0); assert.equal(b.initialPaid, 0); assert.equal(b.outstanding, 0);
});
t('rounding stays at 2 decimals', () => {
  const b = computeBill({ rows: [{ kind: 'service', refId: 's', option: 1, rate: 33.33, qty: 3, discType: 'percent', discValue: 7 }], paid: 0 }, look);
  assert.equal(b.gross, 99.99); assert.equal(b.discount, 7); assert.equal(round2(b.net + b.discount), b.gross);
});
t('receipt numbers', () => { assert.equal(makeNumber('R', 'K3F9', 12), 'RK3F9-000012'); });
t('money parsing', () => {
  assert.equal(parseMoney('12.5'), 12.5); assert.equal(parseMoney('abc'), null); assert.equal(parseMoney('0'), null); assert.equal(parseMoney('0', true), 0);
});
t('legacy bill rows', () => {
  const r = billRows({ doctorId: 'd', doctorName: 'Dr A', doctorFee: 400, items: [{ name: 'X', price: 50, qty: 2, lineTotal: 100 }] });
  assert.equal(r.length, 2); assert.equal(r[1].lineTotal, 100);
});
console.log(`\n${n} checks passed`);
