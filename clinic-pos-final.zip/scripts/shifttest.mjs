// Tests the "why was my slip refused?" logic with made-up records (no Firebase needed):  node scripts/shifttest.mjs
import assert from 'node:assert/strict';
import { register } from 'node:module';
register('data:text/javascript,' + encodeURIComponent(`
export async function resolve(s, c, n) {
  if (s === 'firebase/firestore') return { url: 'data:text/javascript,export const doc=()=>0;export const getDocFromServer=async()=>({exists:()=>false})', shortCircuit: true };
  if (s === './firebase.js') return { url: 'data:text/javascript,export const db={}', shortCircuit: true };
  return n(s, c);
}`));
const { explainPostFailure } = await import('../src/diagnose.js');

const bill = () => ({ shiftId: 'S1', rc: 'K3F9', seq: 8, paymentMethodId: 'm1', paymentMethodName: 'Cash', isCash: true, complimentary: false,
  rows: [{ kind: 'doctor', refId: 'd1', name: 'A. Khan', option: 0, rate: 500, qty: 1, discType: 'none', discValue: 0 },
         { kind: 'service', refId: 's1', name: 'Dressing', option: 2, rate: 150, qty: 1, discType: 'none', discValue: 0 }] });
const good = () => ({ uid: 'U1', name: 'Sara', pointer: { shiftId: 'S1' }, shift: { status: 'open', receptionistUid: 'U1' },
  profile: { role: 'receptionist', disabled: false, displayName: 'Sara', receiptCode: 'K3F9' },
  priceList: { doctors: { d1: { name: 'A. Khan', fee: 500, active: true, mode: 'fixed', min: 500, max: 500 } },
    services: { s1: { name: 'Dressing', kind: 'service', options: [100, 150, 200], mode: 'fixed', min: 100, max: 200, active: true } } },
  method: { name: 'Cash', isCash: true, active: true }, counter: { value: 7 }, license: null,
  limits: { canDiscount: false, canNegotiate: false, canComplimentary: false, maxDiscountPercent: 0, maxDiscountFixed: 0 } });
let n = 0;
const t = (name, mutate, expect, mutBill) => {
  const f = good(); mutate(f);
  const b = bill(); if (mutBill) mutBill(b);
  const r = explainPostFailure(f, b);
  if (expect === null) assert.equal(r, null, `${name}: expected no problem, got ${r?.message}`);
  else { assert.ok(r, `${name}: expected a reason`); assert.match(r.message, expect, name); }
  n++; console.log('ok -', name);
};
t('everything correct, shift open -> nothing blamed (posting allowed)', () => {}, null);
t('no open shift -> blocked with the shift message', (f) => { f.pointer = null; }, /shift is not open/);
t('pointer to another shift', (f) => { f.pointer = { shiftId: 'S2' }; }, /different shift/);
t('shift record closed', (f) => { f.shift.status = 'closed'; }, /not in the open state/);
t('shift owned by someone else', (f) => { f.shift.receptionistUid = 'U9'; }, /not in the open state/);
t('price list missing', (f) => { f.priceList = null; }, /price list has not been created/);
t('doctor not in price list', (f) => { delete f.priceList.doctors.d1; }, /Dr\. A\. Khan is not in the price list/);
t('service not in price list', (f) => { delete f.priceList.services.s1; }, /"Dressing" is not in the price list/);
t('chosen price option no longer exists', (f) => { f.priceList.services.s1.options = [100]; }, /price option no longer exists/);
t('fixed price changed', (f) => { f.priceList.services.s1.options = [100, 175, 200]; }, /changed or is fixed/);
t('negotiated rate without permission', (f) => { f.priceList.services.s1.mode = 'negotiable'; }, /not allowed to change the rate/, (b) => { b.rows[1].rate = 120; });
t('negotiated rate inside range with permission is fine', (f) => { f.priceList.services.s1.mode = 'negotiable'; f.limits.canNegotiate = true; }, null, (b) => { b.rows[1].rate = 120; });
t('negotiated rate outside range', (f) => { f.priceList.services.s1.mode = 'negotiable'; f.limits.canNegotiate = true; }, /between 100 and 200/, (b) => { b.rows[1].rate = 50; });
t('doctor fee changed', (f) => { f.priceList.doctors.d1.fee = 600; }, /changed or is fixed/);
t('discount without permission', () => {}, /not allowed to give a discount/, (b) => { b.rows[1].discType = 'percent'; b.rows[1].discValue = 5; });
t('discount above limit', (f) => { f.limits.canDiscount = true; f.limits.maxDiscountPercent = 5; }, /more than your allowed limit/, (b) => { b.rows[1].discType = 'percent'; b.rows[1].discValue = 10; });
t('discount inside limit is fine', (f) => { f.limits.canDiscount = true; f.limits.maxDiscountPercent = 10; }, null, (b) => { b.rows[1].discType = 'percent'; b.rows[1].discValue = 10; });
t('complimentary without permission', () => {}, /not allowed to create complimentary/, (b) => { b.complimentary = true; });
t('service switched off', (f) => { f.priceList.services.s1.active = false; }, /not active/);
t('payment method switched off', (f) => { f.method.active = false; }, /switched off/);
t('payment method type changed', (f) => { f.method.isCash = false; }, /changed by the Admin/);
t('stale receipt number', (f) => { f.counter.value = 9; }, /out of step/);
t('very first slip ever (no counter yet, number 1) is fine', (f) => { f.counter = null; }, null, (b) => { b.seq = 1; });
t('counter missing but this is not slip number 1', (f) => { f.counter = null; }, /out of step/);
t('"disabled" stored as text', (f) => { f.profile.disabled = 'false'; }, /wrong "disabled" value/);
t('account disabled', (f) => { f.profile.disabled = true; }, /disabled/);
t('name changed', (f) => { f.profile.displayName = 'Sara K'; }, /name on the account changed/);
t('receipt code missing', (f) => { delete f.profile.receiptCode; }, /receipt code/);
t('licence expired and blocking', (f) => { f.license = { mode: 'block', expiresAtMs: Date.now() - 1000 }; }, /licence has expired/);
t('licence expired but only warning', (f) => { f.license = { mode: 'warn', expiresAtMs: Date.now() - 1000 }; }, null);
console.log(`\n${n} checks passed`);
