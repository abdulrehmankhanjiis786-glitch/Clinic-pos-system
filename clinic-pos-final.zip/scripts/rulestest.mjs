// Checks that what the app WRITES matches what the security rules ACCEPT (field names and arithmetic).
// No Firebase needed:  node scripts/rulestest.mjs
import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';
import { computeBill, round2 } from '../src/calc.js';

const rules = readFileSync('firestore.rules', 'utf8');
const src = (f) => readFileSync(f, 'utf8');
const keysIn = (text) => [...text.matchAll(/'([A-Za-z]+)'/g)].map((m) => m[1]);
const ruleKeys = (marker, nth = 0) => {
  const i = [...rules.matchAll(new RegExp(marker.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'))][nth]?.index;
  assert.ok(i !== undefined, `rule marker not found: ${marker}`);
  const start = rules.lastIndexOf('hasOnly([', i + marker.length) + 8;
  return new Set(keysIn(rules.slice(start, rules.indexOf('])', start))));
};
// the keys of an object literal that starts at `start` text in a source file
const objKeys = (text, start) => {
  const i = text.indexOf(start);
  assert.ok(i >= 0, `source marker not found: ${start}`);
  let depth = 0, j = text.indexOf('{', i), s = j;
  for (; j < text.length; j++) { if (text[j] === '{') depth++; if (text[j] === '}') { depth--; if (!depth) break; } }
  const body = text.slice(s + 1, j);
  const out = new Set(); let d = 0, tok = '';
  for (const ch of body + ',') {
    if ('{[('.includes(ch)) d++; if ('}])'.includes(ch)) d--;
    if (ch === ',' && d === 0) { const m = tok.trim().match(/^([A-Za-z_]\w*)\s*(?::|$)/) || tok.trim().match(/^\.\.\./); if (m && m[1]) out.add(m[1]); tok = ''; } else tok += ch;
  }
  return out;
};
const same = (name, a, b) => { const x = [...a].filter((k) => !b.has(k)), y = [...b].filter((k) => !a.has(k)); assert.deepEqual([x, y], [[], []], `${name}: only in app [${x}] / only in rules [${y}]`); console.log('ok -', name); };

const bill = src('src/views/bill.js');
same('slip fields', new Set([...objKeys(bill, 'const bill = {'), 'createdAt', 'clientAt']), ruleKeys("n.keys().hasOnly(['receiptNo'"));
same('slip line fields', objKeys(bill, 'rows: t.rows.map((r) => ({'), new Set(keysIn(rules.slice(rules.indexOf("function rowValid"), rules.indexOf("'lineTotal'", rules.indexOf("function rowValid")) + 12)).filter((k) => k !== 'lineTotal' || true)));
const bal = src('src/views/balances.js');
same('payment fields', new Set([...objKeys(bal, 'const payment = {'), 'createdAt', 'clientAt']), ruleKeys("'paymentNo', 'seq'"));
const cash = src('src/views/cash.js');
same('cash entry fields', objKeys(cash, "batch.set(doc(db, 'cashTransactions', reference), {"), ruleKeys("['type', 'amount', 'reason', 'reference', 'shiftId', 'receptionistUid', 'receptionistName', 'rc', 'seq', 'createdAt', 'clientAt'])"));
const shift = src('src/views/shift.js');
same('shift open fields', objKeys(shift, "batch.set(ref, {"), ruleKeys("'receptionistUid', 'receptionistName', 'shiftName'"));
same('shift close fields', objKeys(shift, "tx.update(doc(db, 'shifts', shift.id), {"), ruleKeys("'status', 'closedAt', 'countedCash'"));
const admin = src('src/views/admin.js');
same('new receptionist fields', new Set([...objKeys(admin, "batch.set(doc(db, 'users', uid), {")]), ruleKeys("['username', 'displayName', 'role'"));
const cfg = src('src/config.js');
const flags = new Set(keysIn(cfg.slice(cfg.indexOf('const DEFAULT_LIMITS'), cfg.indexOf('};', cfg.indexOf('const DEFAULT_LIMITS'))) .replace(/(\w+):/g, "'$1':")));
const lk = new Set([...ruleKeys("'canDiscount', 'maxDiscountPercent'")].filter((k) => !['updatedAt', 'updatedBy'].includes(k)));
same('permission flags', flags, lk);
const cat = src('src/views/catalog.js');
const docKeys = objKeys(cat, "const data = { name, gender: f.gender.value");
same('doctor fields', new Set([...docKeys, 'active']), new Set([...ruleKeys("['name', 'fee', 'active', 'gender'", 0)].filter((k) => !['createdAt', 'createdBy'].includes(k))));
const svcKeys = objKeys(cat, "const data = { name, kind, category: f.category.value.trim()");
same('service fields', new Set([...svcKeys, 'active']), new Set([...ruleKeys("['name', 'kind', 'category', 'price'", 0)].filter((k) => !['createdAt', 'createdBy'].includes(k))));
const rec = src('src/views/receptionist.js');
same('presence fields', new Set(['name', 'lastSeen']), ruleKeys("['name', 'lastSeen']"));
const heldKeys = objKeys(bill, "batch.set(ref, { receptionistUid: ctx.uid, receptionistName: ctx.name, shiftId: ctx.shift().id, title");
same('held invoice fields', new Set([...heldKeys]), ruleKeys("['receptionistUid', 'receptionistName', 'shiftId', 'title'"));

// ---- the arithmetic the rules re-check must hold for everything the app can produce ----
let n = 0;
const rnd = (a, b) => a + Math.random() * (b - a);
for (let i = 0; i < 4000; i++) {
  const rows = Array.from({ length: 1 + Math.floor(rnd(0, 6)) }, () => {
    const t = ['none', 'percent', 'fixed'][Math.floor(rnd(0, 3))];
    return { kind: 'service', refId: 's', option: 1, rate: round2(rnd(1, 5000)), qty: 1 + Math.floor(rnd(0, 9)), discType: t,
      discValue: t === 'none' ? 0 : t === 'percent' ? round2(rnd(0.5, 100)) : round2(rnd(1, 8000)) };
  });
  const comp = Math.random() < 0.1;
  const b = computeBill({ rows, paid: round2(rnd(0, 30000)), comp }, () => ({ name: 'x' }));
  for (const r of b.rows) {
    const g = r.rate * r.qty;
    if (r.discType === 'percent') assert.ok(Math.abs(r.discount - g * r.discValue / 100) < 0.006, 'percent');
    if (r.discType === 'fixed') assert.ok(Math.abs(r.discount - r.discValue) < 0.005 || (r.discValue > g && Math.abs(r.discount - g) < 0.005), 'fixed');
    assert.ok(Math.abs(r.lineTotal - (g - r.discount)) < 0.006, 'line');
  }
  assert.ok(Math.abs(b.gross - b.rows.reduce((s, r) => s + r.rate * r.qty, 0)) < 0.01, 'gross');
  assert.ok(Math.abs(b.discount - b.rows.reduce((s, r) => s + r.discount, 0)) < 0.01, 'discount');
  assert.ok(Math.abs(b.net - (b.gross - b.discount - b.compAmount)) < 0.01 && b.net >= 0, 'net');
  assert.ok(b.initialPaid <= b.net + 0.005 && Math.abs(b.initialPaid + b.change - b.tendered) < 0.01 && (b.change === 0 || Math.abs(b.initialPaid - b.net) < 0.005), 'paid/change');
  assert.ok(Math.abs(b.outstanding - (b.net - b.initialPaid)) < 0.01 && b.outstanding >= -0.005, 'outstanding');
  if (comp) assert.ok(b.net === 0 && b.initialPaid === 0 && Math.abs(b.compAmount - (b.gross - b.discount)) < 0.01, 'comp');
  n++;
}
console.log(`ok - ${n} random slips satisfy the rule arithmetic`);
