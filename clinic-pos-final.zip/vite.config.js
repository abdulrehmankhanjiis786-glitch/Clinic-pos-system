import { readFileSync } from 'node:fs';
import { defineConfig } from 'vite';

const pkg = JSON.parse(readFileSync('./package.json', 'utf8'));
const stamp = new Date().toISOString();

// Writes version.json next to the site so the app can tell when a newer version is online.
const versionFile = () => ({
  name: 'version-file',
  generateBundle() { this.emitFile({ type: 'asset', fileName: 'version.json', source: JSON.stringify({ version: pkg.version, build: stamp }) }); },
});

export default defineConfig({
  server: { port: 5173 },
  plugins: [versionFile()],
  define: { __APP_VERSION__: JSON.stringify(pkg.version), __BUILD_TIME__: JSON.stringify(stamp) },
});
