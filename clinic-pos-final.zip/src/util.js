export const esc = (s) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const $ = (sel, root = document) => root.querySelector(sel);
export const fmtTime = (ts) => {
  const d = ts?.toDate ? ts.toDate() : typeof ts === 'number' ? new Date(ts) : null;
  return d ? d.toLocaleString() : '';
};
export const fmtDate = (ts) => {
  const d = ts?.toDate ? ts.toDate() : typeof ts === 'number' ? new Date(ts) : null;
  return d ? d.toLocaleDateString() : '';
};
export const startOfDay = (d = new Date()) => { const x = new Date(d); x.setHours(0, 0, 0, 0); return x; };
export const endOfDay = (d = new Date()) => { const x = new Date(d); x.setHours(23, 59, 59, 999); return x; };
export const dateInput = (d = new Date()) => { const x = new Date(d); return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`; };
export const parseDateInput = (v) => { const [y, m, d] = String(v).split('-').map(Number); return new Date(y, (m || 1) - 1, d || 1); };

// Prints a small HTML document (receipts, reports) without leaving the page.
export function printHtml(html) {
  const f = document.createElement('iframe');
  f.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0';
  document.body.appendChild(f);
  const d = f.contentWindow.document;
  d.open();
  d.write(html);
  d.close();
  setTimeout(() => { f.contentWindow.focus(); f.contentWindow.print(); }, 150);
  setTimeout(() => f.remove(), 60000);
}

// ---------- Keyboard shortcuts ----------
// Only modifier combinations / function keys are registered, so typing is never disturbed.
// Ctrl+Shift+Alt is reserved for the hidden sign-in shortcut (main.js).
let baseMap = {};
let pageMap = {};
export const keyName = (e) =>
  (e.ctrlKey ? 'Ctrl+' : '') + (e.altKey ? 'Alt+' : '') + (e.shiftKey ? 'Shift+' : '') +
  (e.code && e.code.startsWith('Key') ? e.code.slice(3) : e.code && e.code.startsWith('Digit') ? e.code.slice(5) : e.key);
window.addEventListener('keydown', (e) => {
  if (e.ctrlKey && e.shiftKey && e.altKey) return;
  const name = keyName(e);
  const fn = pageMap[name] || baseMap[name];
  if (fn) { e.preventDefault(); fn(e); }
});
export const setBaseShortcuts = (m) => { baseMap = m || {}; };
export const setPageShortcuts = (m) => { pageMap = m || {}; };

// ---------- Popup (Esc closes it) ----------
export function modal(html, { wide = false } = {}) {
  const o = document.createElement('div');
  o.className = 'modal-bg';
  o.innerHTML = `<div class="modal${wide ? ' wide' : ''}" role="dialog" aria-modal="true">${html}</div>`;
  document.body.appendChild(o);
  const onKey = (e) => { if (e.key === 'Escape') { e.stopPropagation(); close(); } };
  const close = () => { o.remove(); window.removeEventListener('keydown', onKey, true); };
  window.addEventListener('keydown', onKey, true);
  return { el: o, close };
}

// Yes / No popup that returns a promise.
export function ask(title, text, yes = 'Confirm', no = 'Cancel') {
  return new Promise((resolve) => {
    const m = modal(`<h2>${esc(title)}</h2><p>${esc(text)}</p>
      <div class="row-gap" style="justify-content:flex-end"><button class="btn" id="n">${esc(no)}</button><button class="btn primary" id="y">${esc(yes)}</button></div>`);
    $('#y', m.el).onclick = () => { m.close(); resolve(true); };
    $('#n', m.el).onclick = () => { m.close(); resolve(false); };
    $('#y', m.el).focus();
  });
}

// Small message at the bottom of the screen.
export function toast(text, bad = false) {
  const t = document.createElement('div');
  t.className = `toast${bad ? ' bad' : ''}`;
  t.textContent = text;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), bad ? 6000 : 3000);
}
