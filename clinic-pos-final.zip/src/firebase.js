import { initializeApp } from 'firebase/app';
import { getAuth, setPersistence, browserLocalPersistence } from 'firebase/auth';
import { initializeFirestore, getFirestore, persistentLocalCache, persistentMultipleTabManager } from 'firebase/firestore';
import { initializeAppCheck, ReCaptchaV3Provider } from 'firebase/app-check';

const env = import.meta.env;

export const firebaseConfig = {
  apiKey: env.VITE_FIREBASE_API_KEY,
  authDomain: env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: env.VITE_FIREBASE_PROJECT_ID,
  appId: env.VITE_FIREBASE_APP_ID,
  messagingSenderId: env.VITE_FIREBASE_MESSAGING_SENDER_ID,
};

// One Firebase app and one Firestore instance for the whole program.
export const app = initializeApp(firebaseConfig);

// App Check turns on only when a reCAPTCHA key is provided (see SETUP_GUIDE).
export const appCheckEnabled = Boolean(env.VITE_RECAPTCHA_SITE_KEY);
if (appCheckEnabled) {
  initializeAppCheck(app, { provider: new ReCaptchaV3Provider(env.VITE_RECAPTCHA_SITE_KEY), isTokenAutoRefreshEnabled: true });
}

export const auth = getAuth(app);
// Staff stay signed in until they sign out (no inactivity timeout), so a power cut or a restart during an
// internet outage does not lock a receptionist out of the offline billing screen.
setPersistence(auth, browserLocalPersistence).catch(() => {});

// Long polling avoids the "Listen ... transport errored / QUIC" failures seen on some networks.
// The local cache keeps data on the computer so billing continues offline and syncs later.
let database;
try {
  database = initializeFirestore(app, {
    localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }),
    experimentalForceLongPolling: true,
  });
} catch {
  database = getFirestore(app); // already created, or the browser has no local storage for it
}
export const db = database;
