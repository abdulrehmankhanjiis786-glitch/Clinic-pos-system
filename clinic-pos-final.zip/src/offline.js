// Offline support: tracks saves that are waiting for the internet and checks they arrived.
// Firestore itself keeps unsent saves on the computer and sends them when the internet returns.
import { doc, getDoc, getDocFromCache, getDocFromServer, getDocs, getDocsFromCache, waitForPendingWrites } from 'firebase/firestore';
import { auth, db } from './firebase.js';

const qkey = () => `txq:${auth.currentUser?.uid || 'x'}`;
const read = () => { try { return JSON.parse(localStorage.getItem(qkey()) || '[]'); } catch { return []; } };
const write = (a) => { try { localStorage.setItem(qkey(), JSON.stringify(a.slice(-300))); } catch { /* storage full */ } };
const listeners = new Set();
export const onSyncChange = (fn) => { listeners.add(fn); return () => listeners.delete(fn); };
export function summary() {
  const q = read();
  return { online: navigator.onLine, pending: q.filter((x) => x.status === 'pending').length, failed: q.filter((x) => x.status === 'failed') };
}
const emit = () => listeners.forEach((f) => f(summary()));
export const isOnline = () => navigator.onLine;

function mark(id, status, error) {
  const q = read();
  const e = q.find((x) => x.id === id);
  if (e) { e.status = status; e.error = error || ''; e.doneAt = Date.now(); }
  write(q.filter((x) => x.status !== 'synced').concat(q.filter((x) => x.status === 'synced').slice(-10)));
  emit();
}

// Wraps a commit promise: records it as "waiting", then synced / failed.
// meta = { id, type, label, path: ['bills', id], draft? }
export function track(commitPromise, meta) {
  const q = read();
  q.push({ ...meta, status: 'pending', at: Date.now() });
  write(q);
  emit();
  commitPromise.then(() => mark(meta.id, 'synced')).catch(async (e) => {
    // A save that was already stored earlier is reported as "denied" by the rules; check before calling it a failure.
    try { if (meta.path && (await getDocFromServer(doc(db, ...meta.path))).exists()) { mark(meta.id, 'synced'); return; } } catch { /* offline */ }
    mark(meta.id, 'failed', e?.code || 'error');
  });
  return commitPromise;
}
export const dismiss = (id) => { write(read().filter((x) => x.id !== id)); emit(); };

// After a reload: wait for the saved-on-this-computer writes to be sent, then confirm each one.
export async function reconcile() {
  if (!auth.currentUser) return;
  try { await waitForPendingWrites(db); } catch { return; }
  const q = read();
  for (const e of q.filter((x) => x.status === 'pending')) {
    try {
      const s = await getDocFromServer(doc(db, ...e.path));
      mark(e.id, s.exists() ? 'synced' : 'failed', s.exists() ? '' : 'not-saved');
    } catch { return; }
  }
}
window.addEventListener('online', () => { emit(); reconcile(); });
window.addEventListener('offline', emit);

// ----- reads that never make the screen wait for a dead connection -----
const timeout = (ms) => new Promise((_, rej) => setTimeout(() => rej(new Error('slow')), ms));
export async function fastGet(ref, ms = 3500) {
  if (!navigator.onLine) return getDocFromCache(ref).catch(() => null);
  try { return await Promise.race([getDoc(ref), timeout(ms)]); } catch { return getDocFromCache(ref).catch(() => null); }
}
export async function fastDocs(q, ms = 4500) {
  if (!navigator.onLine) return getDocsFromCache(q).catch(() => null);
  try { return await Promise.race([getDocs(q), timeout(ms)]); } catch { return getDocsFromCache(q).catch(() => null); }
}
