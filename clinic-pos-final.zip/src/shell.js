import { esc, $, setPageShortcuts, fmtDate } from './util.js';
import { logout } from './auth.js';
import { onSyncChange, summary } from './offline.js';

// Each page gets its OWN container. If the user opens another page while data is still loading, the
// old page keeps writing into its own (now detached) container instead of the new page. No stale writes, no null errors.
function swap(host) {
  const c = document.createElement('div');
  c.className = 'page';
  host.replaceChildren(c);
  return c;
}

// ---------- Admin / technical shell: text sidebar ----------
export function mountShell(root, { brand, roleLabel, name, nav, pages, start }) {
  root.innerHTML = `
    <div class="shell">
      <aside class="side">
        <div class="brand">${esc(brand)}</div>
        <nav>${nav.map((n) => `<button class="nav" data-id="${n.id}">${esc(n.label)}</button>`).join('')}</nav>
      </aside>
      <div class="main">
        <header class="top">
          <h1 id="crumb"></h1>
          <div class="who"><span id="banner" class="banner"></span><span>${esc(name)}</span><span class="badge">${esc(roleLabel)}</span>
            <button class="btn" id="out">Sign out</button></div>
        </header>
        <section class="content" id="content"></section>
      </div>
    </div>`;
  const go = (id) => {
    setPageShortcuts({});
    root.querySelectorAll('.nav').forEach((b) => b.classList.toggle('active', b.dataset.id === id));
    const item = nav.find((n) => n.id === id);
    $('#crumb', root).textContent = item.label;
    (pages[id] || placeholder(item))(swap($('#content', root)));
  };
  root.querySelectorAll('.nav').forEach((b) => (b.onclick = () => go(b.dataset.id)));
  $('#out', root).onclick = () => logout();
  go(start || nav[0].id);
  return { go, setBanner: (t) => { $('#banner', root).textContent = t || ''; } };
}

const placeholder = (item) => (c) => {
  c.innerHTML = `<div class="card"><h2>${esc(item.label)}</h2><p class="muted">${esc(item.note || 'Nothing to show here.')}</p></div>`;
};

// ---------- Receptionist shell: narrow icon rail on the left, work area in the middle ----------
const ICONS = {
  home: '<path d="M3 11l9-8 9 8M5 10v10h14V10"/>', search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
  plus: '<path d="M12 5v14M5 12h14"/>', pause: '<path d="M8 5v14M16 5v14"/>', held: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
  printer: '<path d="M6 9V3h12v6"/><rect x="6" y="14" width="12" height="7"/><path d="M6 18H4a1 1 0 0 1-1-1v-6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v6a1 1 0 0 1-1 1h-2"/>',
  check: '<path d="M20 6L9 17l-5-5"/>', slips: '<path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6M9 13h6M9 17h6"/>',
  wallet: '<rect x="2" y="6" width="20" height="14" rx="2"/><path d="M2 10h20M16 15h2"/>', cash: '<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="3"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', help: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 1 1 3.5 2.3c-.7.4-1 1-1 1.7M12 17h.01"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
};
export const icon = (n) => `<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[n] || ''}</svg>`;

// rail: [{id, icon, label, page? , act?}] ; pages: {id: fn(container)}
export function mountPos(root, { name, rail, pages, start, shiftLabel }) {
  root.innerHTML = `
    <div class="pos-shell">
      <aside class="rail">${rail.map((r) => (r.sep ? '<hr>' : `<button class="rail-btn" data-id="${r.id}" title="${esc(r.label)}" aria-label="${esc(r.label)}">${icon(r.icon)}<span>${esc(r.label)}</span></button>`)).join('')}</aside>
      <div class="pos-main">
        <header class="pos-top">
          <strong>${esc(name)}</strong><span class="muted">${esc(fmtDate(Date.now()))}</span>
          <span class="chip" id="shiftchip">${esc(shiftLabel || 'Shift: not opened')}</span>
          <span id="net" class="chip net"></span><span id="banner" class="banner"></span>
          <span class="grow"></span><button class="btn small" id="chpw">Change password</button><button class="btn small" id="out">Sign out</button>
        </header>
        <section class="pos-content" id="content"></section>
      </div>
    </div>`;
  const state = { page: null };
  const go = (id) => {
    if (!pages[id]) return;
    setPageShortcuts({});
    state.page = id;
    root.querySelectorAll('.rail-btn').forEach((b) => b.classList.toggle('active', b.dataset.id === id));
    pages[id](swap($('#content', root)));
  };
  root.querySelectorAll('.rail-btn').forEach((b) => {
    b.onclick = () => {
      const item = rail.find((r) => r.id === b.dataset.id);
      if (item.act) item.act(); else go(item.id);
    };
  });
  const paint = (s) => {
    const n = $('#net', root);
    if (!n) return;
    n.className = `chip net ${s.online ? 'on' : 'off'}`;
    n.textContent = s.online ? (s.pending ? `Online · ${s.pending} syncing` : 'Online') : `Offline${s.pending ? ` · ${s.pending} waiting` : ''}`;
    const b = $('#banner', root);
    if (b && !s.online) b.textContent = 'Internet connection unavailable. Your data will sync automatically when the internet is restored.';
    else if (b && b.dataset.kind !== 'license') b.textContent = '';
  };
  onSyncChange(paint);
  paint(summary());
  $('#out', root).onclick = () => pos.beforeLogout();
  const pos = {
    go, current: () => state.page,
    setShift: (t) => { const c = $('#shiftchip', root); if (c) c.textContent = t; },
    setBanner: (t) => { const b = $('#banner', root); if (b) { b.textContent = t || ''; b.dataset.kind = t ? 'license' : ''; } },
    onChangePassword: () => {},
    beforeLogout: () => logout(),
  };
  $('#chpw', root).onclick = () => pos.onChangePassword();
  go(start || rail.find((r) => !r.sep && !r.act).id);
  return pos;
}
