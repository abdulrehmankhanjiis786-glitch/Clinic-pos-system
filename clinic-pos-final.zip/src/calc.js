// Pure billing maths (no Firebase, no DOM). The same formulas are checked by the security rules.
export const round2 = (n) => Math.round((Number(n) + Number.EPSILON) * 100) / 100;

// Old services only have `price`; new ones have `priceOptions` (1-5), `priceMode`, `minRate`, `maxRate`.
export function normService(s) {
  const options = (Array.isArray(s.priceOptions) && s.priceOptions.length ? s.priceOptions : [s.price]).map(Number);
  return {
    ...s, kind: s.kind || 'service', category: s.category || '', options, mode: s.priceMode === 'negotiable' ? 'negotiable' : 'fixed',
    min: Number(s.minRate ?? Math.min(...options)), max: Number(s.maxRate ?? Math.max(...options)),
  };
}
export function normDoctor(d) {
  const fee = Number(d.fee);
  return { ...d, fee, mode: d.feeMode === 'negotiable' ? 'negotiable' : 'fixed', min: Number(d.minFee ?? fee), max: Number(d.maxFee ?? fee),
    category: d.category || '', specialization: d.specialization || '', gender: d.gender || '', day: d.day || '', time: d.time || '' };
}

// The entry stored in settings/priceList for bill validation by the security rules.
export const serviceEntry = (s) => { const n = normService(s); return { name: n.name, active: n.active !== false, kind: n.kind, options: n.options, mode: n.mode, min: n.min, max: n.max }; };
export const doctorEntry = (d) => { const n = normDoctor(d); return { name: n.name, active: n.active !== false, fee: n.fee, mode: n.mode, min: n.min, max: n.max }; };

export function rowDiscount(gross, discType, discValue) {
  const v = Number(discValue) || 0;
  if (discType === 'percent') return round2((gross * v) / 100);
  if (discType === 'fixed') return round2(Math.min(v, gross));
  return 0;
}

// state.rows: [{kind, refId, option, rate, qty, discType, discValue}]
// lookup(kind, refId) -> {name}
export function computeBill(state, lookup) {
  const rows = state.rows.map((r) => {
    const gross = round2(r.rate * r.qty);
    const discount = rowDiscount(gross, r.discType, r.discValue);
    return { ...r, name: lookup(r.kind, r.refId)?.name || '?', gross, discount, lineTotal: round2(gross - discount) };
  });
  const gross = round2(rows.reduce((t, r) => t + r.gross, 0));
  const discount = round2(rows.reduce((t, r) => t + r.discount, 0));
  const afterDiscount = round2(gross - discount);
  const compAmount = state.comp ? afterDiscount : 0;
  const net = round2(afterDiscount - compAmount);
  const tendered = state.comp ? 0 : Math.max(0, Number(state.paid) || 0);
  const initialPaid = round2(Math.min(tendered, net));
  return { rows, gross, discount, compAmount, net, tendered: round2(tendered), initialPaid,
    change: round2(tendered - initialPaid), outstanding: round2(net - initialPaid) };
}

export const pad6 = (n) => String(n).padStart(6, '0');
export const makeNumber = (prefix, rc, seq) => `${prefix}${rc}-${pad6(seq)}`;
export const parseMoney = (v, allowZero = false) => {
  const s = String(v ?? '').trim();
  if (!/^\d{1,9}(\.\d{1,2})?$/.test(s)) return null;
  const n = round2(Number(s));
  return !allowZero && n <= 0 ? null : n;
};

// Old bills (rows missing) are shown through the same screens.
export function billRows(b) {
  if (Array.isArray(b.rows)) return b.rows;
  const out = [];
  if (b.doctorId) out.push({ kind: 'doctor', name: b.doctorName, rate: b.doctorFee, qty: 1, discount: 0, lineTotal: b.doctorFee });
  (b.items || []).forEach((i) => out.push({ kind: 'service', name: i.name, rate: i.price, qty: i.qty, discount: 0, lineTotal: i.lineTotal }));
  return out;
}
