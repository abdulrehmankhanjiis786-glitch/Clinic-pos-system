// Settings that rarely change (doctors, services, payment methods, hospital details, permissions) are
// loaded once, kept in memory and in local storage, and refreshed quietly. Screens read from here,
// not from Firestore, so they open instantly and keep working offline.
import { collection, doc } from 'firebase/firestore';
import { auth, db } from './firebase.js';
import { fastDocs, fastGet } from './offline.js';
import { normDoctor, normService } from './calc.js';
import { setCurrency } from './data.js';

export const DEFAULT_SHORTCUTS = [
  { key: 'Alt+N', action: 'newSlip' }, { key: 'Alt+D', action: 'doctor' }, { key: 'Alt+S', action: 'service' },
  { key: 'Alt+C', action: 'discount' }, { key: 'Alt+P', action: 'paid' }, { key: 'Ctrl+Enter', action: 'post' },
  { key: 'Alt+Enter', action: 'print' }, { key: 'Ctrl+S', action: 'hold' }, { key: 'Alt+H', action: 'held' },
  { key: 'Alt+T', action: 'slips' }, { key: 'Alt+O', action: 'outstanding' }, { key: 'Ctrl+F', action: 'search' },
  { key: 'Alt+Delete', action: 'deleteRow' }, { key: 'F1', action: 'help' },
];
export const ACTIONS = {
  newSlip: 'New Slip', doctor: 'Focus Doctor', service: 'Focus Service search', discount: 'Focus Discount', paid: 'Focus Paid amount',
  post: 'Post invoice', print: 'Print (post + print)', hold: 'Hold invoice', held: 'Held invoices', slips: "Today's Slips",
  outstanding: 'Outstanding Balance', search: 'Search slips', deleteRow: 'Delete selected row', help: 'Shortcut Help',
  cashIn: 'Cash In / Out', shift: 'Shift',
};

const DEFAULT_LIMITS = { canDiscount: false, maxDiscountPercent: 0, maxDiscountFixed: 0, canNegotiate: false, canCollectOutstanding: true,
  canCollectOthers: false, canCashIn: true, canCashOut: false, cashOutLimit: 0, canCancel: false, canRefund: false, canRestore: false, canComplimentary: false };
export const withDefaults = (l) => ({ ...DEFAULT_LIMITS, ...(l || {}) });

let mem = null;
let refreshing = null;
const ckey = () => `cfg:${auth.currentUser?.uid || 'x'}`;
const data = (s) => (s && s.exists() ? s.data() : null);
const rows = (s) => (s ? s.docs.map((d) => ({ id: d.id, ...d.data() })) : null);

function assemble(raw) {
  const general = raw.general || {};
  const legacy = raw.hospital || {};
  const b = raw.branding || {};
  const branding = {
    heading: b.heading || legacy.hospitalName || 'Hospital', address: b.address ?? legacy.address ?? '', phone: b.phone ?? legacy.phone ?? '',
    email: b.email || '', footer: b.footer || '', logo: b.logo || '', receiptNote: b.receiptNote || '',
    print: { width: '80', template: 'standard', fontSize: 12, ...(b.print || {}) },
  };
  return {
    ...raw, general: { currency: general.currency ?? legacy.currency ?? '', receiptPrefix: general.receiptPrefix || 'R' }, branding,
    shortcuts: raw.shortcuts?.items?.length ? raw.shortcuts.items : DEFAULT_SHORTCUTS,
    categories: { lab: raw.categories?.lab || [], service: raw.categories?.service || [] },
    limits: withDefaults(raw.limits),
  };
}

async function fetchAll(role) {
  const uid = auth.currentUser.uid;
  const one = async (...p) => { try { return data(await fastGet(doc(db, ...p))); } catch { return undefined; } };
  const many = async (c) => { try { return rows(await fastDocs(collection(db, c))); } catch { return null; } };
  const prev = mem || {};
  const [docs, services, methods, general, hospital, branding, categories, shortcuts, license, installation, priceList, limits] = await Promise.all([
    many('doctors'), many('services'), many('paymentMethods'), one('settings', 'general'), one('settings', 'hospital'), one('settings', 'branding'),
    one('settings', 'categories'), one('settings', 'shortcuts'), one('settings', 'license'), one('settings', 'installation'), fastGet(doc(db, 'settings', 'priceList')),
    role === 'receptionist' ? one('staffLimits', uid) : Promise.resolve(null),
  ]);
  const keep = (v, old) => (v === undefined || v === null ? old : v);
  const raw = {
    doctors: docs || prev.rawDoctors || [], services: services || prev.rawServices || [], methods: methods || prev.methods || [],
    general: keep(general, prev.general), hospital: keep(hospital, prev.hospital), branding: keep(branding, prev.rawBranding),
    categories: keep(categories, prev.rawCategories), shortcuts: keep(shortcuts, prev.rawShortcuts), license: keep(license, prev.license || null),
    installation: keep(installation, prev.installation || null), limits: role === 'receptionist' ? keep(limits, prev.rawLimits) : null,
  };
  const cfg = assemble(raw);
  cfg.rawDoctors = raw.doctors; cfg.rawServices = raw.services; cfg.rawBranding = raw.branding; cfg.rawCategories = raw.categories;
  cfg.rawShortcuts = raw.shortcuts; cfg.rawLimits = raw.limits;
  cfg.doctors = raw.doctors.map(normDoctor);
  cfg.services = raw.services.map(normService);
  cfg.methods = raw.methods;
  cfg.stamp = priceList?.exists?.() ? priceList.data().updatedAt?.toMillis?.() || 0 : prev.stamp || 0;
  cfg.loadedAt = Date.now();
  cfg.role = role;
  mem = cfg;
  try { localStorage.setItem(ckey(), JSON.stringify(cfg)); } catch { /* too big: memory only */ }
  setCurrency(cfg.general.currency);
  return cfg;
}

// Returns the settings at once if they are already known; loads them the first time only.
export async function getConfig(role, force = false) {
  if (mem && !force) return mem;
  if (!force) {
    try {
      const s = localStorage.getItem(ckey());
      if (s) {
        mem = JSON.parse(s);
        setCurrency(mem.general?.currency);
        refreshConfig(role); // quiet refresh in the background
        return mem;
      }
    } catch { /* ignore bad cache */ }
  }
  return refreshConfig(role);
}
export function refreshConfig(role) {
  if (!refreshing) refreshing = fetchAll(role).finally(() => { refreshing = null; });
  return refreshing;
}
// Called whenever the Admin saves a change, so the next screen shows it.
export function invalidateConfig() { mem = null; try { localStorage.removeItem(ckey()); } catch { /* ignore */ } }
export const peekConfig = () => mem;
export function clearConfig() { mem = null; }

// Cheap check used when the billing screen opens: reloads everything only if the price list changed.
export async function refreshIfChanged(role) {
  if (!navigator.onLine) return mem;
  try {
    const s = await fastGet(doc(db, 'settings', 'priceList'), 2500);
    const stamp = s?.exists?.() ? s.data().updatedAt?.toMillis?.() || 0 : 0;
    if (!mem || stamp !== mem.stamp) return await refreshConfig(role);
    if (role === 'receptionist') {
      const l = await fastGet(doc(db, 'staffLimits', auth.currentUser.uid), 2500);
      if (l?.exists?.()) { mem.rawLimits = l.data(); mem.limits = withDefaults(l.data()); }
    }
  } catch { /* keep what we have */ }
  return mem;
}
