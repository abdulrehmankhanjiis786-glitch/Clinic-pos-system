import './styles.css';
import { onAuthStateChanged } from 'firebase/auth';
import { auth } from './firebase.js';
import { logout, roleAllowed, sessionAllowed, getProfile, startIdleTimer, stopIdleTimer } from './auth.js';
import { renderLogin } from './views/login.js';
import { installErrorCapture } from './diagnostics.js';
import { setBaseShortcuts, setPageShortcuts } from './util.js';
import { getConfig, clearConfig } from './config.js';
import { licenseInfo } from './data.js';

/* global __BUILD_TIME__ */
installErrorCapture();
const root = document.getElementById('app');
let view = 'login'; // login | devlogin | dashboard

function showLogin() { view = 'login'; renderLogin(root, 'staff'); }
function showDevLogin() { view = 'devlogin'; renderLogin(root, 'developer'); }

// The profile is saved on this computer so a restart during an internet outage still works.
async function loadProfile(uid) {
  const key = `profile:${uid}`;
  try { const p = await getProfile(uid); if (p) { localStorage.setItem(key, JSON.stringify(p)); return p; } return null; }
  catch (e) { if (!navigator.onLine || e.code === 'unavailable') { try { return JSON.parse(localStorage.getItem(key) || 'null'); } catch { return null; } } return null; }
}

async function banners(role) {
  const out = [];
  try {
    const l = licenseInfo(await getConfig(role));
    if (l.expired) out.push('Licence expired. Please contact the administrator.'); else if (l.daysLeft !== null && l.daysLeft <= 14) out.push(`Licence expires in ${l.daysLeft} day(s).`);
  } catch { /* none */ }
  try {
    const v = await (await fetch(`/version.json?t=${Date.now()}`, { cache: 'no-store' })).json();
    if (typeof __BUILD_TIME__ !== 'undefined' && v.build !== __BUILD_TIME__) out.push('A new version is available. Please refresh the page when you are not in the middle of a slip.');
  } catch { /* offline */ }
  return out.join(' · ');
}

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    stopIdleTimer(); setBaseShortcuts({}); setPageShortcuts({}); clearConfig();
    if (view === 'dashboard' || !root.firstChild) showLogin();
    return;
  }
  const token = await user.getIdTokenResult();
  const p = await loadProfile(user.uid);
  if (!p || !sessionAllowed(p, token.claims.auth_time) || !roleAllowed(p.role, sessionStorage.getItem('ctx'))) { await logout(); return; }
  const name = p.displayName || 'User';
  view = 'dashboard';
  if (p.role === 'developer') {
    startIdleTimer(15);
    const { renderDeveloper, devGate } = await import('./views/developer.js');
    if (!(await devGate())) { await logout(); return; }
    renderDeveloper(root, name, p.role);
  } else if (p.role === 'admin') {
    const { renderAdmin } = await import('./views/admin.js');
    const shell = renderAdmin(root, name, user.uid);
    banners('admin').then((t) => shell.setBanner(t));
  } else {
    const { renderReceptionist } = await import('./views/receptionist.js');
    const pos = await renderReceptionist(root, name, user.uid, p);
    banners('receptionist').then((t) => pos.setBanner(t));
  }
});

// Hidden shortcut: Ctrl + Shift + Alt + D. Only opens the technical sign-in form.
window.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && view === 'devlogin') { showLogin(); return; }
  if (e.ctrlKey && e.shiftKey && e.altKey && e.code === 'KeyD') {
    const t = e.target;
    if (t && (t.isContentEditable || ['INPUT', 'TEXTAREA', 'SELECT'].includes(t.tagName))) return;
    e.preventDefault();
    if (auth.currentUser) return;
    showDevLogin();
  }
});
