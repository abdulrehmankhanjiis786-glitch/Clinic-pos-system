// Finds the REAL reason a slip was refused. The security rules only answer "permission denied", so this
// reads the records the rules look at and names the first one that does not match.
import { doc, getDocFromServer } from 'firebase/firestore';
import { db } from './firebase.js';

const near = (a, b) => Math.abs(Number(a) - Number(b)) < 0.005;
const fix = (m) => ({ ok: false, message: m });

// Pure part (tested in scripts/shifttest.mjs). null = document missing.
// facts = { uid, name, pointer, shift, profile, priceList, method, counter, license, limits }
export function explainPostFailure(facts, bill) {
  const { uid, name, pointer, shift, profile, priceList, method, counter, license, limits } = facts;
  if (!profile) return fix('Your account record is missing. Please contact the Admin.');
  if (profile.role !== 'receptionist') return fix('Only a receptionist account can post slips.');
  if (profile.disabled !== false) {
    return fix(typeof profile.disabled === 'boolean' ? 'Your account is disabled. Please contact the Admin.'
      : 'Your account record has a wrong "disabled" value (it must be the boolean false). Ask the Admin to correct it.');
  }
  if (profile.displayName !== name) return fix('Your name on the account changed. Please sign out and sign in again.');
  if (!profile.receiptCode || profile.receiptCode !== bill.rc) return fix('Your receipt code is missing or changed. Ask the Admin to check it.');
  if (license && license.mode === 'block' && license.expiresAtMs && license.expiresAtMs < Date.now()) return fix('The licence has expired. Please contact the administrator.');

  if (!pointer) return fix('Your shift is not open. Open it in Current Shift first.');
  if (pointer.shiftId !== bill.shiftId) return fix('A different shift of yours is open now. Reload the page and try again.');
  if (!shift || shift.status !== 'open' || shift.receptionistUid !== uid) return fix('The shift record is not in the open state. Ask the Admin to check the shift reports.');

  if (!priceList) return fix('The price list has not been created yet. The Admin must sign in once; it is created automatically.');
  for (const r of bill.rows || []) {
    const e = r.kind === 'doctor' ? priceList.doctors?.[r.refId] : priceList.services?.[r.refId];
    const label = r.kind === 'doctor' ? `Dr. ${r.name}` : `"${r.name}"`;
    if (!e) return fix(`${label} is not in the price list yet. The Admin must sign in once to update it.`);
    if (e.active !== true) return fix(`${label} is not active in the price list.`);
    if (e.name !== r.name) return fix(`${label} was renamed. Reload the page and add it again.`);
    const base = r.kind === 'doctor' ? e.fee : e.options?.[r.option - 1];
    if (base === undefined) return fix(`${label}: that price option no longer exists. Reload the page.`);
    if (!near(base, r.rate)) {
      if (e.mode !== 'negotiable') return fix(`The price of ${label} changed or is fixed. Reload the page and add it again.`);
      if (!limits?.canNegotiate) return fix(`You are not allowed to change the rate of ${label}.`);
      if (r.rate < e.min || r.rate > e.max) return fix(`${label}: the rate must be between ${e.min} and ${e.max}.`);
    }
    if (r.discType !== 'none') {
      if (!limits?.canDiscount) return fix('You are not allowed to give a discount.');
      const cap = r.discType === 'percent' ? limits.maxDiscountPercent : limits.maxDiscountFixed;
      if (r.discValue > cap) return fix(`${label}: the discount is more than your allowed limit.`);
    }
  }
  if (bill.complimentary && !limits?.canComplimentary) return fix('You are not allowed to create complimentary slips.');
  if (!method) return fix('The payment method no longer exists. Choose another one.');
  if (method.active !== true) return fix(`The payment method "${bill.paymentMethodName}" is switched off.`);
  if (method.name !== bill.paymentMethodName || method.isCash !== bill.isCash) return fix('The payment method was changed by the Admin. Reload the page.');
  const last = counter ? counter.value : 0;
  if (last + 1 !== bill.seq) return fix('The receipt number is out of step (another computer used your account?). Press Post again.');
  return null;
}

export async function loadFacts(uid, name, bill) {
  const get = async (...p) => { const s = await getDocFromServer(doc(db, ...p)); return s.exists() ? s.data() : null; };
  const pointer = await get('openShifts', uid);
  const [shift, profile, priceList, method, counter, license, limits] = await Promise.all([
    pointer ? get('shifts', pointer.shiftId) : null, get('users', uid), get('settings', 'priceList'), get('paymentMethods', bill.paymentMethodId),
    get('counters', `rc_${uid}`), get('settings', 'license'), get('staffLimits', uid),
  ]);
  const lic = license ? { mode: license.mode, expiresAtMs: license.expiresAt?.toMillis?.() } : null;
  return { uid, name, pointer, shift, profile, priceList, method, counter, license: lic, limits };
}

export async function explainFailure(uid, name, bill, error) {
  const code = error?.code ? ` [${error.code}]` : '';
  try {
    const found = explainPostFailure(await loadFacts(uid, name, bill), bill);
    if (found) return found.message + code;
  } catch { return `Could not check the connection to the server. Please try again.${code}`; }
  return `The server refused this slip for a reason that cannot be seen here.${code} Please send this code to the Admin.`;
}
