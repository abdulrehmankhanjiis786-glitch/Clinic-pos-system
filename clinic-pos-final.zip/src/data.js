// Shared helpers: money, shifts and the shift ledger (totals use server-side counting, not downloads).
import { collection, doc, getDoc, getDocFromServer, getDocs, query, where, limit, startAfter, getAggregateFromServer, sum } from 'firebase/firestore';
import { db } from './firebase.js';
import { fastGet } from './offline.js';
import { round2, parseMoney } from './calc.js';

export { round2 };
export const parseAmount = parseMoney;

let currency = '';
export const setCurrency = (c) => { currency = c || ''; };
export const money = (n) => (currency ? currency + ' ' : '') + round2(n).toFixed(2);
export const shortId = (id) => String(id || '').slice(0, 6).toUpperCase();

export async function list(coll, ...constraints) {
  try {
    const s = await getDocs(query(collection(db, coll), ...constraints));
    return s.docs.map((d) => ({ id: d.id, ...d.data() }));
  } catch (e) {
    console.error('Firestore read failed:', coll, e.code, e.message);
    throw e;
  }
}

// The receptionist's open shift. Online it is read from the server and must really be open and belong to this user;
// offline the copy saved on this computer is used. A connection problem is never reported as "no open shift".
export async function getOpenShift(uid) {
  const key = `shift:${uid}`;
  const saved = () => { try { return JSON.parse(localStorage.getItem(key) || 'null'); } catch { return null; } };
  const p = await fastGet(doc(db, 'openShifts', uid));
  if (p === null) return saved(); // offline and not cached: use the saved copy
  if (!p.exists()) { localStorage.removeItem(key); return null; }
  const s = await fastGet(doc(db, 'shifts', p.data().shiftId));
  if (s === null) return saved();
  if (!s.exists() || s.data().status !== 'open' || s.data().receptionistUid !== uid) { localStorage.removeItem(key); return null; }
  const shift = { id: s.id, ...s.data() };
  try { localStorage.setItem(key, JSON.stringify({ ...shift, openedAt: shift.openedAt?.toMillis?.() || shift.openedAt })); } catch { /* ignore */ }
  return shift;
}

// Fresh check straight from the server, used right before saving money records while online.
export async function verifyOpenShift(uid) {
  try {
    const p = await getDocFromServer(doc(db, 'openShifts', uid));
    if (!p.exists()) return { ok: false, message: 'Your shift is not open. Open it in Current Shift first.' };
    const s = await getDocFromServer(doc(db, 'shifts', p.data().shiftId));
    if (!s.exists() || s.data().status !== 'open' || s.data().receptionistUid !== uid) {
      return { ok: false, message: 'The shift record is not in the open state. Ask the Admin to check the shift reports.' };
    }
    return { ok: true, shift: { id: s.id, ...s.data() } };
  } catch (e) {
    console.error('Shift check failed:', e.code, e.message);
    return { ok: false, network: true, message: 'Could not check your shift because the connection to the server failed. Please try again.', error: e };
  }
}

// One page of a list (cursor pagination): returns { rows, last, more }.
export async function page(coll, constraints, after = null, size = 25) {
  try {
    const s = await getDocs(query(collection(db, coll), ...constraints, ...(after ? [startAfter(after)] : []), limit(size + 1)));
    const docs = s.docs;
    return { rows: docs.slice(0, size).map((d) => ({ id: d.id, ...d.data() })), last: docs[Math.min(size, docs.length) - 1] || null, more: docs.length > size };
  } catch (e) {
    console.error('Firestore page failed:', coll, e.code, e.message);
    throw e;
  }
}

export const total = async (coll, field, ...cons) => {
  const r = await getAggregateFromServer(query(collection(db, coll), ...cons), { t: sum(field) });
  return round2(r.data().t || 0);
};

// Accounting formula (physical cash only):
// Expected = Opening + Cash sales + Cash balance payments + Cash In - Cash Out - Cash refunds
// Card / bank / wallet amounts are listed separately and never change expected cash.
export async function shiftTotals(shift) {
  const id = shift.id;
  const rc = shift.receptionistUid;
  const [cashSales, cashOutstanding, cashIn, cashOut, cashRefunds, nb, np] = await Promise.all([
    total('bills', 'initialPaid', where('shiftId', '==', id), where('isCash', '==', true)),
    total('payments', 'amount', where('shiftId', '==', id), where('isCash', '==', true)),
    total('cashTransactions', 'amount', where('shiftId', '==', id), where('receptionistUid', '==', rc), where('type', '==', 'in')),
    total('cashTransactions', 'amount', where('shiftId', '==', id), where('receptionistUid', '==', rc), where('type', '==', 'out')),
    total('bills', 'refundAmount', where('refundShiftId', '==', id), where('refundIsCash', '==', true), where('status', '==', 'cancelled')),
    list('bills', where('shiftId', '==', id), where('isCash', '==', false)),
    list('payments', where('shiftId', '==', id), where('isCash', '==', false)),
  ]);
  const nonCash = {};
  nb.forEach((b) => { if (b.initialPaid > 0) nonCash[b.paymentMethodName || 'Other'] = round2((nonCash[b.paymentMethodName || 'Other'] || 0) + b.initialPaid); });
  np.forEach((p) => { nonCash[p.methodName || 'Other'] = round2((nonCash[p.methodName || 'Other'] || 0) + p.amount); });
  const expected = round2(Number(shift.openingCash) + cashSales + cashOutstanding + cashIn - cashOut - cashRefunds);
  return { cashSales, cashOutstanding, cashIn, cashOut, cashRefunds, nonCash, expected };
}

// Detail lists printed on the closing report (all limited to one shift).
export async function shiftLists(shift) {
  const [txs, payments, cancelled, comps] = await Promise.all([
    list('cashTransactions', where('shiftId', '==', shift.id), where('receptionistUid', '==', shift.receptionistUid)),
    list('payments', where('shiftId', '==', shift.id)),
    list('bills', where('shiftId', '==', shift.id), where('status', '==', 'cancelled')),
    list('bills', where('shiftId', '==', shift.id), where('complimentary', '==', true)),
  ]);
  const byTime = (a, b) => (a.createdAt?.seconds || 0) - (b.createdAt?.seconds || 0);
  return { txs: txs.sort(byTime), payments: payments.sort(byTime), cancelled, comps };
}

export async function getBill(id) {
  const s = await getDoc(doc(db, 'bills', id));
  return s.exists() ? { id: s.id, ...s.data() } : null;
}

export async function countOf(coll, ...cons) {
  const { count } = await import('firebase/firestore');
  const r = await getAggregateFromServer(query(collection(db, coll), ...cons), { n: count() });
  return r.data().n;
}

// Next number of a per-receptionist counter (rc_ = slips, pc_ = balance payments, xc_ = cash entries).
// Works offline: it continues from the last number known on this computer.
export async function nextSeq(uid, prefix) {
  const key = `seq:${prefix}:${uid}`;
  const s = await fastGet(doc(db, 'counters', `${prefix}_${uid}`));
  if (s) { const v = s.exists() ? s.data().value : 0; localStorage.setItem(key, String(v)); return v + 1; }
  return Number(localStorage.getItem(key) || 0) + 1;
}
export const rememberSeq = (uid, prefix, v) => { try { localStorage.setItem(`seq:${prefix}:${uid}`, String(v)); } catch { /* ignore */ } };

export function licenseInfo(cfg) {
  const l = cfg?.license;
  if (!l) return { expired: false, blocked: false, daysLeft: null, mode: 'warn' };
  const ms = l.expiresAt?.toMillis ? l.expiresAt.toMillis() : l.expiresAt?.seconds ? l.expiresAt.seconds * 1000 : null;
  const expired = ms !== null && ms < Date.now();
  return { expired, blocked: expired && l.mode === 'block', daysLeft: ms === null ? null : Math.ceil((ms - Date.now()) / 86400000), mode: l.mode || 'warn', ms };
}
