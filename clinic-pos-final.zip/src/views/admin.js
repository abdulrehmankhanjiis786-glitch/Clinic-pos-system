import { collection, query, where, doc, getDoc, writeBatch, serverTimestamp, Timestamp, getAggregateFromServer, sum, count } from 'firebase/firestore';
import { initializeApp, deleteApp } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword, signOut } from 'firebase/auth';
import { db, firebaseConfig } from '../firebase.js';
import { toEmail, auditData } from '../auth.js';
import { checkUsername } from '../validation.js';
import { mountShell } from '../shell.js';
import { esc, $, startOfDay, modal, ask, toast } from '../util.js';
import { list, money, shiftTotals } from '../data.js';
import { round2 } from '../calc.js';
import { withDefaults } from '../config.js';
import { doctorsPage, servicesPage, methodsPage, settingsPage, permissionsPage, syncPriceList } from './catalog.js';
import { reportPage, revenuePage } from './reports.js';
import { backupPage } from './security.js';

let myUid = null;
const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const newCode = () => Array.from({ length: 4 }, () => CODE_CHARS[Math.floor(Math.random() * CODE_CHARS.length)]).join('');

// Creates the sign-in with a temporary second app connection (so the Admin stays signed in), then the profile,
// its unique receipt code and default permissions together.
async function createStaff(f) {
  const problem = checkUsername(f.username);
  if (problem) throw new Error(problem);
  const username = f.username.toLowerCase();
  if (f.password.length < 10) throw new Error('Password must be at least 10 characters.');
  const tmp = initializeApp(firebaseConfig, 'tmp-' + Date.now());
  let uid;
  try {
    const a = getAuth(tmp);
    uid = (await createUserWithEmailAndPassword(a, toEmail(username), f.password)).user.uid;
    await signOut(a);
  } catch (e) {
    if (e.code === 'auth/email-already-in-use') throw new Error('That username is already taken.');
    throw new Error('Could not create the sign-in. Check the details and try again.');
  } finally { await deleteApp(tmp); }
  for (let attempt = 0; attempt < 4; attempt++) {
    const code = newCode();
    const batch = writeBatch(db);
    batch.set(doc(db, 'receiptCodes', code), { uid, createdAt: serverTimestamp() });
    batch.set(doc(db, 'users', uid), { username, displayName: f.displayName.trim(), role: 'receptionist', recoveryEmail: f.recoveryEmail.trim().toLowerCase(),
      disabled: false, receiptCode: code, createdAt: serverTimestamp(), createdBy: myUid });
    batch.set(doc(db, 'staffLimits', uid), { ...withDefaults({}), updatedAt: serverTimestamp(), updatedBy: myUid });
    batch.set(doc(collection(db, 'auditLogs')), auditData(myUid, 'admin', 'user.create', 'user', uid, { username }));
    try { await batch.commit(); return; } catch (e) { if (attempt === 3) throw new Error('The sign-in was created but the profile was not saved. Use a different username and try again.'); }
  }
}


// Brings accounts made by an older version up to date (receipt code, permission flags). Safe to repeat.
async function upgradeAccounts(ctx) {
  const [users, limits] = await Promise.all([list('users', where('role', '==', 'receptionist')), list('staffLimits')]);
  for (const u of users) {
    if (!u.receiptCode) {
      for (let i = 0; i < 4; i++) {
        const code = newCode(); const b = writeBatch(db);
        b.set(doc(db, 'receiptCodes', code), { uid: u.id, createdAt: serverTimestamp() });
        b.update(doc(db, 'users', u.id), { receiptCode: code });
        try { await b.commit(); break; } catch { /* try another code */ }
      }
    }
    const l = limits.find((x) => x.id === u.id);
    if (!l || !('canCashIn' in l)) {
      const o = l || {};
      const b = writeBatch(db);
      b.set(doc(db, 'staffLimits', u.id), { ...withDefaults({}), maxDiscountPercent: o.maxDiscountPercent ?? 0, maxDiscountFixed: o.maxDiscountFixed ?? 0,
        canDiscount: (o.maxDiscountPercent || 0) > 0 || (o.maxDiscountFixed || 0) > 0, canCashOut: o.canCashOut ?? false, cashOutLimit: o.cashOutLimit ?? 0,
        updatedAt: serverTimestamp(), updatedBy: ctx.uid });
      try { await b.commit(); } catch (e) { console.error('Permission upgrade failed', e.code); }
    }
  }
}

export function renderAdmin(root, name, uid) {
  myUid = uid;
  const ctx = { uid, name, role: 'admin' };
  syncPriceList(ctx).catch((e) => console.error('Price list update failed:', e.code, e.message));
  upgradeAccounts(ctx).catch((e) => console.error('Account upgrade failed:', e.code, e.message));
  let shell;
  const go = (id) => shell.go(id);
  shell = mountShell(root, {
    brand: 'Clinic POS', roleLabel: 'Admin', name,
    nav: [
      { id: 'dashboard', label: 'Dashboard' }, { id: 'slips', label: "Today's Slips" }, { id: 'outstanding', label: 'Outstanding Balance' },
      { id: 'cancelled', label: 'Cancelled Slips' }, { id: 'comp', label: 'Complimentary' }, { id: 'cash', label: 'Cash In / Cash Out' },
      { id: 'shifts', label: 'Shift / Till Reports' }, { id: 'payments', label: 'Outstanding Payments' }, { id: 'revenue', label: 'Revenue & Activity' },
      { id: 'staff', label: 'Receptionists' }, { id: 'permissions', label: 'Permissions' }, { id: 'doctors', label: 'Doctors' }, { id: 'services', label: 'Services' },
      { id: 'lab', label: 'Lab / Tests' }, { id: 'methods', label: 'Payment Methods' }, { id: 'settings', label: 'Settings' }, { id: 'backup', label: 'Backup' },
    ],
    pages: {
      dashboard: (c) => dashboard(c, ctx, go), staff,
      slips: (c) => reportPage(c, ctx, 'slips'), outstanding: (c) => reportPage(c, ctx, 'outstanding'), cancelled: (c) => reportPage(c, ctx, 'cancelled'),
      comp: (c) => reportPage(c, ctx, 'comp'), cash: (c) => reportPage(c, ctx, 'cash'), shifts: (c) => reportPage(c, ctx, 'shifts'),
      payments: (c) => reportPage(c, ctx, 'payments'), revenue: (c) => revenuePage(c, ctx), permissions: (c) => permissionsPage(c, ctx),
      doctors: (c) => doctorsPage(c, ctx), services: (c) => servicesPage(c, ctx, 'service'), lab: (c) => servicesPage(c, ctx, 'lab'),
      methods: (c) => methodsPage(c, ctx), settings: (c) => settingsPage(c, ctx), backup: (c) => backupPage(c, ctx),
    },
  });
  return shell;
}

// Hospital staff only (the security rules never return any other account type).
async function loadUsers() {
  const [admins, recs] = await Promise.all([list('users', where('role', '==', 'admin')), list('users', where('role', '==', 'receptionist'))]);
  return [...recs, ...admins];
}
const agg = async (coll, cons) => (await getAggregateFromServer(query(collection(db, coll), ...cons), { n: count(), net: sum('net'), out: sum('outstanding') })).data();

async function dashboard(c, ctx, go) {
  c.innerHTML = '<p class="muted">Loading…</p>';
  try {
    const start = Timestamp.fromDate(startOfDay());
    const [today, owing, cancelled, comp, users, open, presence] = await Promise.all([
      agg('bills', [where('status', '==', 'posted'), where('createdAt', '>=', start)]), agg('bills', [where('owing', '==', true)]),
      agg('bills', [where('status', '==', 'cancelled'), where('createdAt', '>=', start)]), agg('bills', [where('complimentary', '==', true), where('createdAt', '>=', start)]),
      loadUsers(), list('openShifts'), list('presence'),
    ]);
    const shifts = (await Promise.all(open.map(async (o) => { const s = await getDoc(doc(db, 'shifts', o.shiftId)); return s.exists() ? { id: s.id, ...s.data() } : null; }))).filter(Boolean);
    const till = await Promise.all(shifts.slice(0, 10).map(async (s) => ({ s, t: await shiftTotals(s) })));
    const recs = users.filter((u) => u.role === 'receptionist' && !u.disabled);
    const online = (u) => { const p = presence.find((x) => x.id === u.id); return p?.lastSeen?.toDate && Date.now() - p.lastSeen.toDate().getTime() < 180000; };
    const tile = (n, l, page) => `<button class="tile" data-go="${page}"><span class="num">${n}</span>${l}</button>`;
    c.innerHTML = `<div class="tiles">${tile(today.n, `Today's slips · ${money(round2(today.net || 0))}`, 'slips')}${tile(money(round2(owing.out || 0)), 'Outstanding balance', 'outstanding')}
      ${tile(cancelled.n, 'Cancelled slips today', 'cancelled')}${tile(comp.n, 'Complimentary today', 'comp')}${tile(shifts.length, 'Open shifts', 'shifts')}${tile(recs.filter(online).length + ' / ' + recs.length, 'Receptionists online', 'staff')}</div>
      <div class="card" style="margin-top:14px"><h2>Live till</h2>${till.length ? `<table><thead><tr><th>Receptionist</th><th>Shift</th><th class="right">Opening</th><th class="right">Cash sales</th><th class="right">Cash in</th><th class="right">Cash out</th><th class="right">Total cash now</th></tr></thead><tbody>
        ${till.map(({ s, t }) => `<tr><td>${esc(s.receptionistName)}</td><td>${esc(s.shiftName)}</td><td class="right">${money(s.openingCash)}</td><td class="right">${money(t.cashSales + t.cashOutstanding)}</td><td class="right">${money(t.cashIn)}</td><td class="right">${money(t.cashOut)}</td><td class="right"><strong>${money(t.expected)}</strong></td></tr>`).join('')}</tbody></table>` : '<p class="muted">No shift is open.</p>'}</div>
      <div class="card"><h2>Receptionist status</h2><table><thead><tr><th>Receptionist</th><th>Connection</th><th>Shift</th></tr></thead><tbody>
        ${recs.map((u) => `<tr><td>${esc(u.displayName)}</td><td><span class="pill ${online(u) ? 'on' : 'off'}">${online(u) ? 'Online' : 'Offline'}</span></td><td>${shifts.some((s) => s.receptionistUid === u.id) ? '<span class="pill part">Open</span>' : 'Closed'}</td></tr>`).join('') || '<tr><td colspan="3" class="muted">No receptionists.</td></tr>'}</tbody></table></div>`;
    c.querySelectorAll('[data-go]').forEach((b) => (b.onclick = () => go(b.dataset.go)));
  } catch (e) { console.error('Dashboard failed', e.code, e.message); c.innerHTML = '<div class="card error">Could not load the dashboard. Check your connection.</div>'; }
}

async function staff(c) {
  c.innerHTML = `<div class="card"><h2>Add receptionist</h2><form id="f" class="grid2">
    <label>Username<input name="username" required minlength="3" maxlength="30" pattern="[A-Za-z0-9._\\-]{3,30}" title="3-30 characters: letters, numbers, dot, dash or underscore. No spaces." autocomplete="off"></label>
    <label>Full name<input name="displayName" required autocomplete="off"></label><label>Recovery email<input name="recoveryEmail" type="email" required autocomplete="off"></label>
    <label>Temporary password (10+ characters)<input name="password" type="password" minlength="10" required autocomplete="new-password"></label>
    <div class="row-end"><span id="msg" class="muted"></span><button class="btn primary">Create account</button></div></form></div>
    <div class="card"><h2>Accounts</h2><div id="list" class="muted">Loading…</div></div>`;
  const box = $('#list', c);
  async function refresh() {
    try {
      const users = (await loadUsers()).sort((a, b) => a.username.localeCompare(b.username));
      box.className = '';
      box.innerHTML = `<table><thead><tr><th>Username</th><th>Name</th><th>Recovery email</th><th>Receipt code</th><th>Status</th><th></th></tr></thead><tbody>${users.map((u) => `<tr>
        <td>${esc(u.username)}</td><td>${esc(u.displayName)}</td><td>${esc(u.recoveryEmail)}</td><td>${esc(u.receiptCode || '-')}</td>
        <td><span class="pill ${u.disabled ? 'off' : 'on'}">${u.disabled ? 'Disabled' : 'Active'}</span></td>
        <td class="row-gap">${u.role === 'admin' ? '' : `<button class="btn small" data-dis="${esc(u.id)}">${u.disabled ? 'Enable' : 'Disable'}</button><button class="btn small" data-mail="${esc(u.id)}">Recovery email</button>
          ${u.receiptCode ? '' : `<button class="btn small" data-code="${esc(u.id)}">Assign code</button>`}<button class="btn small" data-pw="${esc(u.username)}">Reset password</button><button class="btn small" data-del="${esc(u.id)}">Delete</button>`}</td></tr>`).join('')}</tbody></table>
        <p class="muted" style="margin-top:8px">A disabled receptionist can finish the current session but cannot sign in again.</p>`;
      const find = (id) => users.find((x) => x.id === id);
      const run = async (batch) => { try { await batch.commit(); refresh(); } catch (e) { console.error(e); toast('Could not save.', true); } };
      box.querySelectorAll('[data-dis]').forEach((b) => (b.onclick = () => { const u = find(b.dataset.dis); const batch = writeBatch(db);
        batch.update(doc(db, 'users', u.id), u.disabled ? { disabled: false } : { disabled: true, disabledAtSec: Math.floor(Date.now() / 1000) });
        batch.set(doc(collection(db, 'auditLogs')), auditData(myUid, 'admin', u.disabled ? 'user.enable' : 'user.disable', 'user', u.id)); run(batch); }));
      box.querySelectorAll('[data-mail]').forEach((b) => (b.onclick = () => {
        const email = (prompt('New recovery email:') || '').trim().toLowerCase();
        if (!email) return;
        if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) { toast('Enter a valid email address.', true); return; }
        const batch = writeBatch(db); batch.update(doc(db, 'users', b.dataset.mail), { recoveryEmail: email });
        batch.set(doc(collection(db, 'auditLogs')), auditData(myUid, 'admin', 'user.recoveryEmail', 'user', b.dataset.mail)); run(batch); }));
      box.querySelectorAll('[data-code]').forEach((b) => (b.onclick = async () => {
        for (let i = 0; i < 4; i++) {
          const code = newCode(); const batch = writeBatch(db);
          batch.set(doc(db, 'receiptCodes', code), { uid: b.dataset.code, createdAt: serverTimestamp() });
          batch.update(doc(db, 'users', b.dataset.code), { receiptCode: code });
          try { await batch.commit(); refresh(); return; } catch { /* try another code */ }
        }
        toast('Could not assign a code.', true); }));
      box.querySelectorAll('[data-pw]').forEach((b) => (b.onclick = () => { const m = modal(`<h2>Reset password</h2><p>The receptionist can change their own password after signing in (top bar → Change password).</p>
        <p>If the password was forgotten, the system administrator resets it with the reset tool using the username <strong>${esc(b.dataset.pw)}</strong>.</p><div class="row-gap" style="justify-content:flex-end"><button class="btn primary" id="ok">OK</button></div>`); $('#ok', m.el).onclick = m.close; }));
      box.querySelectorAll('[data-del]').forEach((b) => (b.onclick = async () => {
        const u = find(b.dataset.del);
        if (!(await ask('Delete receptionist?', `${u.displayName} will no longer be able to use the system. Their past slips and reports stay.`, 'Delete'))) return;
        const batch = writeBatch(db); batch.delete(doc(db, 'users', u.id)); batch.delete(doc(db, 'staffLimits', u.id));
        batch.set(doc(collection(db, 'auditLogs')), auditData(myUid, 'admin', 'user.delete', 'user', u.id, { username: u.username })); run(batch); }));
    } catch { box.innerHTML = '<span class="error">Could not load accounts.</span>'; }
  }
  $('#f', c).onsubmit = async (e) => {
    e.preventDefault();
    const f = e.target, msg = $('#msg', c);
    msg.className = 'muted'; msg.textContent = 'Creating…';
    try { await createStaff({ username: f.username.value, displayName: f.displayName.value, recoveryEmail: f.recoveryEmail.value, password: f.password.value });
      f.reset(); msg.textContent = 'Account created.'; refresh(); }
    catch (ex) { msg.className = 'error'; msg.textContent = ex.message || 'Could not create the account.'; }
  };
  refresh();
}
