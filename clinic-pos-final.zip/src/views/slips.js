// Slip lists (Today's Slips, Search, Cancelled, Complimentary) and the slip detail with Reprint / Cancel / Refund / Restore.
import { collection, doc, getDoc, runTransaction, serverTimestamp, where, orderBy, Timestamp } from 'firebase/firestore';
import { db, auth } from '../firebase.js';
import { auditData, writeAudit } from '../auth.js';
import { esc, $, fmtTime, modal, toast, startOfDay, endOfDay, dateInput, parseDateInput } from '../util.js';
import { page, getBill, money } from '../data.js';
import { billRows, parseMoney, round2 } from '../calc.js';
import { billStatus, statusClass, printBill } from './receipt.js';
import { isOnline } from '../offline.js';

const RECEIPT = /^[A-Za-z0-9]{3,8}-\d{6}$/;
const errCard = '<div class="card error">Could not load data. Check your connection and try again.</div>';

// Builds the Firestore query for a slip list. Only the needed records are fetched (never the whole history).
export function slipQuery({ uid, from, to, q, mode }) {
  const text = (q || '').trim();
  if (RECEIPT.test(text)) return { single: text.toUpperCase() };
  const mine = uid ? [where('receptionistUid', '==', uid)] : [];
  const m = mode === 'cancelled' ? [where('status', '==', 'cancelled')] : mode === 'comp' ? [where('complimentary', '==', true)] : [];
  if (text) {
    const p = text.toLowerCase();
    return { cons: [...mine, ...m, where('patientLower', '>=', p), where('patientLower', '<=', p + '\uf8ff'), orderBy('patientLower')] };
  }
  return { cons: [...mine, ...m, where('createdAt', '>=', Timestamp.fromDate(from)), where('createdAt', '<=', Timestamp.fromDate(to)), orderBy('createdAt', 'desc')] };
}

// ---------- the list ----------
export async function slipsPage(c, ctx, mode = 'today') {
  const isRecep = ctx.role === 'receptionist';
  const title = { today: "Today's Slips", search: 'Search slips', cancelled: 'Cancelled Slips', comp: 'Complimentary' }[mode];
  const t0 = new Date();
  const f = { from: mode === 'search' ? new Date(t0.getTime() - 30 * 86400000) : t0, to: t0, q: '' };
  c.innerHTML = `<div class="card"><div class="row-gap" style="margin-bottom:8px"><h2 style="margin:0">${title}</h2><span class="grow"></span>
      <label class="inl">From<input type="date" id="df" value="${dateInput(f.from)}"></label><label class="inl">To<input type="date" id="dt" value="${dateInput(f.to)}"></label>
      <input id="q" class="search" placeholder="Receipt no. or patient name (Ctrl+F)"><button class="btn small primary" id="go">Search</button></div>
    <div id="out"></div><div class="row-gap" style="margin-top:8px"><button class="btn small" id="more" style="display:none">Load more</button></div></div><div id="panel"></div>`;
  let after = null;
  let rows = [];
  const cfg = ctx.cfg();
  async function load(reset) {
    if (reset) { after = null; rows = []; }
    f.q = $('#q', c).value;
    f.from = startOfDay(parseDateInput($('#df', c).value)); f.to = endOfDay(parseDateInput($('#dt', c).value));
    const sq = slipQuery({ uid: isRecep ? ctx.uid : null, from: f.from, to: f.to, q: f.q, mode });
    try {
      if (sq.single) { const b = await getBill(sq.single); rows = b ? [b] : []; after = null; $('#more', c).style.display = 'none'; }
      else {
        const r = await page('bills', sq.cons, after);
        rows = rows.concat(r.rows); after = r.last; $('#more', c).style.display = r.more ? '' : 'none';
      }
    } catch { $('#out', c).innerHTML = errCard; return; }
    draw();
  }
  function draw() {
    $('#out', c).innerHTML = rows.length
      ? `<table><thead><tr><th>Receipt</th><th>Time</th><th>Patient</th><th class="right">Net</th><th class="right">Paid</th><th class="right">Balance</th><th>Status</th><th></th></tr></thead><tbody>
        ${rows.map((b) => `<tr><td>${esc(b.receiptNo)}</td><td>${esc(fmtTime(b.createdAt))}</td><td>${esc(b.patientName)}</td><td class="right">${money(b.net)}</td>
          <td class="right">${money(b.received)}</td><td class="right">${money(b.outstanding)}</td><td><span class="pill ${statusClass(b)}">${billStatus(b)}</span></td>
          <td><button class="btn small" data-id="${esc(b.id)}">Review</button></td></tr>`).join('')}</tbody></table>`
      : '<p class="muted">No slips found.</p>';
    c.querySelectorAll('button[data-id]').forEach((b) => (b.onclick = () => slipPanel($('#panel', c), rows.find((x) => x.id === b.dataset.id), ctx, cfg, () => load(true))));
  }
  $('#go', c).onclick = () => load(true);
  $('#more', c).onclick = () => load(false);
  $('#q', c).onkeydown = (e) => { if (e.key === 'Enter') load(true); };
  ctx.focusSearch = () => $('#q', c).focus();
  await load(true);
}

// ---------- slip detail + actions ----------
export async function slipPanel(host, bill, ctx, cfg, changed) {
  host.innerHTML = '<div class="card muted">Loading…</div>';
  const fresh = (await getBill(bill.id)) || bill;
  let pays = [];
  try { pays = (await page('payments', [where('billId', '==', fresh.id)], null, 50)).rows.sort((a, b) => (a.createdAt?.seconds || 0) - (b.createdAt?.seconds || 0)); } catch { /* empty history */ }
  const lim = cfg.limits || {};
  let canCancel = false, canRestore = false;
  if (ctx.role === 'receptionist') {
    const sh = ctx.shift?.();
    canCancel = Boolean(lim.canCancel && fresh.status === 'posted' && sh && sh.id === fresh.shiftId);
    canRestore = Boolean(lim.canRestore && fresh.status === 'cancelled' && sh && sh.id === fresh.cancelShiftId);
  } else if (fresh.status === 'cancelled' && fresh.cancelShiftId) {
    const s = await getDoc(doc(db, 'shifts', fresh.cancelShiftId)).catch(() => null);
    canRestore = Boolean(s?.exists() && s.data().status === 'open');
  }
  host.innerHTML = `<div class="card"><h2>${esc(fresh.receiptNo)} <span class="pill ${statusClass(fresh)}">${billStatus(fresh)}</span></h2>
    <p>${esc(fresh.patientName)}, ${esc(fresh.age)} / ${esc(fresh.gender)} · Doctor: ${esc(fresh.doctorName || '-')} · ${esc(fmtTime(fresh.createdAt))} · by ${esc(fresh.receptionistName)}</p>
    <table><thead><tr><th>S.No</th><th>Service</th><th class="right">Discount</th><th class="right">Qty</th><th class="right">Rate</th><th class="right">Total</th></tr></thead><tbody>
      ${billRows(fresh).map((r, i) => `<tr><td>${i + 1}</td><td>${r.kind === 'doctor' ? 'Consultation: ' : ''}${esc(r.name)}</td><td class="right">${money(r.discount || 0)}</td><td class="right">${r.qty}</td><td class="right">${money(r.rate)}</td><td class="right">${money(r.lineTotal)}</td></tr>`).join('')}</tbody></table>
    <table class="tot"><tbody><tr><td>Subtotal</td><td class="right">${money(fresh.gross)}</td></tr><tr><td>Discount</td><td class="right">${money(fresh.discount || 0)}</td></tr>
      ${fresh.compAmount > 0 ? `<tr><td>Complimentary (${esc(fresh.compReason)})</td><td class="right">${money(fresh.compAmount)}</td></tr>` : ''}
      <tr class="big"><td>Grand total</td><td class="right">${money(fresh.net)}</td></tr>
      <tr><td>Paid at billing (${esc(fresh.paymentMethodName)})</td><td class="right">${money(fresh.initialPaid ?? fresh.received)}</td></tr>
      <tr><td>Outstanding</td><td class="right">${money(fresh.outstanding)}</td></tr></tbody></table>
    ${pays.length ? `<h3 class="sec-title">Later payments</h3><table><tbody>${pays.map((p) => `<tr><td>${esc(p.paymentNo || '')}</td><td>${esc(fmtTime(p.createdAt))}</td><td>${esc(p.methodName)}</td><td>${esc(p.receptionistName)}</td><td class="right">${money(p.amount)}</td></tr>`).join('')}</tbody></table>` : ''}
    ${fresh.status === 'cancelled' ? `<p class="error">Cancelled ${esc(fmtTime(fresh.cancelledAt))} by ${esc(fresh.cancelledByName)}. Reason: ${esc(fresh.cancelReason)}${fresh.refundAmount > 0 ? ` · Refund ${money(fresh.refundAmount)}` : ''}</p>` : ''}
    <div class="row-gap"><button class="btn primary" id="rp">Reprint</button>
      ${canCancel ? '<button class="btn" id="cx">Cancel slip</button>' : ''}${canRestore ? '<button class="btn" id="rs">Restore slip</button>' : ''}<span id="pm" class="muted"></span></div></div>`;
  $('#rp', host).onclick = () => {
    if (!printBill(cfg, fresh)) toast('The printer did not respond. The slip is saved; try again.', true);
    writeAudit(auth.currentUser.uid, ctx.role, 'receipt.reprint', 'bill', fresh.id).catch(() => {});
  };
  const cx = $('#cx', host);
  if (cx) cx.onclick = () => cancelDialog(fresh, ctx, lim, () => { changed(); });
  const rs = $('#rs', host);
  if (rs) rs.onclick = () => restoreDialog(fresh, ctx, () => { changed(); });
}

function reasonDialog({ title, extra = '', confirm }) {
  return new Promise((resolve) => {
    const m = modal(`<h2>${esc(title)}</h2>${extra}<label>Reason (required)<input id="why" maxlength="200" autocomplete="off"></label><div id="e" class="error"></div>
      <div class="row-gap" style="justify-content:flex-end"><button class="btn" id="n">Back</button><button class="btn primary" id="y">${esc(confirm)}</button></div>`);
    $('#n', m.el).onclick = () => { m.close(); resolve(null); };
    $('#y', m.el).onclick = () => {
      const why = $('#why', m.el).value.trim();
      if (why.length < 3) { $('#e', m.el).textContent = 'Please write the reason.'; return; }
      const r = { why, refund: $('#rf', m.el)?.value };
      m.close(); resolve(r);
    };
    $('#why', m.el).focus();
  });
}

async function cancelDialog(bill, ctx, lim, done) {
  if (!isOnline()) { toast('Cancel needs the internet. Please try again when it is back.', true); return; }
  const canRefund = lim.canRefund && bill.received > 0;
  const r = await reasonDialog({ title: `Cancel ${bill.receiptNo}`, confirm: 'Cancel slip',
    extra: canRefund ? `<label>Refund amount (max ${money(bill.received)}; 0 for none)<input id="rf" inputmode="decimal" value="0"></label>` : '' });
  if (!r) return;
  let refund = 0;
  if (canRefund) {
    refund = parseMoney(r.refund, true);
    if (refund === null || refund > round2(bill.received) + 0.004) { toast('Refund cannot be more than the amount received.', true); return; }
  }
  try {
    await runTransaction(db, async (tx) => {
      const ref = doc(db, 'bills', bill.id);
      const b = (await tx.get(ref)).data();
      if (b.status !== 'posted') throw new Error('changed');
      tx.update(ref, { status: 'cancelled', cancelledAt: serverTimestamp(), cancelledBy: ctx.uid, cancelledByName: ctx.name, cancelReason: r.why,
        cancelShiftId: b.shiftId, cancelledOutstanding: b.outstanding, outstanding: 0, owing: false, refundAmount: refund,
        refundIsCash: refund > 0 ? Boolean(b.isCash) : false, refundShiftId: refund > 0 ? b.shiftId : '' });
      tx.set(doc(collection(db, 'auditLogs')), auditData(ctx.uid, ctx.role, 'bill.cancel', 'bill', bill.id, { refund }));
    });
    toast('Slip cancelled.');
    done();
  } catch (e) { toast(e.code === 'permission-denied' ? 'You are not allowed to cancel this slip now (shift, permission or refund).' : 'Could not cancel. Check the internet and try again.', true); }
}

async function restoreDialog(bill, ctx, done) {
  if (!isOnline()) { toast('Restore needs the internet.', true); return; }
  const r = await reasonDialog({ title: `Restore ${bill.receiptNo}`, confirm: 'Restore slip' });
  if (!r) return;
  try {
    await runTransaction(db, async (tx) => {
      const ref = doc(db, 'bills', bill.id);
      const b = (await tx.get(ref)).data();
      if (b.status !== 'cancelled') throw new Error('changed');
      tx.update(ref, { status: 'posted', restoredAt: serverTimestamp(), restoredBy: ctx.uid, restoredByName: ctx.name, restoreReason: r.why,
        outstanding: b.cancelledOutstanding, owing: b.cancelledOutstanding > 0.004, cancelledOutstanding: 0, refundAmount: 0, refundIsCash: false, refundShiftId: '' });
      tx.set(doc(collection(db, 'auditLogs')), auditData(ctx.uid, ctx.role, 'bill.restore', 'bill', bill.id));
    });
    toast('Slip restored.');
    done();
  } catch (e) { toast(e.code === 'permission-denied' ? 'Restore is only possible while the shift of the cancellation is still open.' : 'Could not restore. Try again.', true); }
}
