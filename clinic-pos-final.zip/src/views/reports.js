// Admin reports. Every report has its own search, filters and date range, and loads one page at a time.
import { collection, doc, getAggregateFromServer, getDoc, query, where, orderBy, sum, count, Timestamp } from 'firebase/firestore';
import { db } from '../firebase.js';
import { esc, $, fmtTime, startOfDay, endOfDay, dateInput, parseDateInput, toast } from '../util.js';
import { page, money, list, round2 } from '../data.js';
import { slipQuery, slipPanel } from './slips.js';
import { balStatus } from './balances.js';
import { billStatus, statusClass } from './receipt.js';
import { shiftReport, reopenShift } from './shift.js';
import { getConfig } from '../config.js';

const errCard = '<div class="card error">Could not load data. Check your connection and try again.</div>';
const ts = (d) => Timestamp.fromDate(d);

// kind -> how to query and draw it
const KINDS = {
  slips: { title: "Today's Slips", bills: 'all', cols: ['Receipt', 'Time', 'Patient', 'Receptionist', 'Net', 'Paid', 'Balance', 'Status'] },
  outstanding: { title: 'Outstanding Balances', bills: 'owing' },
  cancelled: { title: 'Cancelled Slips', bills: 'cancelled' },
  comp: { title: 'Complimentary', bills: 'comp' },
  cash: { title: 'Cash In / Cash Out' }, payments: { title: 'Outstanding Payment History' }, shifts: { title: 'Shift and Till Close Reports' },
};

export async function reportPage(c, ctx, kind) {
  const K = KINDS[kind];
  const cfg = await getConfig('admin');
  let staff = [];
  try { staff = await list('users', where('role', '==', 'receptionist')); } catch { /* filter shows no names */ }
  const isBills = Boolean(K.bills);
  const today = new Date();
  c.innerHTML = `<div class="card"><div class="row-gap" style="margin-bottom:8px"><h2 style="margin:0">${K.title}</h2><span class="grow"></span>
    <label class="inl">From<input type="date" id="df" value="${dateInput(today)}"></label><label class="inl">To<input type="date" id="dt" value="${dateInput(today)}"></label>
    ${kind === 'cash' || kind === 'payments' ? '' : `<select id="rc" class="inline" style="width:170px"><option value="">All receptionists</option>${staff.map((u) => `<option value="${esc(u.id)}">${esc(u.displayName)}</option>`).join('')}</select>`}
    ${isBills ? '<input id="q" class="search" placeholder="Receipt no. or patient name">' : ''}${kind === 'cash' ? '<select id="ty" class="inline" style="width:120px"><option value="">All</option><option value="in">Cash In</option><option value="out">Cash Out</option></select>' : ''}
    <button class="btn small primary" id="go">Show</button></div>
    <div id="sum" class="muted"></div><div id="out"></div><button class="btn small" id="more" style="display:none;margin-top:8px">Load more</button></div><div id="panel"></div>`;
  let after = null, rows = [];

  function constraints() {
    const from = startOfDay(parseDateInput($('#df', c).value)), to = endOfDay(parseDateInput($('#dt', c).value));
    const rc = $('#rc', c)?.value;
    if (isBills) {
      const text = $('#q', c).value;
      const base = slipQuery({ uid: rc || null, from, to, q: text, mode: kind === 'cancelled' ? 'cancelled' : kind === 'comp' ? 'comp' : 'all' });
      if (base.single || kind !== 'outstanding') return base;
      // outstanding: unpaid and partly paid slips
      if (text) { const p = text.toLowerCase(); return { cons: [where('owing', '==', true), ...(rc ? [where('receptionistUid', '==', rc)] : []), where('patientLower', '>=', p), where('patientLower', '<=', p + '\uf8ff'), orderBy('patientLower')] }; }
      return { cons: [where('owing', '==', true), ...(rc ? [where('receptionistUid', '==', rc)] : []), where('createdAt', '>=', ts(from)), where('createdAt', '<=', ts(to)), orderBy('createdAt', 'desc')] };
    }
    if (kind === 'cash') { const ty = $('#ty', c).value; return { coll: 'cashTransactions', cons: [...(ty ? [where('type', '==', ty)] : []), where('createdAt', '>=', ts(from)), where('createdAt', '<=', ts(to)), orderBy('createdAt', 'desc')] }; }
    if (kind === 'payments') return { coll: 'payments', cons: [where('createdAt', '>=', ts(from)), where('createdAt', '<=', ts(to)), orderBy('createdAt', 'desc')] };
    return { coll: 'shifts', cons: [...(rc ? [where('receptionistUid', '==', rc)] : []), where('openedAt', '>=', ts(from)), where('openedAt', '<=', ts(to)), orderBy('openedAt', 'desc')] };
  }
  async function load(reset) {
    if (reset) { after = null; rows = []; }
    const q = constraints();
    try {
      if (q.single) { const s = await getDoc(doc(db, 'bills', q.single)); rows = s.exists() ? [{ id: s.id, ...s.data() }] : []; $('#more', c).style.display = 'none'; }
      else { const r = await page(q.coll || 'bills', q.cons, after); rows = rows.concat(r.rows); after = r.last; $('#more', c).style.display = r.more ? '' : 'none'; }
    } catch { $('#out', c).innerHTML = errCard; return; }
    draw();
  }
  function draw() {
    const out = $('#out', c);
    if (!rows.length) { out.innerHTML = '<p class="muted">Nothing found.</p>'; return; }
    if (isBills) {
      out.innerHTML = `<table><thead><tr><th>Receipt</th><th>Time</th><th>Patient</th><th>Receptionist</th><th class="right">Net</th><th class="right">Paid</th><th class="right">Balance</th><th>Status</th><th></th></tr></thead><tbody>
        ${rows.map((b) => `<tr><td>${esc(b.receiptNo)}</td><td>${esc(fmtTime(b.createdAt))}</td><td>${esc(b.patientName)}</td><td>${esc(b.receptionistName)}</td><td class="right">${money(b.net)}</td>
          <td class="right">${money(b.received)}</td><td class="right">${money(b.outstanding)}</td>
          <td><span class="pill ${kind === 'outstanding' ? ({ Paid: 'paid', Unpaid: 'unpaid', 'Partially Paid': 'part' }[balStatus(b)]) : statusClass(b)}">${kind === 'outstanding' ? balStatus(b) : billStatus(b)}</span></td>
          <td><button class="btn small" data-id="${esc(b.id)}">View</button></td></tr>`).join('')}</tbody></table>`;
      c.querySelectorAll('button[data-id]').forEach((b) => (b.onclick = () => slipPanel($('#panel', c), rows.find((x) => x.id === b.dataset.id), ctx, cfg, () => load(true))));
    } else if (kind === 'cash') {
      out.innerHTML = `<table><thead><tr><th>Reference</th><th>Time</th><th>Receptionist</th><th>Type</th><th class="right">Amount</th><th>Remarks</th></tr></thead><tbody>${rows.map((x) =>
        `<tr><td>${esc(x.reference || x.id)}</td><td>${esc(fmtTime(x.createdAt))}</td><td>${esc(x.receptionistName)}</td><td>${x.type === 'in' ? 'Cash In' : 'Cash Out'}</td><td class="right">${money(x.amount)}</td><td>${esc(x.reason)}</td></tr>`).join('')}</tbody></table>`;
    } else if (kind === 'payments') {
      out.innerHTML = `<table><thead><tr><th>Reference</th><th>Time</th><th>Patient</th><th>Slip</th><th>Method</th><th>Receptionist</th><th class="right">Amount</th></tr></thead><tbody>${rows.map((p) =>
        `<tr><td>${esc(p.paymentNo)}</td><td>${esc(fmtTime(p.createdAt))}</td><td>${esc(p.patientName)}</td><td>${esc(p.receiptNo)}</td><td>${esc(p.methodName)}</td><td>${esc(p.receptionistName)}</td><td class="right">${money(p.amount)}</td></tr>`).join('')}</tbody></table>`;
    } else {
      out.innerHTML = `<table><thead><tr><th>Opened</th><th>Receptionist</th><th>Shift</th><th>Status</th><th class="right">Opening</th><th class="right">Difference</th><th></th></tr></thead><tbody>${rows.map((s) =>
        `<tr><td>${esc(fmtTime(s.openedAt))}</td><td>${esc(s.receptionistName)}</td><td>${esc(s.shiftName)}</td><td><span class="pill ${s.status === 'open' ? 'warn' : 'on'}">${s.status === 'open' ? 'Open' : 'Closed'}</span></td>
          <td class="right">${money(s.openingCash)}</td><td class="right">${s.status === 'closed' ? money(s.difference) : ''}</td><td><button class="btn small" data-sid="${esc(s.id)}">Report</button></td></tr>`).join('')}</tbody></table>`;
      c.querySelectorAll('[data-sid]').forEach((b) => (b.onclick = async () => {
        const s = rows.find((x) => x.id === b.dataset.sid);
        const p = $('#panel', c);
        p.innerHTML = '';
        if (s.status === 'closed') {
          const bar = document.createElement('div');
          bar.className = 'card no-print';
          bar.innerHTML = '<div class="row-gap"><strong>Reopen this shift</strong><input class="inline" style="max-width:340px" id="why" placeholder="Reason (required)" maxlength="200"><button class="btn small" id="re">Reopen</button><span id="rm" class="error"></span></div>';
          p.appendChild(bar);
          $('#re', bar).onclick = async () => {
            const why = $('#why', bar).value.trim();
            if (why.length < 5) { $('#rm', bar).textContent = 'Write a reason (at least 5 characters).'; return; }
            try { await reopenShift(s, ctx, why); toast('Shift reopened.'); load(true); } catch { $('#rm', bar).textContent = 'Could not reopen (that receptionist may already have an open shift).'; }
          };
        }
        await shiftReport(p, s, cfg);
      }));
    }
  }
  $('#go', c).onclick = () => load(true);
  $('#more', c).onclick = () => load(false);
  $('#q', c)?.addEventListener('keydown', (e) => { if (e.key === 'Enter') load(true); });
  await load(true);
}

// ---------- revenue / activity (server-side totals, nothing is downloaded) ----------
const agg = async (cons) => {
  const r = await getAggregateFromServer(query(collection(db, 'bills'), ...cons), { n: count(), net: sum('net'), paid: sum('initialPaid'), disc: sum('discount'), comp: sum('compAmount') });
  const d = r.data();
  return { n: d.n, net: round2(d.net || 0), paid: round2(d.paid || 0), disc: round2(d.disc || 0), comp: round2(d.comp || 0) };
};
export async function revenuePage(c, ctx) {
  const cfg = await getConfig('admin');
  let staff = [];
  try { staff = await list('users', where('role', '==', 'receptionist')); } catch { /* ignore */ }
  const today = new Date();
  c.innerHTML = `<div class="card"><div class="row-gap"><h2 style="margin:0">Revenue and activity</h2><span class="grow"></span>
    <label class="inl">From<input type="date" id="df" value="${dateInput(today)}"></label><label class="inl">To<input type="date" id="dt" value="${dateInput(today)}"></label>
    <button class="btn small primary" id="go">Show</button></div><div id="out" class="muted" style="margin-top:10px"></div></div>`;
  $('#go', c).onclick = async () => {
    const from = startOfDay(parseDateInput($('#df', c).value)), to = endOfDay(parseDateInput($('#dt', c).value));
    const range = [where('createdAt', '>=', ts(from)), where('createdAt', '<=', ts(to))];
    $('#out', c).textContent = 'Loading…';
    try {
      const posted = (extra = []) => agg([where('status', '==', 'posted'), ...extra, ...range]);
      const [all, docs, recs] = await Promise.all([
        posted(),
        Promise.all(cfg.doctors.map(async (d) => ({ d, a: await posted([where('doctorId', '==', d.id)]) }))),
        Promise.all(staff.map(async (u) => ({ u, a: await posted([where('receptionistUid', '==', u.id)]) }))),
      ]);
      const rowsHtml = (arr, name) => arr.filter((x) => x.a.n).map((x) => `<tr><td>${esc(name(x))}</td><td class="right">${x.a.n}</td><td class="right">${money(x.a.net)}</td><td class="right">${money(x.a.paid)}</td></tr>`).join('') || '<tr><td colspan="4" class="muted">No slips.</td></tr>';
      $('#out', c).className = '';
      $('#out', c).innerHTML = `<div class="cards"><div class="card stat"><span class="num">${all.n}</span><span>Slips</span></div><div class="card stat"><span class="num">${money(all.net)}</span><span>Total billed</span></div>
        <div class="card stat"><span class="num">${money(all.paid)}</span><span>Received at billing</span></div><div class="card stat"><span class="num">${money(all.disc)}</span><span>Discounts</span></div></div>
        <h3 class="sec-title">Doctor revenue</h3><table><thead><tr><th>Doctor</th><th class="right">Slips</th><th class="right">Billed</th><th class="right">Received</th></tr></thead><tbody>${rowsHtml(docs, (x) => x.d.name)}</tbody></table>
        <h3 class="sec-title">Receptionist activity</h3><table><thead><tr><th>Receptionist</th><th class="right">Slips</th><th class="right">Billed</th><th class="right">Received</th></tr></thead><tbody>${rowsHtml(recs, (x) => x.u.displayName)}</tbody></table>
        <h3 class="sec-title">Service revenue</h3><button class="btn small" id="sv">Calculate for these days (loads up to 1,500 slips)</button><div id="svo"></div>`;
      $('#sv', c).onclick = async () => {
        $('#svo', c).textContent = 'Loading…';
        try {
          const r = await page('bills', [where('status', '==', 'posted'), ...range, orderBy('createdAt', 'desc')], null, 1500);
          const m = {};
          r.rows.forEach((b) => (b.rows || []).filter((x) => x.kind !== 'doctor').forEach((x) => { const k = x.name; m[k] = m[k] || { q: 0, t: 0 }; m[k].q += x.qty; m[k].t = round2(m[k].t + x.lineTotal); }));
          const ent = Object.entries(m).sort((a, b) => b[1].t - a[1].t);
          $('#svo', c).innerHTML = (r.more ? '<p class="error">More than 1,500 slips: choose a shorter range for full totals.</p>' : '') +
            `<table><thead><tr><th>Service</th><th class="right">Qty</th><th class="right">Revenue</th></tr></thead><tbody>${ent.map(([k, v]) => `<tr><td>${esc(k)}</td><td class="right">${v.q}</td><td class="right">${money(v.t)}</td></tr>`).join('') || '<tr><td colspan="3" class="muted">None.</td></tr>'}</tbody></table>`;
        } catch { $('#svo', c).innerHTML = '<span class="error">Could not load.</span>'; }
      };
    } catch { $('#out', c).innerHTML = '<span class="error">Could not load the totals (needs the internet).</span>'; }
  };
}
