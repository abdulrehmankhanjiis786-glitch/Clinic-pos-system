// Shifts: open, close (own shift only), till reconciliation and the Till Close Report.
import { collection, doc, getDoc, runTransaction, writeBatch, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase.js';
import { auditData } from '../auth.js';
import { esc, $, fmtTime, printHtml, ask } from '../util.js';
import { shiftTotals, shiftLists, money } from '../data.js';
import { parseMoney, round2 } from '../calc.js';
import { summary, isOnline } from '../offline.js';
import { heldCount } from './bill.js';

const errCard = '<div class="card error">Could not load data. Check your connection and try again.</div>';
const SHIFT_NAMES = ['Morning', 'Evening', 'Night'];

function recon(shift, t) {
  const row = (l, v, b) => `<tr${b ? ' style="font-weight:700"' : ''}><td>${l}</td><td class="right">${money(v)}</td></tr>`;
  const nc = Object.entries(t.nonCash);
  return `<table><tbody>${row('Opening cash', shift.openingCash)}${row('+ Cash sales received', t.cashSales)}${row('+ Cash outstanding payments received', t.cashOutstanding)}
    ${row('+ Cash In', t.cashIn)}${row('− Cash Out', t.cashOut)}${row('− Cash refunds (cancelled slips)', t.cashRefunds)}${row('= Total cash', t.expected, true)}</tbody></table>
    ${nc.length ? `<h3 class="sec-title">Not in the cash drawer</h3><table><tbody>${nc.map(([k, v]) => `<tr><td>${esc(k)}</td><td class="right">${money(v)}</td></tr>`).join('')}</tbody></table>` : ''}`;
}

export async function currentShiftPage(c, ctx) {
  const shift = ctx.shift();
  if (!shift) { openForm(c, ctx); return; }
  c.innerHTML = '<p class="muted">Loading…</p>';
  let t = null;
  if (isOnline()) { try { t = await shiftTotals(shift); } catch { c.innerHTML = errCard; return; } }
  c.innerHTML = `<div class="card"><h2>${esc(shift.shiftName)} shift — open</h2><p class="muted">Opened ${esc(fmtTime(shift.openedAt) || new Date(shift.openedAt || 0).toLocaleString())}</p>
    ${t ? recon(shift, t) : '<p class="muted">The till summary needs the internet.</p>'}</div>
    <div class="card"><h2>Close shift</h2><p class="muted">Held invoices must be cleared first. After closing there is no new billing, cash entry, cancel or refund in this shift.</p>
      <form id="f" class="grid2"><label>Counted cash<input name="counted" required inputmode="decimal" autocomplete="off"></label><label>Notes (optional)<input name="notes" maxlength="300"></label>
      <div class="row-end"><span id="msg" class="error"></span><button class="btn primary">Close shift</button></div></form></div>`;
  $('#f', c).onsubmit = async (e) => {
    e.preventDefault();
    const f = e.target;
    const msg = $('#msg', c);
    const counted = parseMoney(f.counted.value, true);
    if (counted === null) { msg.textContent = 'Enter the counted cash.'; return; }
    if (!isOnline()) { msg.textContent = 'Closing a shift needs the internet.'; return; }
    if (summary().pending > 0) { msg.textContent = 'Some entries are still waiting to sync. Wait a moment and try again.'; return; }
    if (await heldCount(ctx.uid) > 0) { msg.textContent = 'Please continue or delete your held invoices first.'; return; }
    if (ctx.bill?.hasUnsaved?.() && !(await ask('Unsaved slips', 'You still have unsaved slips on the billing page. Close the shift anyway?', 'Close shift'))) return;
    if (!(await ask('Close shift?', 'You will not be able to bill or enter cash in this shift again.', 'Close shift'))) return;
    $('button', f).disabled = true;
    try {
      const t2 = await shiftTotals(shift);
      const diff = round2(counted - t2.expected);
      await runTransaction(db, async (tx) => {
        tx.update(doc(db, 'shifts', shift.id), { status: 'closed', closedAt: serverTimestamp(), countedCash: counted, expectedCash: t2.expected, difference: diff, closeNotes: f.notes.value.trim(), totals: t2 });
        tx.delete(doc(db, 'openShifts', ctx.uid));
        tx.set(doc(collection(db, 'auditLogs')), auditData(ctx.uid, 'receptionist', 'shift.close', 'shift', shift.id, { expected: t2.expected, counted, difference: diff }));
      });
      localStorage.removeItem(`shift:${ctx.uid}`);
      const closed = await getDoc(doc(db, 'shifts', shift.id));
      ctx.setShift(null);
      c.innerHTML = '';
      await shiftReport(c, { id: closed.id, ...closed.data() }, ctx.cfg());
    } catch (ex) {
      console.error('Close failed', ex.code, ex.message);
      msg.textContent = 'Could not close the shift. Check the internet and try again.';
      $('button', f).disabled = false;
    }
  };
}

function openForm(c, ctx) {
  c.innerHTML = `<div class="card"><h2>Open your shift</h2><p class="muted">Count the cash in your drawer and enter it as the opening cash.</p>
    <form id="f" class="grid2"><label>Shift<select name="shiftName">${SHIFT_NAMES.map((n) => `<option>${n}</option>`).join('')}</select></label>
    <label>Opening cash<input name="cash" required inputmode="decimal" autocomplete="off"></label>
    <div class="row-end"><span id="msg" class="error"></span><button class="btn primary">Open shift</button></div></form></div>`;
  $('#f', c).onsubmit = async (e) => {
    e.preventDefault();
    const f = e.target;
    const msg = $('#msg', c);
    const cash = parseMoney(f.cash.value, true);
    if (cash === null) { msg.textContent = 'Enter the opening cash (0 if none).'; return; }
    if (!isOnline()) { msg.textContent = 'Opening a shift needs the internet.'; return; }
    $('button', f).disabled = true;
    const ref = doc(collection(db, 'shifts'));
    const batch = writeBatch(db);
    batch.set(ref, { receptionistUid: ctx.uid, receptionistName: ctx.name, shiftName: f.shiftName.value, openingCash: cash, status: 'open', openedAt: serverTimestamp() });
    batch.set(doc(db, 'openShifts', ctx.uid), { shiftId: ref.id, openedAt: serverTimestamp() });
    batch.set(doc(collection(db, 'auditLogs')), auditData(ctx.uid, 'receptionist', 'shift.open', 'shift', ref.id, { openingCash: cash }));
    try {
      await batch.commit();
      await ctx.refreshShift();
      currentShiftPage(c, ctx);
    } catch (ex) {
      console.error('Open shift failed', ex.code, ex.message);
      msg.textContent = 'Could not open the shift. You may already have one open.';
      $('button', f).disabled = false;
    }
  };
}

// ---------- Till Close Report (receptionist after closing, Admin any time) ----------
export async function shiftReport(host, shift, cfg) {
  const box = document.createElement('div');
  box.innerHTML = '<p class="muted">Loading report…</p>';
  host.appendChild(box);
  let t, L;
  try { [t, L] = await Promise.all([shiftTotals(shift), shiftLists(shift)]); } catch { box.innerHTML = errCard; return; }
  const closed = shift.status === 'closed';
  const diff = closed ? round2(shift.countedCash - t.expected) : null;
  const label = diff === null ? '' : diff > 0 ? 'Excess' : diff < 0 ? 'Short' : 'Balanced';
  const tx = (arr) => (arr.length ? `<table><thead><tr><th>Reference</th><th>Time</th><th class="right">Amount</th><th>Remarks</th></tr></thead><tbody>${arr.map((x) =>
    `<tr><td>${esc(x.reference)}</td><td>${esc(fmtTime(x.createdAt))}</td><td class="right">${money(x.amount)}</td><td>${esc(x.reason)}</td></tr>`).join('')}</tbody></table>` : '<p class="muted">None.</p>');
  const b = cfg.branding;
  box.className = 'card report';
  box.innerHTML = `<div class="no-print row-gap" style="justify-content:flex-end;margin-bottom:8px"><button class="btn" id="pr">Print report</button></div>
    <div id="rp">${b.logo ? `<img src="${esc(b.logo)}" alt="" style="display:block;margin:0 auto 6px;max-height:60px">` : ''}<h2>${esc(b.heading)}</h2>
    <div class="sub">${esc(b.address)} ${esc(b.phone)}<br>Till Close Report</div>
    <table><tbody><tr><td>Report date and time</td><td>${esc(new Date().toLocaleString())}</td></tr><tr><td>Receptionist</td><td>${esc(shift.receptionistName)}</td></tr>
      <tr><td>Shift</td><td>${esc(shift.shiftName)}</td></tr><tr><td>Opened</td><td>${esc(fmtTime(shift.openedAt))}</td></tr>
      <tr><td>Closed</td><td>${closed ? esc(fmtTime(shift.closedAt)) : 'Still open'}</td></tr></tbody></table>
    <h3 class="sec-title">Cash In</h3>${tx(L.txs.filter((x) => x.type === 'in'))}<h3 class="sec-title">Cash Out</h3>${tx(L.txs.filter((x) => x.type === 'out'))}
    <h3 class="sec-title">Patient balance amounts received</h3>${L.payments.length ? `<table><thead><tr><th>Reference</th><th>Patient</th><th>Slip</th><th>Method</th><th class="right">Amount</th></tr></thead><tbody>
      ${L.payments.map((p) => `<tr><td>${esc(p.paymentNo)}</td><td>${esc(p.patientName)}</td><td>${esc(p.receiptNo)}</td><td>${esc(p.methodName)}</td><td class="right">${money(p.amount)}</td></tr>`).join('')}</tbody></table>` : '<p class="muted">None.</p>'}
    <h3 class="sec-title">Cancelled slips and refunds</h3>${L.cancelled.length ? `<table><thead><tr><th>Slip</th><th>Patient</th><th class="right">Amount</th><th class="right">Refund</th><th>Reason</th><th>By</th><th>Time</th></tr></thead><tbody>
      ${L.cancelled.map((x) => `<tr><td>${esc(x.receiptNo)}</td><td>${esc(x.patientName)}</td><td class="right">${money(x.net)}</td><td class="right">${money(x.refundAmount || 0)}</td><td>${esc(x.cancelReason)}</td><td>${esc(x.cancelledByName)}</td><td>${esc(fmtTime(x.cancelledAt))}</td></tr>`).join('')}</tbody></table>` : '<p class="muted">None.</p>'}
    <h3 class="sec-title">Complimentary</h3>${L.comps.length ? `<table><tbody>${L.comps.map((x) => `<tr><td>${esc(x.receiptNo)}</td><td>${esc(x.patientName)}</td><td class="right">${money(x.compAmount)}</td></tr>`).join('')}</tbody></table>` : '<p class="muted">None.</p>'}
    <h3 class="sec-title">Cash reconciliation</h3>${recon(shift, t)}
    ${closed ? `<table style="margin-top:8px"><tbody><tr><td>Counted cash</td><td class="right">${money(shift.countedCash)}</td></tr><tr style="font-weight:700"><td>Difference (${label})</td><td class="right">${money(diff)}</td></tr></tbody></table>${shift.closeNotes ? `<p>Notes: ${esc(shift.closeNotes)}</p>` : ''}` : '<p class="muted">Counted cash and difference appear after the shift is closed.</p>'}
    <div class="sign"><div>Receptionist</div><div>Admin — checking report</div><div>Accountant — reviewing report</div></div>
    <p class="sub" style="margin-top:20px">${esc(b.footer)}</p></div>`;
  $('#pr', box).onclick = () => printHtml(`<!doctype html><html><head><meta charset="utf-8"><title>Till Close Report</title>
    <style>body{font:13px Arial,sans-serif;margin:18px;color:#000}table{width:100%;border-collapse:collapse;margin-bottom:6px}th,td{text-align:left;padding:4px 6px;border-bottom:1px solid #999}
    .right{text-align:right}h2{text-align:center;margin:0}.sub{text-align:center;margin-bottom:12px}.sec-title{margin:16px 0 6px;font-size:14px}.muted{color:#555}
    .sign{display:grid;grid-template-columns:repeat(3,1fr);gap:24px;margin-top:56px}.sign div{border-top:1px solid #000;padding-top:4px;text-align:center}</style></head><body>${$('#rp', box).innerHTML}</body></html>`);
}

// Admin: reopen a closed shift with a reason.
export async function reopenShift(shift, ctx, why) {
  const batch = writeBatch(db);
  batch.update(doc(db, 'shifts', shift.id), { status: 'open', reopenedAt: serverTimestamp(), reopenedBy: ctx.uid, reopenReason: why });
  batch.set(doc(db, 'openShifts', shift.receptionistUid), { shiftId: shift.id, openedAt: serverTimestamp() });
  batch.set(doc(collection(db, 'auditLogs')), auditData(ctx.uid, 'admin', 'shift.reopen', 'shift', shift.id, { reason: why }));
  await batch.commit();
}
