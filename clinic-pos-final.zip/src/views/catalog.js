// Admin configuration: doctors, services, lab / tests, payment methods, settings, shortcuts and permissions.
import { collection, doc, writeBatch, serverTimestamp, deleteField, where, getDoc } from 'firebase/firestore';
import { db } from '../firebase.js';
import { auditData } from '../auth.js';
import { esc, $, ask, toast } from '../util.js';
import { list, money } from '../data.js';
import { parseMoney, normService, normDoctor, doctorEntry, serviceEntry } from '../calc.js';
import { getConfig, invalidateConfig, withDefaults, DEFAULT_SHORTCUTS, ACTIONS } from '../config.js';

const PL = () => doc(db, 'settings', 'priceList');
const stamp = (ctx) => ({ updatedAt: serverTimestamp(), updatedBy: ctx.uid });
const audit = (batch, ctx, action, type, id, details) => batch.set(doc(collection(db, 'auditLogs')), auditData(ctx.uid, ctx.role || 'admin', action, type, id, details));
const ENTRY = { doctors: doctorEntry, services: serviceEntry };
const fresh = () => { invalidateConfig(); return getConfig('admin', true); };

// settings/priceList mirrors doctors + services; the security rules check every slip against it.
export async function syncPriceList(ctx) {
  const [d, s] = await Promise.all([list('doctors'), list('services')]);
  const want = { doctors: Object.fromEntries(d.map((x) => [x.id, doctorEntry(x)])), services: Object.fromEntries(s.map((x) => [x.id, serviceEntry(x)])) };
  const cur = await getDoc(PL());
  const canon = (v) => JSON.stringify(v, (k, val) => (val && typeof val === 'object' && !Array.isArray(val) ? Object.fromEntries(Object.entries(val).sort(([a], [b]) => a.localeCompare(b))) : val));
  if (cur.exists() && canon(cur.data().doctors || {}) === canon(want.doctors) && canon(cur.data().services || {}) === canon(want.services)) return false;
  const batch = writeBatch(db);
  batch.set(PL(), { ...want, ...stamp(ctx) });
  audit(batch, ctx, 'pricelist.rebuild', 'settings', 'priceList', { doctors: d.length, services: s.length });
  await batch.commit();
  invalidateConfig();
  return true;
}

async function saveItem(ctx, coll, id, data, isNew, action) {
  const batch = writeBatch(db);
  const ref = doc(db, coll, id);
  if (isNew) batch.set(ref, { ...data, active: true, createdAt: serverTimestamp(), createdBy: ctx.uid });
  else batch.update(ref, { ...data, ...stamp(ctx) });
  const full = { ...data, active: data.active !== false };
  batch.set(PL(), { [coll]: { [id]: ENTRY[coll](full) }, ...stamp(ctx) }, { merge: true });
  audit(batch, ctx, action, coll, id, { name: data.name });
  await batch.commit();
}
async function removeItem(ctx, coll, item) {
  const batch = writeBatch(db);
  batch.delete(doc(db, coll, item.id));
  batch.update(PL(), { [`${coll}.${item.id}`]: deleteField(), ...stamp(ctx) });
  audit(batch, ctx, `${coll}.delete`, coll, item.id, { name: item.name });
  await batch.commit();
}
const dup = (items, name, exceptId) => items.some((x) => x.id !== exceptId && x.name.toLowerCase() === name.toLowerCase());

// ---------- Doctors ----------
export async function doctorsPage(c, ctx) {
  let cfg = await getConfig('admin');
  c.innerHTML = `<div class="card"><h2 id="ft">Add doctor</h2><form id="f" class="grid3b">
    <label>Name<input name="name" required minlength="2" maxlength="80" autocomplete="off"></label>
    <label>Gender<select name="gender"><option>Male</option><option>Female</option><option>Other</option></select></label>
    <label>Category<select name="category"><option>Consultant</option><option>RMO</option></select></label>
    <label>Specialization<input name="specialization" maxlength="60" autocomplete="off"></label>
    <label>Day<input name="day" maxlength="40" placeholder="e.g. Mon - Fri"></label><label>Time<input name="time" maxlength="40" placeholder="e.g. 9 am - 1 pm"></label>
    <label>Fee<input name="fee" required inputmode="decimal" autocomplete="off"></label>
    <label>Fee type<select name="feeMode"><option value="fixed">Fixed</option><option value="negotiable">Negotiable</option></select></label>
    <label class="neg">Lowest allowed fee<input name="minFee" inputmode="decimal"></label><label class="neg">Highest allowed fee<input name="maxFee" inputmode="decimal"></label>
    <div class="row-end"><span id="msg" class="error"></span><button class="btn" type="button" id="cancel" style="display:none">Cancel edit</button><button class="btn primary" id="sv">Add doctor</button></div></form></div>
    <div class="card"><h2>Doctors</h2><div id="list"></div></div>`;
  const f = $('#f', c);
  let editing = null;
  const syncNeg = () => c.querySelectorAll('.neg').forEach((x) => (x.style.display = f.feeMode.value === 'negotiable' ? '' : 'none'));
  f.feeMode.onchange = syncNeg; syncNeg();
  const draw = () => {
    const items = cfg.rawDoctors.map((d) => ({ ...normDoctor(d) })).sort((a, b) => a.name.localeCompare(b.name));
    $('#list', c).innerHTML = items.length ? `<table><thead><tr><th>Name</th><th>Category</th><th>Specialization</th><th>Day / Time</th><th class="right">Fee</th><th>Type</th><th>Status</th><th></th></tr></thead><tbody>
      ${items.map((d) => `<tr><td>${esc(d.name)}</td><td>${esc(d.category)}</td><td>${esc(d.specialization)}</td><td>${esc([d.day, d.time].filter(Boolean).join(' · '))}</td><td class="right">${money(d.fee)}</td>
        <td>${d.mode === 'negotiable' ? `Negotiable (${money(d.min)} - ${money(d.max)})` : 'Fixed'}</td><td><span class="pill ${d.active !== false ? 'on' : 'off'}">${d.active !== false ? 'Active' : 'Inactive'}</span></td>
        <td class="row-gap"><button class="btn small" data-e="${esc(d.id)}">Edit</button><button class="btn small" data-t="${esc(d.id)}">${d.active !== false ? 'Deactivate' : 'Activate'}</button><button class="btn small" data-d="${esc(d.id)}">Delete</button></td></tr>`).join('')}</tbody></table>` : '<p class="muted">No doctors yet.</p>';
    c.querySelectorAll('[data-e]').forEach((b) => (b.onclick = () => {
      const d = items.find((x) => x.id === b.dataset.e); editing = d;
      ['name', 'gender', 'category', 'specialization', 'day', 'time', 'fee', 'feeMode'].forEach((k) => { f[k].value = k === 'feeMode' ? d.mode : d[k] ?? ''; });
      f.minFee.value = d.min; f.maxFee.value = d.max; syncNeg();
      $('#ft', c).textContent = 'Edit doctor'; $('#sv', c).textContent = 'Save changes'; $('#cancel', c).style.display = ''; f.scrollIntoView({ behavior: 'smooth' });
    }));
    c.querySelectorAll('[data-t]').forEach((b) => (b.onclick = async () => { const d = cfg.rawDoctors.find((x) => x.id === b.dataset.t);
      try { await saveItem(ctx, 'doctors', d.id, { ...clean(d), active: d.active === false }, false, 'doctors.toggle'); cfg = await fresh(); draw(); } catch { toast('Could not save.', true); } }));
    c.querySelectorAll('[data-d]').forEach((b) => (b.onclick = async () => { const d = cfg.rawDoctors.find((x) => x.id === b.dataset.d);
      if (!(await ask('Delete doctor?', `${d.name} will be removed from new slips. Old slips keep their data.`, 'Delete'))) return;
      try { await removeItem(ctx, 'doctors', d); cfg = await fresh(); draw(); } catch { toast('Could not delete.', true); } }));
  };
  const clean = (d) => { const n = normDoctor(d); return { name: n.name, gender: n.gender || 'Male', category: n.category || 'Consultant', specialization: n.specialization, day: n.day, time: n.time, fee: n.fee, feeMode: n.mode, minFee: n.min, maxFee: n.max, active: n.active !== false }; };
  const reset = () => { editing = null; f.reset(); syncNeg(); $('#ft', c).textContent = 'Add doctor'; $('#sv', c).textContent = 'Add doctor'; $('#cancel', c).style.display = 'none'; };
  $('#cancel', c).onclick = reset;
  f.onsubmit = async (e) => {
    e.preventDefault();
    const msg = $('#msg', c);
    const fee = parseMoney(f.fee.value, true);
    const neg = f.feeMode.value === 'negotiable';
    const min = neg ? parseMoney(f.minFee.value, true) : fee, max = neg ? parseMoney(f.maxFee.value, true) : fee;
    if (fee === null || min === null || max === null) { msg.textContent = 'Enter valid fee amounts.'; return; }
    if (neg && !(min <= fee && fee <= max)) { msg.textContent = 'The fee must be between the lowest and highest allowed fee.'; return; }
    const name = f.name.value.trim();
    if (dup(cfg.rawDoctors, name, editing?.id)) { msg.textContent = 'A doctor with this name already exists.'; return; }
    const data = { name, gender: f.gender.value, category: f.category.value, specialization: f.specialization.value.trim(), day: f.day.value.trim(), time: f.time.value.trim(), fee, feeMode: f.feeMode.value, minFee: min, maxFee: max };
    try {
      if (editing) await saveItem(ctx, 'doctors', editing.id, { ...data, active: editing.active !== false }, false, 'doctors.update');
      else await saveItem(ctx, 'doctors', doc(collection(db, 'doctors')).id, data, true, 'doctors.create');
      cfg = await fresh(); reset(); msg.textContent = ''; draw(); toast('Saved.');
    } catch (ex) { console.error(ex); msg.textContent = 'Could not save. Try again.'; }
  };
  draw();
}

// ---------- Services and Lab / Tests (same screen, different kind) ----------
export async function servicesPage(c, ctx, kind = 'service') {
  let cfg = await getConfig('admin');
  const isLab = kind === 'lab';
  const noun = isLab ? 'test' : 'service';
  c.innerHTML = `${isLab ? '<div class="card"><h2>Lab / Test categories</h2><div id="cats" class="row-gap"></div><form id="cf" class="row-gap" style="margin-top:8px"><input name="c" class="inline" style="max-width:240px" placeholder="New category" maxlength="40"><button class="btn small">Add category</button></form></div>' : ''}
    <div class="card"><h2 id="ft">Add ${noun}</h2><form id="f" class="grid3b">
    <label>Name<input name="name" required minlength="2" maxlength="80" autocomplete="off"></label>
    <label>Category<input name="category" list="dl-cat" maxlength="40" autocomplete="off"></label><datalist id="dl-cat"></datalist>
    <label>Price type<select name="mode"><option value="fixed">Fixed</option><option value="negotiable">Negotiable</option></select></label>
    ${[1, 2, 3, 4, 5].map((i) => `<label>Price ${i}${i === 1 ? '' : ' (optional)'}<input name="p${i}" inputmode="decimal" ${i === 1 ? 'required' : ''} autocomplete="off"></label>`).join('')}
    <label class="neg">Lowest allowed rate<input name="minRate" inputmode="decimal"></label><label class="neg">Highest allowed rate<input name="maxRate" inputmode="decimal"></label>
    <div class="row-end"><span id="msg" class="error"></span><button class="btn" type="button" id="cancel" style="display:none">Cancel edit</button><button class="btn primary" id="sv">Add ${noun}</button></div></form></div>
    <div class="card"><h2>${isLab ? 'Lab / Tests' : 'Services'}</h2><div id="list"></div></div>`;
  const f = $('#f', c);
  let editing = null;
  const syncNeg = () => c.querySelectorAll('.neg').forEach((x) => (x.style.display = f.mode.value === 'negotiable' ? '' : 'none'));
  f.mode.onchange = syncNeg; syncNeg();
  const cats = () => [...new Set([...(cfg.categories[kind] || []), ...cfg.rawServices.filter((s) => (s.kind || 'service') === kind).map((s) => s.category).filter(Boolean)])].sort();
  const drawCats = () => {
    $('#dl-cat', c).innerHTML = cats().map((x) => `<option value="${esc(x)}">`).join('');
    if (!isLab) return;
    $('#cats', c).innerHTML = (cfg.categories.lab || []).map((x) => `<span class="pill on">${esc(x)} <button class="x" data-rc="${esc(x)}" aria-label="Remove category">×</button></span>`).join('') || '<span class="muted">No categories yet.</span>';
    c.querySelectorAll('[data-rc]').forEach((b) => (b.onclick = () => saveCats((cfg.categories.lab || []).filter((x) => x !== b.dataset.rc))));
  };
  async function saveCats(lab) {
    const batch = writeBatch(db);
    batch.set(doc(db, 'settings', 'categories'), { lab, service: cfg.categories.service || [], ...stamp(ctx) });
    audit(batch, ctx, 'categories.update', 'settings', 'categories', { lab: lab.length });
    try { await batch.commit(); cfg = await fresh(); drawCats(); } catch { toast('Could not save the categories.', true); }
  }
  if (isLab) $('#cf', c).onsubmit = (e) => { e.preventDefault(); const v = e.target.c.value.trim(); if (v && !(cfg.categories.lab || []).includes(v)) saveCats([...(cfg.categories.lab || []), v]); e.target.reset(); };
  const rowsOf = () => cfg.rawServices.map(normService).filter((s) => s.kind === kind).sort((a, b) => a.name.localeCompare(b.name));
  const draw = () => {
    drawCats();
    const items = rowsOf();
    $('#list', c).innerHTML = items.length ? `<table><thead><tr><th>Name</th><th>Category</th><th>Prices</th><th>Type</th><th>Status</th><th></th></tr></thead><tbody>
      ${items.map((s) => `<tr><td>${esc(s.name)}</td><td>${esc(s.category)}</td><td>${s.options.map((o, i) => `P${i + 1} ${money(o)}`).join(' · ')}</td>
        <td>${s.mode === 'negotiable' ? `Negotiable (${money(s.min)} - ${money(s.max)})` : 'Fixed'}</td><td><span class="pill ${s.active !== false ? 'on' : 'off'}">${s.active !== false ? 'Active' : 'Inactive'}</span></td>
        <td class="row-gap"><button class="btn small" data-e="${esc(s.id)}">Edit</button><button class="btn small" data-t="${esc(s.id)}">${s.active !== false ? 'Deactivate' : 'Activate'}</button><button class="btn small" data-d="${esc(s.id)}">Delete</button></td></tr>`).join('')}</tbody></table>` : `<p class="muted">No ${noun}s yet.</p>`;
    c.querySelectorAll('[data-e]').forEach((b) => (b.onclick = () => {
      const s = items.find((x) => x.id === b.dataset.e); editing = s;
      f.name.value = s.name; f.category.value = s.category; f.mode.value = s.mode;
      [1, 2, 3, 4, 5].forEach((i) => { f[`p${i}`].value = s.options[i - 1] ?? ''; });
      f.minRate.value = s.min; f.maxRate.value = s.max; syncNeg();
      $('#ft', c).textContent = `Edit ${noun}`; $('#sv', c).textContent = 'Save changes'; $('#cancel', c).style.display = ''; f.scrollIntoView({ behavior: 'smooth' });
    }));
    const full = (s, over) => ({ name: s.name, kind, category: s.category, price: s.options[0], priceOptions: s.options, priceMode: s.mode, minRate: s.min, maxRate: s.max, active: s.active !== false, ...over });
    c.querySelectorAll('[data-t]').forEach((b) => (b.onclick = async () => { const s = items.find((x) => x.id === b.dataset.t);
      try { await saveItem(ctx, 'services', s.id, full(s, { active: s.active === false }), false, 'services.toggle'); cfg = await fresh(); draw(); } catch { toast('Could not save.', true); } }));
    c.querySelectorAll('[data-d]').forEach((b) => (b.onclick = async () => { const s = items.find((x) => x.id === b.dataset.d);
      if (!(await ask(`Delete ${noun}?`, `${s.name} will be removed from new slips. Old slips keep their data.`, 'Delete'))) return;
      try { await removeItem(ctx, 'services', s); cfg = await fresh(); draw(); } catch { toast('Could not delete.', true); } }));
  };
  const reset = () => { editing = null; f.reset(); syncNeg(); $('#ft', c).textContent = `Add ${noun}`; $('#sv', c).textContent = `Add ${noun}`; $('#cancel', c).style.display = 'none'; };
  $('#cancel', c).onclick = reset;
  f.onsubmit = async (e) => {
    e.preventDefault();
    const msg = $('#msg', c);
    const opts = [];
    for (let i = 1; i <= 5; i++) {
      const raw = f[`p${i}`].value.trim();
      if (!raw) { if (i === 1) { msg.textContent = 'Price 1 is required.'; return; } continue; }
      const v = parseMoney(raw, true);
      if (v === null) { msg.textContent = `Price ${i} is not a valid amount.`; return; }
      opts.push(v);
    }
    const neg = f.mode.value === 'negotiable';
    const min = neg ? parseMoney(f.minRate.value, true) : Math.min(...opts), max = neg ? parseMoney(f.maxRate.value, true) : Math.max(...opts);
    if (min === null || max === null || min > max) { msg.textContent = 'Enter a valid lowest and highest allowed rate.'; return; }
    if (neg && (Math.min(...opts) < min || Math.max(...opts) > max)) { msg.textContent = 'All price options must be inside the allowed range.'; return; }
    const name = f.name.value.trim();
    if (dup(cfg.rawServices.filter((s) => (s.kind || 'service') === kind), name, editing?.id)) { msg.textContent = 'This name already exists.'; return; }
    const data = { name, kind, category: f.category.value.trim(), price: opts[0], priceOptions: opts, priceMode: f.mode.value, minRate: min, maxRate: max };
    try {
      if (editing) await saveItem(ctx, 'services', editing.id, { ...data, active: editing.active !== false }, false, 'services.update');
      else await saveItem(ctx, 'services', doc(collection(db, 'services')).id, data, true, 'services.create');
      cfg = await fresh(); reset(); msg.textContent = ''; draw(); toast('Saved.');
    } catch (ex) { console.error(ex); msg.textContent = 'Could not save. Try again.'; }
  };
  draw();
}

// ---------- Payment methods ----------
export async function methodsPage(c, ctx) {
  let cfg = await getConfig('admin');
  c.innerHTML = `<div class="card"><h2>Payment methods</h2><form id="f" class="row-gap" style="margin-bottom:12px"><input name="name" class="inline" style="max-width:240px" placeholder="Name, for example Cash" required minlength="2" maxlength="40" autocomplete="off">
    <label class="inl chk"><input type="checkbox" name="isCash"> Physical cash</label><button class="btn primary">Add method</button><span id="msg" class="error"></span></form><div id="list"></div></div>`;
  const draw = () => {
    const ms = [...cfg.methods].sort((a, b) => a.name.localeCompare(b.name));
    $('#list', c).innerHTML = ms.length ? `<table><thead><tr><th>Name</th><th>Type</th><th>Status</th><th></th></tr></thead><tbody>${ms.map((m) => `<tr><td>${esc(m.name)}</td><td>${m.isCash ? 'Cash' : 'Card / other'}</td>
      <td><span class="pill ${m.active ? 'on' : 'off'}">${m.active ? 'Enabled' : 'Disabled'}</span></td><td><button class="btn small" data-t="${esc(m.id)}">${m.active ? 'Disable' : 'Enable'}</button></td></tr>`).join('')}</tbody></table>` : '<p class="muted">No payment methods yet. Add Cash first.</p>';
    c.querySelectorAll('[data-t]').forEach((b) => (b.onclick = async () => {
      const m = cfg.methods.find((x) => x.id === b.dataset.t);
      const batch = writeBatch(db);
      batch.update(doc(db, 'paymentMethods', m.id), { active: !m.active, ...stamp(ctx) });
      audit(batch, ctx, 'paymentMethod.toggle', 'paymentMethod', m.id, { name: m.name });
      try { await batch.commit(); cfg = await fresh(); draw(); } catch { toast('Could not save.', true); }
    }));
  };
  $('#f', c).onsubmit = async (e) => {
    e.preventDefault();
    const f = e.target; const name = f.name.value.trim();
    if (cfg.methods.some((m) => m.name.toLowerCase() === name.toLowerCase())) { $('#msg', c).textContent = 'This method already exists.'; return; }
    const ref = doc(collection(db, 'paymentMethods'));
    const batch = writeBatch(db);
    batch.set(ref, { name, isCash: f.isCash.checked, active: true, createdAt: serverTimestamp(), createdBy: ctx.uid });
    audit(batch, ctx, 'paymentMethod.create', 'paymentMethod', ref.id, { name });
    try { await batch.commit(); cfg = await fresh(); f.reset(); $('#msg', c).textContent = ''; draw(); } catch { $('#msg', c).textContent = 'Could not save.'; }
  };
  draw();
}

// ---------- Settings: general + shortcuts ----------
const KEY_OK = /^((Ctrl|Alt|Shift)\+){0,2}([A-Z0-9]|F([1-9]|1[0-2])|Enter|Delete|Escape)$/;
export async function settingsPage(c, ctx) {
  let cfg = await getConfig('admin');
  c.innerHTML = `<div class="card"><h2>General</h2><form id="gf" class="grid2"><label>Currency label (for example Rs)<input name="currency" maxlength="8" value="${esc(cfg.general.currency)}"></label>
    <label>Receipt number prefix (letters / numbers, up to 4)<input name="prefix" maxlength="4" value="${esc(cfg.general.receiptPrefix)}"></label>
    <div class="row-end"><span id="gm" class="muted"></span><button class="btn primary">Save</button></div></form></div>
    <div class="card"><h2>Shortcuts</h2><p class="muted">These appear in the receptionist's Shortcut Help.</p><div id="sc"></div>
      <div class="row-gap" style="margin-top:8px"><button class="btn small" id="add">Add shortcut</button><button class="btn small" id="rs">Reset to default</button><button class="btn primary small" id="ss">Save shortcuts</button><span id="sm" class="error"></span></div></div>`;
  $('#gf', c).onsubmit = async (e) => {
    e.preventDefault();
    const f = e.target; const prefix = f.prefix.value.trim().toUpperCase();
    if (!/^[A-Z0-9]{0,4}$/.test(prefix)) { $('#gm', c).textContent = 'The prefix may only contain letters and numbers.'; return; }
    const batch = writeBatch(db);
    batch.set(doc(db, 'settings', 'general'), { currency: f.currency.value.trim(), receiptPrefix: prefix || 'R', ...stamp(ctx) });
    audit(batch, ctx, 'settings.general', 'settings', 'general', {});
    try { await batch.commit(); cfg = await fresh(); $('#gm', c).className = 'muted'; $('#gm', c).textContent = 'Saved.'; } catch { $('#gm', c).className = 'error'; $('#gm', c).textContent = 'Could not save.'; }
  };
  let items = cfg.shortcuts.map((x) => ({ ...x }));
  const drawSc = () => {
    $('#sc', c).innerHTML = `<table><thead><tr><th>Key</th><th>Action</th><th></th></tr></thead><tbody>${items.map((x, i) => `<tr><td><input class="inline" data-k="${i}" value="${esc(x.key)}" style="width:140px"></td>
      <td><select data-a="${i}" class="inline">${Object.entries(ACTIONS).map(([k, v]) => `<option value="${k}" ${x.action === k ? 'selected' : ''}>${esc(v)}</option>`).join('')}</select></td>
      <td><button class="btn small" data-x="${i}">Delete</button></td></tr>`).join('')}</tbody></table>`;
    c.querySelectorAll('[data-k]').forEach((el) => (el.oninput = () => { items[Number(el.dataset.k)].key = el.value.trim(); }));
    c.querySelectorAll('[data-a]').forEach((el) => (el.onchange = () => { items[Number(el.dataset.a)].action = el.value; }));
    c.querySelectorAll('[data-x]').forEach((el) => (el.onclick = () => { items.splice(Number(el.dataset.x), 1); drawSc(); }));
  };
  $('#add', c).onclick = () => { items.push({ key: '', action: 'newSlip' }); drawSc(); };
  $('#rs', c).onclick = () => { items = DEFAULT_SHORTCUTS.map((x) => ({ ...x })); drawSc(); };
  $('#ss', c).onclick = async () => {
    const m = $('#sm', c); m.className = 'error';
    const keys = items.map((x) => x.key);
    if (items.some((x) => !KEY_OK.test(x.key))) { m.textContent = 'Use keys like Alt+N, Ctrl+Enter or F2.'; return; }
    if (new Set(keys).size !== keys.length) { m.textContent = 'Each key can be used only once.'; return; }
    const batch = writeBatch(db);
    batch.set(doc(db, 'settings', 'shortcuts'), { items, ...stamp(ctx) });
    audit(batch, ctx, 'settings.shortcuts', 'settings', 'shortcuts', { count: items.length });
    try { await batch.commit(); cfg = await fresh(); m.className = 'muted'; m.textContent = 'Saved.'; } catch { m.textContent = 'Could not save.'; }
  };
  drawSc();
}

// ---------- Permissions per receptionist ----------
const FLAGS = [['canDiscount', 'Discount'], ['canNegotiate', 'Negotiable doctor fee / service rate'], ['canCollectOutstanding', 'Receive outstanding payment'], ['canCollectOthers', "Receive other receptionists' outstanding payment"],
  ['canCashIn', 'Cash In'], ['canCashOut', 'Cash Out'], ['canCancel', 'Cancel slips'], ['canRefund', 'Refund'], ['canRestore', 'Restore cancelled slips'], ['canComplimentary', 'Complimentary']];
export async function permissionsPage(c, ctx) {
  c.innerHTML = '<p class="muted">Loading…</p>';
  let staff, limits;
  try { [staff, limits] = await Promise.all([list('users', where('role', '==', 'receptionist')), list('staffLimits')]); } catch { c.innerHTML = '<div class="card error">Could not load.</div>'; return; }
  staff.sort((a, b) => a.username.localeCompare(b.username));
  c.innerHTML = staff.length ? staff.map((u) => { const l = withDefaults(limits.find((x) => x.id === u.id)); return `<div class="card" data-uid="${esc(u.id)}"><h2>${esc(u.displayName)} <span class="muted">(${esc(u.username)})</span></h2>
    <div class="perm-grid">${FLAGS.map(([k, label]) => `<label class="chk"><input type="checkbox" data-f="${k}" ${l[k] ? 'checked' : ''}> ${esc(label)}</label>`).join('')}</div>
    <div class="row-gap" style="margin-top:8px"><label class="inl">Max discount %<input class="num-in" data-n="maxDiscountPercent" value="${esc(l.maxDiscountPercent)}"></label>
      <label class="inl">Max fixed discount per row<input class="num-in" data-n="maxDiscountFixed" value="${esc(l.maxDiscountFixed)}"></label>
      <label class="inl">Cash Out limit (0 = no limit)<input class="num-in" data-n="cashOutLimit" value="${esc(l.cashOutLimit)}"></label>
      <button class="btn primary small" data-save>Save</button><span class="msg"></span></div></div>`; }).join('') : '<div class="card"><p class="muted">No receptionists yet.</p></div>';
  c.querySelectorAll('[data-uid]').forEach((card) => {
    $('[data-save]', card).onclick = async () => {
      const msg = $('.msg', card);
      const data = {};
      card.querySelectorAll('[data-f]').forEach((x) => { data[x.dataset.f] = x.checked; });
      for (const x of card.querySelectorAll('[data-n]')) {
        const v = parseMoney(x.value, true);
        if (v === null || (x.dataset.n === 'maxDiscountPercent' && v > 100)) { msg.className = 'msg error'; msg.textContent = 'Check the numbers.'; return; }
        data[x.dataset.n] = v;
      }
      const uid = card.dataset.uid;
      const batch = writeBatch(db);
      batch.set(doc(db, 'staffLimits', uid), { ...data, ...stamp(ctx) });
      audit(batch, ctx, 'permissions.update', 'user', uid, data);
      try { await batch.commit(); msg.className = 'msg muted'; msg.textContent = 'Saved. Applies immediately.'; } catch { msg.className = 'msg error'; msg.textContent = 'Could not save.'; }
    };
  });
}
