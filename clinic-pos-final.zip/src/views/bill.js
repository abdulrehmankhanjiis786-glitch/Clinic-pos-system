// Receptionist POS: invoice (centre), patient panel (right), icon rail (left, see receptionist.js).
import { collection, doc, writeBatch, serverTimestamp, where } from 'firebase/firestore';
import { db } from '../firebase.js';
import { auditData } from '../auth.js';
import { esc, $, modal, ask, toast } from '../util.js';
import { money, list, verifyOpenShift, nextSeq as nextSeqOf, rememberSeq } from '../data.js';
import { explainFailure } from '../diagnose.js';
import { computeBill, makeNumber, parseMoney } from '../calc.js';
import { track, isOnline } from '../offline.js';
import { printBill } from './receipt.js';

const GENDERS = ['Male', 'Female', 'Other'];
const MAX_SERVICE_ROWS = 11; // the security rules check a doctor line + 11 other lines
const rid = () => Math.random().toString(36).slice(2, 10);
const blank = () => ({ id: rid(), patientName: '', age: '', gender: '', doctorId: '', doctorRate: null, doctorDisc: { t: 'none', v: '' },
  rows: [], paid: '', methodId: '', comp: false, compReason: '', pending: null, posted: null, heldId: null, sel: -1 });
const hasData = (s) => Boolean(s.patientName || s.age || s.gender || s.doctorId || s.rows.length);
const draftKey = (uid) => `drafts:${uid}`;
const strip = (s) => ({ ...s, pending: null, posted: null, sel: -1 });

export async function newBillPage(c, ctx) {
  const cfg = ctx.cfg();
  const limits = cfg.limits;
  const lic = ctx.licenseBlocked();
  const shift = ctx.shift();
  if (!shift) {
    c.innerHTML = '<div class="card"><h2>New Slip</h2><p class="muted">Open your shift first, then you can create slips.</p><button class="btn primary" id="gs">Open shift</button></div>';
    $('#gs', c).onclick = () => ctx.go('shift');
    return;
  }
  if (!ctx.profile.receiptCode) {
    c.innerHTML = '<div class="card error"><h2>New Slip</h2><p>Your receipt code has not been set up yet. Please ask the Admin to assign it (Receptionists screen).</p></div>';
    return;
  }
  const methods = cfg.methods.filter((m) => m.active).sort((a, b) => a.name.localeCompare(b.name));
  if (!methods.length) {
    c.innerHTML = '<div class="card"><h2>New Slip</h2><p class="muted">No payment method is enabled. Please ask the Admin.</p></div>';
    return;
  }
  const doctors = cfg.doctors.filter((d) => d.active !== false).sort((a, b) => a.name.localeCompare(b.name));
  const services = cfg.services.filter((s) => s.active !== false);

  // ----- draft tabs (survive a closed browser) -----
  let saved = null;
  try { saved = JSON.parse(localStorage.getItem(draftKey(ctx.uid)) || 'null'); } catch { /* ignore */ }
  let tabs = saved?.tabs?.length ? saved.tabs.map((t) => ({ ...blank(), ...t })) : [blank()];
  let cur = Math.min(saved?.active || 0, tabs.length - 1);
  if (ctx.resume) { tabs[cur] = hasData(tabs[cur]) ? tabs[cur] : blank(); if (hasData(tabs[cur])) { tabs.push(ctx.resume); cur = tabs.length - 1; } else tabs[cur] = ctx.resume; ctx.resume = null; }
  const st = () => tabs[cur];
  tabs.forEach((t) => { if (!t.methodId || !methods.some((m) => m.id === t.methodId)) t.methodId = methods[0].id; });
  let persistTimer = null;
  const persist = () => {
    clearTimeout(persistTimer);
    persistTimer = setTimeout(() => {
      const keep = tabs.filter((t) => !t.posted && hasData(t)).map(strip);
      try { localStorage.setItem(draftKey(ctx.uid), JSON.stringify({ tabs: keep, active: Math.min(cur, Math.max(keep.length - 1, 0)) })); } catch { /* ignore */ }
    }, 250);
  };

  const lookup = (kind, id) => (kind === 'doctor' ? doctors.find((d) => d.id === id) : services.find((s) => s.id === id));
  const doctorOf = (s) => doctors.find((d) => d.id === s.doctorId);
  function fullState(s) {
    const d = doctorOf(s);
    const rows = [];
    if (d) rows.push({ kind: 'doctor', refId: d.id, option: 0, rate: s.doctorRate ?? d.fee, qty: 1, discType: s.doctorDisc.t, discValue: s.doctorDisc.v });
    s.rows.forEach((r) => rows.push({ kind: r.kind, refId: r.refId, option: r.option, rate: r.rate, qty: r.qty, discType: r.discType, discValue: r.discValue }));
    return { rows, paid: s.paid, comp: s.comp };
  }
  const calc = (s) => computeBill(fullState(s), lookup);

  // ----- page skeleton -----
  c.innerHTML = `
    <div id="tabs" class="tabs"></div>
    <div class="pos">
      <section class="pos-center">
        <div class="card inv">
          <div class="row-gap" style="margin-bottom:8px">
            <div class="seg"><button class="btn small active" data-k="service" type="button">Services</button><button class="btn small" data-k="lab" type="button">Lab / Tests</button></div>
            <input id="svc" list="dl-svc" class="inline" style="max-width:340px" placeholder="Search and press Enter (Alt+S)" autocomplete="off">
            <input id="qty" class="num-in" style="width:64px" value="1" inputmode="numeric" aria-label="Quantity">
            <button class="btn" id="add" type="button">Add</button><span id="svcmsg" class="error"></span>
          </div>
          <datalist id="dl-svc"></datalist>
          <div class="table-wrap"><table class="inv-table"><thead><tr><th>S.No</th><th>Service</th><th>Discount</th><th class="right">Qty</th><th class="right">Rate</th><th class="right">Total</th><th></th></tr></thead>
            <tbody id="rows"></tbody></table></div>
        </div>
        <div class="card totals">
          <div class="tot-grid">
            <div><div class="muted">Subtotal</div><div class="big" id="tg"></div></div>
            <div><div class="muted">Discount</div><div class="big" id="td"></div></div>
            <div><div class="muted">Grand total</div><div class="big blue" id="tn"></div></div>
            <div><div class="muted" id="bl">Balance</div><div class="big" id="tb"></div></div>
          </div>
          <div class="row-gap" style="margin-top:10px">
            <label class="inl">Payment<select id="pm">${methods.map((m) => `<option value="${esc(m.id)}">${esc(m.name)}</option>`).join('')}</select></label>
            <label class="inl">Paid (Alt+P)<input id="paid" inputmode="decimal" autocomplete="off" style="width:130px"></label>
            <button class="btn small" id="full" type="button">Full</button>
            ${limits.canComplimentary ? '<label class="inl chk"><input type="checkbox" id="comp"> Complimentary</label><input id="compWhy" class="inline" style="max-width:220px;display:none" placeholder="Reason" maxlength="120">' : ''}
          </div>
          <div id="perr" class="error"></div>
          <div class="row-gap" style="margin-top:8px">
            <button class="btn primary" id="post" type="button">Post</button><button class="btn primary" id="print" type="button">Print</button>
            <button class="btn" id="hold" type="button">Hold</button><span class="hint">Post saves only. Print posts the slip, then prints it.</span>
          </div>
        </div>
      </section>
      <aside class="pos-right card">
        <h2>Patient</h2>
        <label>Name<input id="pn" maxlength="80" autocomplete="off"></label>
        <div class="grid2" style="gap:0 10px">
          <label>Age<input id="pa" inputmode="numeric" maxlength="3" autocomplete="off"></label>
          <label>Gender (M / F)<input id="pg" list="dl-g" maxlength="6" autocomplete="off"></label>
        </div><datalist id="dl-g">${GENDERS.map((g) => `<option value="${g}">`).join('')}</datalist>
        <label>Doctor (Alt+D)<input id="doc" list="dl-doc" autocomplete="off" placeholder="Type to search"></label>
        <datalist id="dl-doc">${doctors.map((d) => `<option value="${esc(d.name)}">${esc(d.specialization)}</option>`).join('')}</datalist>
        <div id="docinfo" class="doc-info"></div>
      </aside>
    </div>`;

  const els = { rows: $('#rows', c), svc: $('#svc', c), qty: $('#qty', c) };
  let kind = 'service';
  const fillList = () => {
    $('#dl-svc', c).innerHTML = services.filter((s) => s.kind === kind).sort((a, b) => a.name.localeCompare(b.name))
      .map((s) => `<option value="${esc(s.name)}">${esc(s.category)}</option>`).join('');
  };
  fillList();
  c.querySelectorAll('.seg button').forEach((b) => (b.onclick = () => {
    kind = b.dataset.k;
    c.querySelectorAll('.seg button').forEach((x) => x.classList.toggle('active', x === b));
    fillList();
    els.svc.focus();
  }));

  // ----- drawing -----
  function drawTabs() {
    $('#tabs', c).innerHTML = tabs.length > 1 || tabs[0].posted
      ? tabs.map((t, i) => `<span class="tab ${i === cur ? 'active' : ''}" data-i="${i}">${esc(t.posted ? t.posted.receiptNo : t.patientName || `Slip ${i + 1}`)}
          <button class="x" data-x="${i}" aria-label="Close slip">×</button></span>`).join('') : '';
    c.querySelectorAll('.tab').forEach((t) => (t.onclick = (e) => {
      if (e.target.dataset.x !== undefined) return;
      cur = Number(t.dataset.i); fillForm(); draw();
    }));
    c.querySelectorAll('.tab .x').forEach((x) => (x.onclick = async (e) => {
      e.stopPropagation();
      const i = Number(x.dataset.x);
      if (hasData(tabs[i]) && !tabs[i].posted && !(await ask('Close this slip?', 'The slip has not been saved. Close it and lose its data?', 'Close slip'))) return;
      tabs.splice(i, 1);
      if (!tabs.length) tabs.push({ ...blank(), methodId: methods[0].id });
      cur = Math.min(cur, tabs.length - 1);
      persist(); fillForm(); draw();
    }));
  }
  const optLabel = (o, i) => `P${i + 1} · ${money(o)}`;
  function rowHtml(r, i, t) {
    const lk = lookup(r.kind, r.refId);
    const canDisc = limits.canDiscount;
    const disc = `<select data-dt="${i}" ${canDisc ? '' : 'disabled'}><option value="none">-</option><option value="percent" ${r.discType === 'percent' ? 'selected' : ''}>%</option><option value="fixed" ${r.discType === 'fixed' ? 'selected' : ''}>Rs</option></select>
      <input class="num-in tiny" data-dv="${i}" value="${esc(r.discValue)}" ${canDisc && r.discType !== 'none' ? '' : 'disabled'} inputmode="decimal">`;
    let rate;
    if (r.kind === 'doctor') {
      rate = lk.mode === 'negotiable' && limits.canNegotiate
        ? `<input class="num-in" data-rate="${i}" value="${esc(r.rate)}" inputmode="decimal" title="Allowed ${lk.min} - ${lk.max}">`
        : money(r.rate);
    } else {
      const canCustom = lk.mode === 'negotiable' && limits.canNegotiate;
      const custom = Boolean(t.rows[i - (doctorOf(t) ? 1 : 0)]?.custom);
      rate = `${lk.options.length > 1 || canCustom ? `<select data-opt="${i}">${lk.options.map((o, k) => `<option value="${k + 1}" ${!custom && r.option === k + 1 ? 'selected' : ''}>${optLabel(o, k)}</option>`).join('')}${canCustom ? `<option value="custom" ${custom ? 'selected' : ''}>Custom</option>` : ''}</select>` : ''}
        ${custom ? `<input class="num-in" data-rate="${i}" value="${esc(r.rate)}" inputmode="decimal" title="Allowed ${lk.min} - ${lk.max}">` : lk.options.length > 1 || canCustom ? '' : money(r.rate)}`;
    }
    return `<tr data-i="${i}" class="${t.sel === i ? 'sel' : ''}"><td>${i + 1}</td><td>${r.kind === 'doctor' ? 'Consultation: ' : ''}${esc(lk.name)}</td>
      <td>${disc}</td><td class="right">${r.kind === 'doctor' ? 1 : `<input class="num-in tiny" data-q="${i}" value="${r.qty}" inputmode="numeric">`}</td>
      <td class="right">${rate}</td><td class="right">${money(r.lineTotal)}</td>
      <td>${r.kind === 'doctor' ? '' : `<button class="x" data-del="${i}" aria-label="Delete row">×</button>`}</td></tr>`;
  }
  function draw() {
    const s = st();
    drawTabs();
    if (s.posted) { drawPosted(s); return; }
    $('.pos', c).classList.remove('posted');
    const t = calc(s);
    els.rows.innerHTML = t.rows.length ? t.rows.map((r, i) => rowHtml(r, i, s)).join('')
      : '<tr><td colspan="7" class="muted" style="padding:18px">Select a doctor and/or add services.</td></tr>';
    drawTotals();
    const d = doctorOf(s);
    $('#docinfo', c).innerHTML = d ? `<div><strong>${esc(d.name)}</strong></div><div class="muted">${esc([d.category, d.specialization].filter(Boolean).join(' · '))}</div>
      <div class="muted">${esc([d.day, d.time].filter(Boolean).join(' · '))}</div>
      <div>Fee: <strong>${money(s.doctorRate ?? d.fee)}</strong> ${d.mode === 'negotiable' ? '<span class="pill part">Negotiable</span>' : '<span class="pill on">Fixed</span>'}</div>` : '';
    persist();
  }
  function drawTotals() {
    const s = st();
    const t = calc(s);
    $('#tg', c).textContent = money(t.gross);
    $('#td', c).textContent = money(t.discount);
    $('#tn', c).textContent = money(t.net);
    $('#bl', c).textContent = t.change > 0 ? 'Change' : 'Balance';
    $('#tb', c).textContent = money(t.change > 0 ? t.change : t.outstanding);
  }
  function drawPosted(s) {
    const b = s.posted;
    els.rows.innerHTML = `<tr><td colspan="7" style="padding:20px"><strong>${esc(b.receiptNo)}</strong> ${isOnline() ? 'posted.' : 'saved on this computer. It will sync when the internet returns.'}
      ${b.printFailed ? '<div class="error">The printer did not respond. The slip is saved: use Print to try again.</div>' : ''}
      <div class="row-gap" style="margin-top:10px"><button class="btn primary" id="rp">Print again</button><button class="btn" id="ns">New slip</button></div></td></tr>`;
    $('#rp', c).onclick = () => printBill(cfg, b);
    $('#ns', c).onclick = () => newSlip(true);
    $('#tg', c).textContent = money(b.gross); $('#td', c).textContent = money(b.discount); $('#tn', c).textContent = money(b.net); $('#tb', c).textContent = money(b.outstanding);
  }
  function fillForm() {
    const s = st();
    $('#pn', c).value = s.patientName; $('#pa', c).value = s.age; $('#pg', c).value = s.gender;
    $('#doc', c).value = doctorOf(s)?.name || ''; $('#paid', c).value = s.paid; $('#pm', c).value = s.methodId;
    const cb = $('#comp', c);
    if (cb) { cb.checked = s.comp; $('#compWhy', c).style.display = s.comp ? '' : 'none'; $('#compWhy', c).value = s.compReason; }
  }

  // ----- inputs -----
  const touch = () => { persist(); drawTotals(); };
  $('#pn', c).oninput = (e) => { st().patientName = e.target.value; persist(); drawTabs(); };
  $('#pa', c).oninput = (e) => { st().age = e.target.value.replace(/\D/g, ''); e.target.value = st().age; persist(); };
  $('#pg', c).oninput = (e) => {
    const v = e.target.value.trim().toLowerCase();
    const full = v === 'm' ? 'Male' : v === 'f' ? 'Female' : v === 'o' ? 'Other' : GENDERS.find((g) => g.toLowerCase() === v) || '';
    if (full && e.target.value !== full) e.target.value = full;
    st().gender = full; persist();
  };
  $('#doc', c).oninput = (e) => {
    const v = e.target.value.trim().toLowerCase();
    const d = doctors.find((x) => x.name.toLowerCase() === v);
    st().doctorId = d?.id || ''; st().doctorRate = null; st().doctorDisc = { t: 'none', v: '' };
    draw();
  };
  $('#pm', c).onchange = (e) => { st().methodId = e.target.value; persist(); };
  $('#paid', c).oninput = (e) => { st().paid = e.target.value; touch(); };
  $('#full', c).onclick = () => { st().paid = String(calc(st()).net); $('#paid', c).value = st().paid; touch(); };
  const cb = $('#comp', c);
  if (cb) {
    cb.onchange = () => { st().comp = cb.checked; $('#compWhy', c).style.display = cb.checked ? '' : 'none'; touch(); };
    $('#compWhy', c).oninput = (e) => { st().compReason = e.target.value; persist(); };
  }
  function addService() {
    const m = $('#svcmsg', c);
    m.textContent = '';
    const name = els.svc.value.trim().toLowerCase();
    const sv = services.find((x) => x.kind === kind && x.name.toLowerCase() === name);
    const q = Number(els.qty.value);
    if (!sv) { m.textContent = 'Choose an item from the list.'; return; }
    if (!Number.isInteger(q) || q < 1 || q > 99) { m.textContent = 'Quantity must be 1-99.'; return; }
    const s = st();
    const ex = s.rows.find((r) => r.refId === sv.id && r.option === 1 && !r.custom && r.discType === 'none');
    if (ex) ex.qty = Math.min(99, ex.qty + q);
    else if (s.rows.length >= MAX_SERVICE_ROWS) { m.textContent = `At most ${MAX_SERVICE_ROWS} items per slip.`; return; }
    else s.rows.push({ kind: sv.kind, refId: sv.id, option: 1, rate: sv.options[0], qty: q, custom: false, discType: 'none', discValue: '' });
    els.svc.value = ''; els.qty.value = '1'; els.svc.focus();
    draw();
  }
  $('#add', c).onclick = addService;
  els.svc.onkeydown = (e) => { if (e.key === 'Enter') { e.preventDefault(); addService(); } };

  // row edits (event delegation on the table)
  const idx = (el) => Number(el.dataset.i ?? el.closest('tr')?.dataset.i);
  const target = (i) => { const s = st(); const hasDoc = Boolean(doctorOf(s)); return i === 0 && hasDoc ? { doctor: true } : { row: s.rows[i - (hasDoc ? 1 : 0)] }; };
  els.rows.onclick = (e) => {
    const tr = e.target.closest('tr[data-i]');
    if (e.target.dataset.del !== undefined) { const r = target(Number(e.target.dataset.del)).row; st().rows.splice(st().rows.indexOf(r), 1); st().sel = -1; draw(); return; }
    if (tr) { st().sel = Number(tr.dataset.i); els.rows.querySelectorAll('tr').forEach((x) => x.classList.toggle('sel', x === tr)); }
  };
  els.rows.onchange = (e) => {
    const el = e.target;
    const i = idx(el);
    const tg = target(i);
    const s = st();
    if (el.dataset.dt !== undefined) {
      const v = el.value;
      if (tg.doctor) s.doctorDisc = { t: v, v: v === 'none' ? '' : s.doctorDisc.v }; else { tg.row.discType = v; if (v === 'none') tg.row.discValue = ''; }
    } else if (el.dataset.dv !== undefined) {
      if (tg.doctor) s.doctorDisc.v = el.value; else tg.row.discValue = el.value;
    } else if (el.dataset.q !== undefined) {
      const q = Number(el.value);
      if (Number.isInteger(q) && q >= 1 && q <= 99) tg.row.qty = q;
    } else if (el.dataset.opt !== undefined) {
      const sv = lookup(tg.row.kind, tg.row.refId);
      if (el.value === 'custom') tg.row.custom = true;
      else { tg.row.custom = false; tg.row.option = Number(el.value); tg.row.rate = sv.options[tg.row.option - 1]; }
    } else if (el.dataset.rate !== undefined) {
      const n = parseMoney(el.value, true);
      if (n !== null) { if (tg.doctor) s.doctorRate = n; else tg.row.rate = n; }
    }
    draw();
  };

  // ----- validation, posting, holding -----
  function validate(s, t) {
    if (lic) return 'The licence has expired. Please contact the administrator.';
    if (s.patientName.trim().length < 2) return 'Enter the patient name.';
    if (!/^\d{1,3}$/.test(String(s.age)) || Number(s.age) > 150) return 'Enter a valid age.';
    if (!GENDERS.includes(s.gender)) return 'Enter the gender (M or F).';
    if (!t.rows.length || t.gross <= 0) return 'Add a doctor and/or services.';
    for (const r of t.rows) {
      const lk = lookup(r.kind, r.refId);
      const base = r.kind === 'doctor' ? lk.fee : lk.options[r.option - 1];
      if (r.rate !== base) {
        if (lk.mode !== 'negotiable' || !limits.canNegotiate) return `${lk.name}: the rate cannot be changed.`;
        if (r.rate < lk.min || r.rate > lk.max) return `${lk.name}: rate must be between ${money(lk.min)} and ${money(lk.max)}.`;
      }
      if (r.discType !== 'none') {
        if (!limits.canDiscount) return 'You are not allowed to give a discount.';
        const v = Number(r.discValue);
        if (!(v > 0)) return `${lk.name}: enter the discount value.`;
        if (r.discType === 'percent' && (v > 100 || v > limits.maxDiscountPercent)) return `${lk.name}: discount is more than your allowed ${limits.maxDiscountPercent}%.`;
        if (r.discType === 'fixed' && v > limits.maxDiscountFixed) return `${lk.name}: discount is more than your allowed ${money(limits.maxDiscountFixed)}.`;
      }
    }
    if (s.comp && (!limits.canComplimentary || s.compReason.trim().length < 3)) return 'Enter the reason for the complimentary slip.';
    if (s.paid !== '' && parseMoney(s.paid, true) === null) return 'Enter a valid paid amount.';
    return '';
  }
  let busy = false;
  async function post(print) {
    const s = st();
    if (s.posted) { if (print) printBill(cfg, s.posted); return; }
    if (busy) return; // blocks double clicks
    const t = calc(s);
    const err = validate(s, t);
    $('#perr', c).textContent = err;
    if (err) return;
    busy = true;
    const method = methods.find((m) => m.id === s.methodId);
    if (isOnline()) {
      // Fresh check from the server: if the shift is really not open, posting stays blocked with the exact reason.
      const chk = await verifyOpenShift(ctx.uid);
      if (!chk.ok && !chk.network) { busy = false; $('#perr', c).textContent = chk.message; ctx.refreshShift?.(); return; }
      if (chk.ok) ctx.setShift?.(chk.shift);
    }
    let billForCheck = null;
    try {
      if (!s.pending) {
        const seq = await nextSeqOf(ctx.uid, 'rc');
        s.pending = { seq, receiptNo: makeNumber(cfg.general.receiptPrefix, ctx.profile.receiptCode, seq) };
        persist();
      }
      const { seq, receiptNo } = s.pending;
      const d = doctorOf(s);
      const bill = {
        receiptNo, seq, rc: ctx.profile.receiptCode, patientName: s.patientName.trim(), patientLower: s.patientName.trim().toLowerCase(),
        age: Number(s.age), gender: s.gender, doctorId: d ? d.id : '', doctorName: d ? d.name : '',
        rows: t.rows.map((r) => ({ kind: r.kind, refId: r.refId, name: r.name, option: r.option, rate: r.rate, qty: r.qty,
          discType: r.discType, discValue: r.discType === 'none' ? 0 : Number(r.discValue), discount: r.discount, lineTotal: r.lineTotal })),
        gross: t.gross, discount: t.discount, compAmount: t.compAmount, complimentary: Boolean(s.comp), compReason: s.comp ? s.compReason.trim() : '',
        net: t.net, tendered: t.tendered, change: t.change, initialPaid: t.initialPaid, received: t.initialPaid, outstanding: t.outstanding,
        hadBalance: t.outstanding > 0.004, owing: t.outstanding > 0.004, paymentMethodId: method.id, paymentMethodName: method.name, isCash: method.isCash, status: 'posted',
        shiftId: ctx.shift().id, receptionistUid: ctx.uid, receptionistName: ctx.name,
      };
      billForCheck = bill;
      const batch = writeBatch(db);
      batch.set(doc(db, 'counters', `rc_${ctx.uid}`), { value: seq });
      batch.set(doc(db, 'bills', receiptNo), { ...bill, createdAt: serverTimestamp(), clientAt: Date.now() });
      if (s.heldId) batch.delete(doc(db, 'heldBills', s.heldId));
      batch.set(doc(collection(db, 'auditLogs')), auditData(ctx.uid, 'receptionist', 'bill.post', 'bill', receiptNo, { net: t.net, shiftId: ctx.shift().id }));
      const p = track(batch.commit(), { id: receiptNo, type: 'bill', label: `Slip ${receiptNo}`, path: ['bills', receiptNo], draft: JSON.stringify(strip(s)) });
      // When online the answer comes back quickly; if the rules refuse the slip we hear about it here.
      const quick = await Promise.race([p.then(() => 'ok'), new Promise((r) => setTimeout(() => r('wait'), 1800))]);
      void quick;
      rememberSeq(ctx.uid, 'rc', seq);
      s.posted = { ...bill, clientAt: Date.now(), printFailed: false };
      s.pending = null;
      persist();
      if (print) s.posted.printFailed = !printBill(cfg, s.posted);
      draw();
      ctx.afterPost?.();
    } catch (e) {
      console.error('Post failed', e.code, e.message);
      $('#perr', c).textContent = 'Checking why the slip was refused…';
      const fb = billForCheck || { shiftId: ctx.shift().id, rc: ctx.profile.receiptCode, rows: [], paymentMethodId: method.id, paymentMethodName: method.name, isCash: method.isCash, seq: 0 };
      $('#perr', c).textContent = await explainFailure(ctx.uid, ctx.name, fb, e);
      // A refused number is released so the next try starts clean.
      s.pending = null; localStorage.removeItem(`seq:rc:${ctx.uid}`);
    } finally { busy = false; }
  }
  $('#post', c).onclick = () => post(false);
  $('#print', c).onclick = () => post(true);

  async function hold() {
    const s = st();
    if (s.posted || !hasData(s)) { toast('Nothing to hold.', true); return; }
    const ref = s.heldId ? doc(db, 'heldBills', s.heldId) : doc(collection(db, 'heldBills'));
    const batch = writeBatch(db);
    batch.set(ref, { receptionistUid: ctx.uid, receptionistName: ctx.name, shiftId: ctx.shift().id, title: (s.patientName || 'No name').slice(0, 80),
      draft: JSON.stringify(strip({ ...s, heldId: ref.id })).slice(0, 19000), savedAt: serverTimestamp() });
    batch.set(doc(collection(db, 'auditLogs')), auditData(ctx.uid, 'receptionist', 'bill.hold', 'heldBill', ref.id));
    track(batch.commit(), { id: `hold-${ref.id}`, type: 'hold', label: 'Held invoice', path: ['heldBills', ref.id] });
    tabs[cur] = { ...blank(), methodId: methods[0].id };
    persist(); fillForm(); draw();
    toast('Invoice held.');
  }
  $('#hold', c).onclick = hold;

  async function newSlip(force) {
    const s = st();
    if (!force && hasData(s) && !s.posted) {
      const m = modal(`<h2>New slip</h2><p>The current slip has data that is not saved.</p>
        <div class="row-gap" style="justify-content:flex-end"><button class="btn" id="c">Cancel</button><button class="btn" id="d">Discard &amp; New</button><button class="btn primary" id="h">Save &amp; New</button></div>`);
      $('#c', m.el).onclick = m.close;
      $('#d', m.el).onclick = () => { m.close(); tabs[cur] = { ...blank(), methodId: methods[0].id }; persist(); fillForm(); draw(); els.svc.focus(); };
      $('#h', m.el).onclick = async () => { m.close(); await hold(); };
      return;
    }
    tabs[cur] = { ...blank(), methodId: methods[0].id };
    persist(); fillForm(); draw();
    $('#pn', c).focus();
  }
  function deleteRow() {
    const s = st();
    const hasDoc = Boolean(doctorOf(s));
    let i = s.sel >= 0 ? s.sel - (hasDoc ? 1 : 0) : s.rows.length - 1;
    if (i < 0 || i >= s.rows.length) { toast('Select a service row first.', true); return; }
    s.rows.splice(i, 1); s.sel = -1; draw();
  }

  // ----- hooks used by the left rail and the keyboard shortcuts -----
  ctx.bill = {
    post: () => post(false), print: () => post(true), hold, newSlip: () => newSlip(false), deleteRow,
    focus: (n) => ({ doctor: '#doc', service: '#svc', discount: '[data-dt]', paid: '#paid' }[n] && ($({ doctor: '#doc', service: '#svc', discount: '[data-dt]', paid: '#paid' }[n], c)?.focus())),
    hasUnsaved: () => tabs.some((t) => !t.posted && hasData(t)),
  };
  fillForm();
  draw();
  $('#pn', c).focus();
}

// ---------- Held invoices ----------
export async function heldPage(c, ctx) {
  c.innerHTML = '<p class="muted">Loading…</p>';
  let held;
  try { held = await list('heldBills', where('receptionistUid', '==', ctx.uid)); }
  catch { c.innerHTML = '<div class="card error">Could not load the held invoices.</div>'; return; }
  held.sort((a, b) => (b.savedAt?.seconds || 0) - (a.savedAt?.seconds || 0));
  c.innerHTML = `<div class="card"><h2>Held invoices</h2>
    <p class="muted">Held invoices are drafts. They are not sales and no money is counted for them. They cannot carry over to the next shift.</p>
    ${held.length ? `<table><thead><tr><th>Saved</th><th>Patient</th><th></th></tr></thead><tbody>
      ${held.map((h) => `<tr><td>${esc(h.savedAt?.toDate ? h.savedAt.toDate().toLocaleString() : 'just now')}</td><td>${esc(h.title)}</td>
        <td class="row-gap"><button class="btn small primary" data-res="${esc(h.id)}">Continue</button><button class="btn small" data-del="${esc(h.id)}">Delete</button></td></tr>`).join('')}</tbody></table>`
      : '<p class="muted">No held invoices.</p>'}</div>`;
  c.querySelectorAll('[data-res]').forEach((b) => {
    b.onclick = () => {
      const h = held.find((x) => x.id === b.dataset.res);
      try { ctx.resume = { ...blank(), ...JSON.parse(h.draft), heldId: h.id }; } catch { toast('This held invoice could not be opened.', true); return; }
      ctx.go('bill');
    };
  });
  c.querySelectorAll('[data-del]').forEach((b) => {
    b.onclick = async () => {
      if (!(await ask('Delete held invoice?', 'This held invoice will be removed.', 'Delete'))) return;
      const batch = writeBatch(db);
      batch.delete(doc(db, 'heldBills', b.dataset.del));
      track(batch.commit(), { id: `del-${b.dataset.del}`, type: 'hold', label: 'Held invoice removed', path: ['heldBills', b.dataset.del] }).catch(() => {});
      b.closest('tr').remove();
    };
  });
}
export async function heldCount(uid) {
  try { return (await list('heldBills', where('receptionistUid', '==', uid))).length; } catch { return 0; }
}
