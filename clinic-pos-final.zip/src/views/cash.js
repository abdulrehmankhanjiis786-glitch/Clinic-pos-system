// Cash In / Cash Out for the receptionist (works offline). Reference numbers are automatic; there is no category.
import { collection, doc, writeBatch, serverTimestamp, where } from 'firebase/firestore';
import { db } from '../firebase.js';
import { auditData } from '../auth.js';
import { esc, $, fmtTime, toast } from '../util.js';
import { page, money, nextSeq, rememberSeq } from '../data.js';
import { parseMoney, pad6, round2 } from '../calc.js';
import { track } from '../offline.js';
import { verifyOpenShift } from '../data.js';
import { isOnline } from '../offline.js';

const errCard = '<div class="card error">Could not load data. Check your connection and try again.</div>';

export async function cashPage(c, ctx, startType = 'in') {
  const shift = ctx.shift();
  if (!shift) { c.innerHTML = '<div class="card"><h2>Cash In / Out</h2><p class="muted">Open your shift first.</p></div>'; return; }
  const lim = ctx.cfg().limits;
  let txs = [];
  try { txs = (await page('cashTransactions', [where('shiftId', '==', shift.id), where('receptionistUid', '==', ctx.uid)], null, 100)).rows; }
  catch { /* offline: list may be empty */ }
  txs.sort((a, b) => (b.createdAt?.seconds || b.clientAt / 1000 || 0) - (a.createdAt?.seconds || a.clientAt / 1000 || 0));
  const sum = (t) => round2(txs.filter((x) => x.type === t).reduce((s, x) => s + x.amount, 0));
  c.innerHTML = `<div class="card"><h2>Cash In / Out</h2>
    <form id="f" class="row-gap"><select name="type" class="inline" style="width:130px"><option value="in" ${lim.canCashIn ? '' : 'disabled'}>Cash In</option><option value="out" ${lim.canCashOut ? '' : 'disabled'}>Cash Out</option></select>
      <input name="amount" class="num-in" inputmode="decimal" placeholder="Amount" required autocomplete="off">
      <input name="remarks" class="inline" style="max-width:320px" placeholder="Remarks" maxlength="200" autocomplete="off">
      <button class="btn primary">Save</button><span id="msg" class="error"></span></form>
    <p class="hint">The reference number and the time are added automatically. Saved entries cannot be changed or deleted.${lim.canCashOut && lim.cashOutLimit > 0 ? ` Cash Out limit per entry: ${money(lim.cashOutLimit)}.` : ''}</p></div>
    <div class="card"><h2>This shift</h2><p>Cash In: <strong>${money(sum('in'))}</strong> &nbsp; Cash Out: <strong>${money(sum('out'))}</strong></p>
    ${txs.length ? `<table><thead><tr><th>Reference</th><th>Time</th><th>Type</th><th class="right">Amount</th><th>Remarks</th></tr></thead><tbody>
      ${txs.map((x) => `<tr><td>${esc(x.reference)}</td><td>${esc(fmtTime(x.createdAt) || new Date(x.clientAt || 0).toLocaleString())}</td><td>${x.type === 'in' ? 'Cash In' : 'Cash Out'}</td><td class="right">${money(x.amount)}</td><td>${esc(x.reason)}</td></tr>`).join('')}</tbody></table>`
      : '<p class="muted">No cash entries yet.</p>'}</div>`;
  const f = $('#f', c);
  f.type.value = startType === 'out' && lim.canCashOut ? 'out' : lim.canCashIn ? 'in' : 'out';
  let busy = false;
  f.onsubmit = async (e) => {
    e.preventDefault();
    if (busy) return;
    const msg = $('#msg', c);
    const amount = parseMoney(f.amount.value);
    const type = f.type.value;
    if (amount === null) { msg.textContent = 'Enter a valid amount.'; return; }
    if (type === 'out' && lim.cashOutLimit > 0 && amount > lim.cashOutLimit) { msg.textContent = 'This is above your Cash Out limit.'; return; }
    if (!ctx.profile.receiptCode) { msg.textContent = 'Your receipt code is not set up. Ask the Admin.'; return; }
    busy = true; msg.textContent = '';
    try {
      const seq = await nextSeq(ctx.uid, 'xc');
      const reference = `${type === 'in' ? 'CI' : 'CO'}${ctx.profile.receiptCode}-${pad6(seq)}`;
      const batch = writeBatch(db);
      batch.set(doc(db, 'counters', `xc_${ctx.uid}`), { value: seq });
      batch.set(doc(db, 'cashTransactions', reference), { type, amount, reason: f.remarks.value.trim(), reference, shiftId: shift.id, receptionistUid: ctx.uid,
        receptionistName: ctx.name, rc: ctx.profile.receiptCode, seq, createdAt: serverTimestamp(), clientAt: Date.now() });
      batch.set(doc(collection(db, 'auditLogs')), auditData(ctx.uid, 'receptionist', type === 'in' ? 'cash.in' : 'cash.out', 'cashTransaction', reference, { amount, shiftId: shift.id }));
      const p = track(batch.commit(), { id: reference, type: 'cash', label: `${type === 'in' ? 'Cash In' : 'Cash Out'} ${reference}`, path: ['cashTransactions', reference] });
      await Promise.race([p, new Promise((r) => setTimeout(r, 1800))]);
      rememberSeq(ctx.uid, 'xc', seq);
      toast(`${reference} saved${isOnline() ? '' : ' (will sync later)'}.`);
      cashPage(c, ctx, type);
    } catch (ex) {
      console.error('Cash entry failed', ex.code, ex.message);
      const chk = isOnline() ? await verifyOpenShift(ctx.uid) : { ok: true };
      msg.textContent = !chk.ok ? chk.message : 'The entry was refused. Check your Cash In / Cash Out permission and limit.';
      busy = false;
    }
  };
}
