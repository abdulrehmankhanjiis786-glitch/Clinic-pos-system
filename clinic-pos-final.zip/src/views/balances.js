// Outstanding balances: search / filter, receive a payment (separate payment record, original slip stays locked), history.
import { collection, doc, writeBatch, serverTimestamp, where, orderBy, Timestamp } from 'firebase/firestore';
import { db } from '../firebase.js';
import { auditData } from '../auth.js';
import { esc, $, fmtTime, toast, startOfDay, endOfDay, parseDateInput } from '../util.js';
import { page, getBill, money, nextSeq, rememberSeq } from '../data.js';
import { round2, parseMoney, pad6 } from '../calc.js';
import { track, fastGet, isOnline } from '../offline.js';
import { printPayment } from './receipt.js';
import { slipPanel } from './slips.js';

const errCard = '<div class="card error">Could not load data. Check your connection and try again.</div>';
const RECEIPT = /^[A-Za-z0-9]{3,8}-\d{6}$/;
export const balStatus = (b) => (b.outstanding <= 0.004 ? 'Paid' : (b.received || 0) <= 0.004 ? 'Unpaid' : 'Partially Paid');
const cls = (s) => ({ Paid: 'paid', Unpaid: 'unpaid', 'Partially Paid': 'part' }[s]);

export async function balancesPage(c, ctx) {
  const canCollect = ctx.role === 'receptionist';
  c.innerHTML = `<div class="card"><div class="row-gap" style="margin-bottom:8px"><h2 style="margin:0">Outstanding Balance</h2><span class="grow"></span>
    <select id="st" class="inline" style="width:150px"><option value="open">Unpaid / Partial</option><option value="paid">Paid later</option><option value="all">All</option></select>
    <label class="inl">From<input type="date" id="df"></label><label class="inl">To<input type="date" id="dt"></label>
    <input id="q" class="search" placeholder="Receipt no. or patient name"><button class="btn small primary" id="go">Search</button></div>
    <div id="out"></div><button class="btn small" id="more" style="display:none;margin-top:8px">Load more</button></div><div id="panel"></div>`;
  let after = null, rows = [];
  async function load(reset) {
    if (reset) { after = null; rows = []; }
    const text = $('#q', c).value.trim();
    const st = $('#st', c).value;
    const stCons = st === 'open' ? [where('owing', '==', true)] : st === 'paid' ? [where('hadBalance', '==', true), where('owing', '==', false)] : [where('hadBalance', '==', true)];
    try {
      if (RECEIPT.test(text)) { const b = await getBill(text.toUpperCase()); rows = b && b.hadBalance ? [b] : []; $('#more', c).style.display = 'none'; }
      else {
        let cons;
        if (text) { const p = text.toLowerCase(); cons = [...stCons, where('patientLower', '>=', p), where('patientLower', '<=', p + '\uf8ff'), orderBy('patientLower')]; }
        else {
          const df = $('#df', c).value, dt = $('#dt', c).value;
          cons = [...stCons, ...(df ? [where('createdAt', '>=', Timestamp.fromDate(startOfDay(parseDateInput(df))))] : []),
            ...(dt ? [where('createdAt', '<=', Timestamp.fromDate(endOfDay(parseDateInput(dt))))] : []), orderBy('createdAt', 'desc')];
        }
        const r = await page('bills', cons, after);
        rows = rows.concat(r.rows); after = r.last; $('#more', c).style.display = r.more ? '' : 'none';
      }
    } catch { $('#out', c).innerHTML = errCard; return; }
    draw();
  }
  function draw() {
    $('#out', c).innerHTML = rows.length
      ? `<table><thead><tr><th>Invoice</th><th>Date</th><th>Patient</th><th class="right">Original total</th><th class="right">Paid</th><th class="right">Outstanding</th><th>Status</th><th></th></tr></thead><tbody>
        ${rows.map((b) => `<tr><td>${esc(b.receiptNo)}</td><td>${esc(fmtTime(b.createdAt))}</td><td>${esc(b.patientName)}</td><td class="right">${money(b.net)}</td>
          <td class="right">${money(b.received)}</td><td class="right"><strong>${money(b.outstanding)}</strong></td>
          <td><span class="pill ${cls(balStatus(b))}">${balStatus(b)}</span></td><td><button class="btn small" data-id="${esc(b.id)}">Open</button></td></tr>`).join('')}</tbody></table>`
      : '<p class="muted">No balances found.</p>';
    c.querySelectorAll('button[data-id]').forEach((b) => (b.onclick = () => openBill(b.dataset.id)));
  }
  async function openBill(id) {
    const panel = $('#panel', c);
    panel.innerHTML = '<div class="card muted">Loading…</div>';
    const cfg = ctx.cfg();
    let bill, pays;
    try {
      bill = await getBill(id);
      pays = (await page('payments', [where('billId', '==', id)], null, 50)).rows.sort((a, b) => (a.createdAt?.seconds || 0) - (b.createdAt?.seconds || 0));
    } catch { panel.innerHTML = errCard; return; }
    const lim = cfg.limits || {};
    const methods = cfg.methods.filter((m) => m.active);
    const shift = canCollect ? ctx.shift() : null;
    const mine = bill.receptionistUid === ctx.uid;
    const allowed = canCollect && lim.canCollectOutstanding && (mine || lim.canCollectOthers);
    panel.innerHTML = `<div class="card"><h2>${esc(bill.patientName)} — ${esc(bill.receiptNo)} <span class="pill ${cls(balStatus(bill))}">${balStatus(bill)}</span></h2>
      <table><tbody><tr><td>Original total</td><td class="right">${money(bill.net)}</td></tr><tr><td>Already paid</td><td class="right">${money(bill.received)}</td></tr>
        <tr style="font-weight:700"><td>Remaining balance</td><td class="right">${money(bill.outstanding)}</td></tr></tbody></table>
      <h3 class="sec-title">Payment history</h3>
      <table><thead><tr><th>Reference</th><th>Amount</th><th>Method</th><th>Date and time</th><th>Receptionist</th><th></th></tr></thead><tbody>
        <tr><td>${esc(bill.receiptNo)}</td><td>${money(bill.initialPaid ?? 0)}</td><td>${esc(bill.paymentMethodName)} (at billing)</td><td>${esc(fmtTime(bill.createdAt))}</td><td>${esc(bill.receptionistName)}</td><td></td></tr>
        ${pays.map((p) => `<tr><td>${esc(p.paymentNo)}</td><td>${money(p.amount)}</td><td>${esc(p.methodName)}</td><td>${esc(fmtTime(p.createdAt))}</td><td>${esc(p.receptionistName)}</td>
          <td><button class="btn small" data-rp="${esc(p.id)}">Receipt</button></td></tr>`).join('')}</tbody></table>
      ${canCollect ? (bill.status === 'posted' && bill.outstanding > 0.004
        ? (!allowed ? '<p class="muted" style="margin-top:12px">You are not allowed to receive this payment.</p>'
          : !shift ? '<p class="muted" style="margin-top:12px">Open your shift (Shift) to receive payments.</p>'
          : !methods.length ? '<p class="muted" style="margin-top:12px">No payment method is enabled.</p>'
          : `<h3 class="sec-title">Receive payment</h3><form id="pf" class="row-gap"><input name="amount" class="num-in" inputmode="decimal" placeholder="Amount" required autocomplete="off">
              <select name="method" class="inline" style="max-width:220px">${methods.map((m) => `<option value="${esc(m.id)}">${esc(m.name)}</option>`).join('')}</select>
              <button class="btn small" type="button" id="fl">Full</button><button class="btn primary">Receive</button><span id="pe" class="error"></span></form>`) : '') : ''}
      <div id="oks"></div><div id="slip" style="margin-top:12px"></div></div>`;
    panel.querySelectorAll('[data-rp]').forEach((b) => (b.onclick = () => { const p = pays.find((x) => x.id === b.dataset.rp); printPayment(cfg, p, bill, bill.outstanding); }));
    const pf = $('#pf', panel);
    if (pf) {
      $('#fl', panel).onclick = () => { pf.amount.value = bill.outstanding; };
      let pending = null, busy = false;
      pf.onsubmit = async (e) => {
        e.preventDefault();
        if (busy) return;
        const pe = $('#pe', panel);
        const amount = parseMoney(pf.amount.value);
        if (amount === null) { pe.textContent = 'Enter a valid amount.'; return; }
        if (amount > round2(bill.outstanding) + 0.004) { pe.textContent = `Amount is more than the balance (${money(bill.outstanding)}).`; return; }
        busy = true; pe.textContent = '';
        try {
          const method = methods.find((m) => m.id === pf.method.value);
          const cur = (await (async () => { const s = await fastGet(doc(db, 'bills', id)); return s?.exists() ? s.data() : bill; })());
          if (!pending) { const seq = await nextSeq(ctx.uid, 'pc'); pending = { seq, no: `P${ctx.profile.receiptCode}-${pad6(seq)}` }; }
          const payment = { paymentNo: pending.no, seq: pending.seq, rc: ctx.profile.receiptCode, billId: id, receiptNo: cur.receiptNo, patientName: cur.patientName,
            amount, methodId: method.id, methodName: method.name, isCash: method.isCash, shiftId: shift.id, receptionistUid: ctx.uid, receptionistName: ctx.name };
          const remaining = round2(cur.outstanding - amount);
          const batch = writeBatch(db);
          batch.set(doc(db, 'counters', `pc_${ctx.uid}`), { value: pending.seq });
          batch.set(doc(db, 'payments', pending.no), { ...payment, createdAt: serverTimestamp(), clientAt: Date.now() });
          batch.update(doc(db, 'bills', id), { received: round2(cur.received + amount), outstanding: remaining, owing: remaining > 0.004, lastPaymentId: pending.no, updatedAt: serverTimestamp() });
          batch.set(doc(collection(db, 'auditLogs')), auditData(ctx.uid, 'receptionist', 'payment.balance', 'bill', id, { amount, ref: pending.no }));
          const p = track(batch.commit(), { id: pending.no, type: 'payment', label: `Payment ${pending.no}`, path: ['payments', pending.no] });
          await Promise.race([p, new Promise((r) => setTimeout(r, 1800))]);
          rememberSeq(ctx.uid, 'pc', pending.seq);
          const ok = $('#oks', panel);
          ok.innerHTML = `<p style="margin-top:12px"><strong>Payment saved</strong> ${esc(pending.no)} — balance now ${money(remaining)}${isOnline() ? '' : ' (will sync when the internet returns)'}.
            <button class="btn small" id="pr">Print receipt</button></p>`;
          const shown = { ...payment, createdAt: null };
          $('#pr', ok).onclick = () => { if (!printPayment(cfg, shown, cur, remaining)) toast('The printer did not respond. The payment is saved.', true); };
          pending = null; pf.reset();
          bill.received = round2(cur.received + amount); bill.outstanding = remaining;
          load(true);
        } catch (ex) {
          console.error('Payment failed', ex.code, ex.message);
          pe.textContent = ex.code === 'permission-denied' ? 'The payment was refused (balance changed, permission or shift). Reopen the patient and try again.' : 'Could not save. Try again.';
          pending = null;
        } finally { busy = false; }
      };
    }
    $('#slip', panel).innerHTML = '<button class="btn small" id="vs">View full slip</button>';
    $('#vs', panel).onclick = () => slipPanel($('#slip', panel), bill, ctx, cfg, () => load(true));
  }
  $('#go', c).onclick = () => load(true);
  $('#more', c).onclick = () => load(false);
  $('#q', c).onkeydown = (e) => { if (e.key === 'Enter') load(true); };
  await load(true);
}
