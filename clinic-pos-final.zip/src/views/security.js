// Admin: backups (manual download + status of the automatic daily backup).
import { collection, doc, getDoc, getDocs, query, where, writeBatch, serverTimestamp, Timestamp } from 'firebase/firestore';
import { db, firebaseConfig } from '../firebase.js';
import { auditData } from '../auth.js';
import { esc, $, fmtTime } from '../util.js';

const PLAIN = ['doctors', 'services', 'paymentMethods', 'settings', 'staffLimits', 'receiptCodes', 'openShifts', 'shifts', 'bills', 'payments', 'cashTransactions', 'counters', 'heldBills'];
const encode = (v) => {
  if (v instanceof Timestamp) return { __ts: v.toDate().toISOString() };
  if (Array.isArray(v)) return v.map(encode);
  if (v && typeof v === 'object') return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, encode(x)]));
  return v;
};
const dump = async (name, ...cons) => (await getDocs(query(collection(db, name), ...cons))).docs.map((d) => ({ id: d.id, data: encode(d.data()) }));

export async function backupPage(c, ctx) {
  c.innerHTML = '<p class="muted">Loading…</p>';
  let status = null;
  try { const s = await getDoc(doc(db, 'meta', 'backupStatus')); status = s.exists() ? s.data() : null; } catch { /* unknown */ }
  const age = status?.autoAt?.toDate ? (Date.now() - status.autoAt.toDate().getTime()) / 86400000 : null;
  c.innerHTML = `<div class="card"><h2>Backups</h2>
    <p>Last manual backup: <strong>${status?.manualAt ? esc(fmtTime(status.manualAt)) : 'never'}</strong></p>
    <p>Last automatic backup: <strong>${status?.autoAt ? `${esc(fmtTime(status.autoAt))} (${esc(status.autoStatus || '')})${age > 2 ? ' — older than 2 days, please check' : ''}` : 'not set up'}</strong></p>
    <p class="muted">A backup contains patient and money data. Keep it private; never email it.</p>
    <div class="row-gap"><button class="btn primary" id="bk">Download backup now</button><span id="bm" class="muted"></span></div></div>`;
  $('#bk', c).onclick = async () => {
    const m = $('#bm', c); m.className = 'muted'; m.textContent = 'Reading data…'; $('#bk', c).disabled = true;
    try {
      const out = { app: 'clinic-pos', format: 1, createdAt: new Date().toISOString(), project: firebaseConfig.projectId, collections: {} };
      for (const n of PLAIN) out.collections[n] = await dump(n);
      out.collections.users = [...(await dump('users', where('role', '==', 'admin'))), ...(await dump('users', where('role', '==', 'receptionist')))];
      out.collections.auditLogs = [...(await dump('auditLogs', where('role', '==', 'admin'))), ...(await dump('auditLogs', where('role', '==', 'receptionist')))];
      const counts = {};
      Object.entries(out.collections).forEach(([k, v]) => (counts[k] = v.length));
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([JSON.stringify(out)], { type: 'application/json' }));
      a.download = `clinic-pos-backup-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a); a.click(); a.remove();
      const batch = writeBatch(db);
      batch.set(doc(db, 'meta', 'backupStatus'), { manualAt: serverTimestamp(), manualBy: ctx.uid, manualCounts: counts }, { merge: true });
      batch.set(doc(collection(db, 'auditLogs')), auditData(ctx.uid, 'admin', 'backup.manual', 'system', 'backup', { counts }));
      await batch.commit();
      backupPage(c, ctx);
    } catch { m.className = 'error'; m.textContent = 'Backup failed. Nothing was saved; try again.'; $('#bk', c).disabled = false; }
  };
}
