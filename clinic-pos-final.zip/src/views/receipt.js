// Receipt printing. Paper size and layout come from the hospital's print settings
// (thermal 58/80 mm, A5, A4 or any width in mm). Printing never creates a transaction.
import { esc, printHtml, fmtTime } from '../util.js';
import { money } from '../data.js';
import { billRows } from '../calc.js';

export function billStatus(b) {
  if (b.status === 'cancelled') return 'CANCELLED';
  if (b.complimentary) return 'COMPLIMENTARY';
  if (b.outstanding <= 0.004) return 'PAID';
  if ((b.received || 0) <= 0.004) return 'UNPAID';
  return 'PARTIALLY PAID';
}
export const statusClass = (b) => ({ PAID: 'paid', 'PARTIALLY PAID': 'part', UNPAID: 'unpaid', CANCELLED: 'off', COMPLIMENTARY: 'part' }[billStatus(b)]);

function page(print) {
  const w = String(print?.width || '80');
  const fs = Number(print?.fontSize) || 12;
  if (w === 'A4') return { css: '@page{size:A4;margin:12mm}', body: '186mm', font: Math.max(fs, 13) };
  if (w === 'A5') return { css: '@page{size:A5;margin:8mm}', body: '132mm', font: Math.max(fs, 12) };
  const mm = Math.min(210, Math.max(40, Number(w) || 80));
  return { css: `@page{size:${mm}mm auto;margin:2mm}`, body: `${mm - 6}mm`, font: mm <= 58 ? Math.min(fs, 10) : fs };
}
const shell = (cfg, title, inner) => {
  const p = page(cfg.branding.print);
  const b = cfg.branding;
  return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(title)}</title>
    <style>${p.css}body{font:${p.font}px monospace;width:${p.body};margin:0;color:#000}h1{font-size:1.25em;text-align:center;margin:0}
    p{margin:2px 0;text-align:center}table{width:100%;border-collapse:collapse;margin-top:4px}td{padding:1px 0;vertical-align:top}
    .r{text-align:right;white-space:nowrap;padding-left:6px}.b td{font-weight:bold}hr{border:0;border-top:1px dashed #000;margin:5px 0}
    img.logo{display:block;margin:0 auto 4px;max-width:40%;max-height:60px}</style></head><body>
    ${b.logo ? `<img class="logo" src="${esc(b.logo)}" alt="">` : ''}<h1>${esc(b.heading)}</h1>
    <p>${esc(b.address)}</p><p>${esc([b.phone, b.email].filter(Boolean).join(' · '))}</p><hr>${inner}<hr>
    ${b.receiptNote ? `<p>${esc(b.receiptNote)}</p>` : ''}<p>${esc(b.footer || 'Thank you. Get well soon.')}</p></body></html>`;
};
const row = (a, v, bold) => `<tr${bold ? ' class="b"' : ''}><td>${esc(a)}</td><td class="r">${esc(v)}</td></tr>`;

export function billReceiptHtml(cfg, b) {
  const compact = cfg.branding.print?.template === 'compact';
  const lines = billRows(b).map((r, i) => `<tr><td>${i + 1}. ${r.kind === 'doctor' ? 'Consultation: ' : ''}${esc(r.name)}${r.qty > 1 ? ` x${r.qty} @ ${money(r.rate)}` : ''}${r.discount > 0 ? ` (-${money(r.discount)})` : ''}</td><td class="r">${money(r.lineTotal)}</td></tr>`);
  return shell(cfg, b.receiptNo, `
    <table>${row('Receipt no.', b.receiptNo, true)}${row('Date', fmtTime(b.createdAt) || new Date(b.clientAt || Date.now()).toLocaleString())}
    ${row('Patient', b.patientName)}${compact ? '' : row('Age / Gender', `${b.age} / ${b.gender}`)}${row('Doctor', b.doctorName || '-')}</table><hr>
    <table>${lines.join('')}</table><hr>
    <table>${row('Gross total', money(b.gross))}${row('Discount', money(b.discount || 0))}${b.compAmount > 0 ? row('Complimentary', money(b.compAmount)) : ''}
    ${row('Net total', money(b.net), true)}${row('Paid', money(b.tendered ?? b.received))}${(b.change || 0) > 0 ? row('Change', money(b.change)) : ''}
    ${row('Outstanding', money(b.outstanding), true)}${row('Payment method', b.paymentMethodName || '-')}${row('Status', billStatus(b), true)}
    ${row('Receptionist', b.receptionistName)}</table>${b.status === 'cancelled' ? '<p><strong>*** CANCELLED ***</strong></p>' : ''}`);
}
export function paymentReceiptHtml(cfg, p, bill, remaining) {
  return shell(cfg, p.paymentNo, `<p><strong>PAYMENT RECEIPT</strong></p>
    <table>${row('Receipt no.', p.paymentNo, true)}${row('Date', fmtTime(p.createdAt) || new Date().toLocaleString())}${row('Patient', p.patientName)}
    ${row('Original slip', bill.receiptNo)}${row('Method', p.methodName)}${row('Amount paid', money(p.amount), true)}${row('Balance left', money(remaining), true)}
    ${row('Received by', p.receptionistName)}</table>`);
}
// Printing problems must never affect the saved slip, so they are caught here.
export function printBill(cfg, b) { try { printHtml(billReceiptHtml(cfg, b)); return true; } catch { return false; } }
export function printPayment(cfg, p, bill, remaining) { try { printHtml(paymentReceiptHtml(cfg, p, bill, remaining)); return true; } catch { return false; } }
