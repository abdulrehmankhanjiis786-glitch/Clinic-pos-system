// System-level screens: status, hospital branding / printing, licence, installations, updates, configuration export / import, error log.
// No patient, till or financial data is read here (the security rules would refuse it).
import { collection, doc, getDoc, getDocs, limit, orderBy, query, writeBatch, serverTimestamp, Timestamp } from 'firebase/firestore';
import { auth, db, firebaseConfig, appCheckEnabled } from '../firebase.js';
import { auditData, writeAudit } from '../auth.js';
import { mountShell } from '../shell.js';
import { esc, $, fmtTime, modal, toast, printHtml } from '../util.js';
import { list } from '../data.js';
import { getConfig, invalidateConfig } from '../config.js';
import { billReceiptHtml } from './receipt.js';

/* global __APP_VERSION__, __BUILD_TIME__ */
const version = typeof __APP_VERSION__ !== 'undefined' ? __APP_VERSION__ : 'dev';
const buildTime = typeof __BUILD_TIME__ !== 'undefined' ? __BUILD_TIME__ : 'unknown';
const stamp = () => ({ updatedAt: serverTimestamp(), updatedBy: auth.currentUser.uid });
const hex = (n) => Array.from(crypto.getRandomValues(new Uint8Array(n)), (b) => b.toString(16).padStart(2, '0')).join('');
const sha = async (t) => Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(t))), (b) => b.toString(16).padStart(2, '0')).join('');
const download = (name, obj) => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(obj, null, 1)], { type: 'application/json' })); a.download = name; document.body.appendChild(a); a.click(); a.remove(); };

// Second step after the password: the security code configured by the owner of the system.
export async function devGate() {
  const ref = doc(db, 'settings', 'devAccess');
  let cur = null;
  try { const s = await getDoc(ref); cur = s.exists() ? s.data() : null; } catch { return false; }
  return new Promise((resolve) => {
    const first = !cur;
    const m = modal(`<h2>${first ? 'Create the security code' : 'Security code'}</h2><p class="muted">${first ? 'Choose a code of at least 8 characters. You will need it every time you sign in here.' : 'Enter your security code.'}</p>
      <label>Code<input id="c" type="password" autocomplete="off"></label><div id="e" class="error"></div>
      <div class="row-gap" style="justify-content:flex-end"><button class="btn" id="x">Cancel</button><button class="btn primary" id="o">Continue</button></div>`);
    $('#x', m.el).onclick = () => { m.close(); resolve(false); };
    $('#o', m.el).onclick = async () => {
      const code = $('#c', m.el).value;
      if (first) {
        if (code.length < 8) { $('#e', m.el).textContent = 'At least 8 characters.'; return; }
        const salt = hex(8);
        const b = writeBatch(db);
        b.set(ref, { salt, codeHash: await sha(salt + code), updatedAt: serverTimestamp() });
        try { await b.commit(); m.close(); resolve(true); } catch { $('#e', m.el).textContent = 'Could not save the code.'; }
      } else if ((await sha(cur.salt + code)) === cur.codeHash) { m.close(); resolve(true); } else { $('#e', m.el).textContent = 'Wrong code.'; }
    };
    $('#c', m.el).focus();
  });
}

export function renderDeveloper(root, name, role) {
  mountShell(root, {
    brand: 'System', roleLabel: 'System', name,
    nav: [{ id: 'status', label: 'System status' }, { id: 'brand', label: 'Hospital & printing' }, { id: 'license', label: 'Licence' }, { id: 'install', label: 'Installations' },
      { id: 'updates', label: 'Version & updates' }, { id: 'config', label: 'Configuration' }, { id: 'diag', label: 'Error diagnostics' }],
    pages: { status: (c) => status(c, role), brand, license, install, updates, config, diag },
  });
}

async function status(c, role) {
  const uid = auth.currentUser.uid;
  let dbOk = false, isolated = false, backup = null, lic = null, inst = null;
  try { dbOk = (await getDoc(doc(db, 'users', uid))).exists(); } catch { /* failed */ }
  // A hospital-data read must be refused for this account; permission-denied is the good result.
  try { await getDocs(query(collection(db, 'bills'), limit(1))); } catch (e) { isolated = e?.code === 'permission-denied'; }
  try { const s = await getDoc(doc(db, 'meta', 'backupStatus')); backup = s.exists() ? s.data() : null; } catch { /* unknown */ }
  try { const s = await getDoc(doc(db, 'settings', 'license')); lic = s.exists() ? s.data() : null; const i = await getDoc(doc(db, 'settings', 'installation')); inst = i.exists() ? i.data() : null; } catch { /* unknown */ }
  const t = await auth.currentUser.getIdTokenResult();
  const rows = [['Version', version], ['Build time', buildTime], ['Address', location.hostname], ['Firebase project', firebaseConfig.projectId || 'not set'], ['Signed in as', role],
    ['Session token expires', new Date(t.expirationTime).toLocaleString()], ['Idle sign-out', '15 minutes'], ['Database connection', dbOk ? 'Connected' : 'Failed'],
    ['Hospital data blocked for this account', isolated ? 'Yes (rules working)' : 'NO - check the security rules'], ['App Check', appCheckEnabled ? 'Enabled in app' : 'Not enabled yet'],
    ['Hospital ID', inst?.hospitalId || 'not set'], ['Installation ID', inst?.installationId || 'not set'],
    ['Licence', lic ? `${lic.status || ''} until ${lic.expiresAt?.toDate ? lic.expiresAt.toDate().toLocaleDateString() : '-'} (${lic.mode})` : 'not set'],
    ['Last manual backup', backup?.manualAt ? fmtTime(backup.manualAt) : 'never'], ['Last automatic backup', backup?.autoAt ? `${fmtTime(backup.autoAt)} (${backup.autoStatus || ''})` : 'not set up']];
  c.innerHTML = `<div class="card"><h2>System status</h2><table><tbody>${rows.map(([k, v]) => `<tr><td>${esc(k)}</td><td>${esc(v)}</td></tr>`).join('')}</tbody></table></div>`;
}

async function brand(c) {
  const cfg = await getConfig('developer', true);
  const b = cfg.branding;
  c.innerHTML = `<div class="card"><h2>Hospital information and receipt</h2><form id="f" class="grid2">
    <label>Hospital heading / name<input name="heading" required maxlength="100" value="${esc(b.heading)}"></label><label>Address<input name="address" maxlength="200" value="${esc(b.address)}"></label>
    <label>Phone<input name="phone" maxlength="40" value="${esc(b.phone)}"></label><label>Email<input name="email" maxlength="80" value="${esc(b.email)}"></label>
    <label>Footer text<input name="footer" maxlength="200" value="${esc(b.footer)}"></label><label>Receipt note<input name="receiptNote" maxlength="200" value="${esc(b.receiptNote)}"></label>
    <label>Logo (PNG or JPG, small)<input name="logo" type="file" accept="image/png,image/jpeg"></label><div><div class="muted">Current logo</div>${b.logo ? `<img src="${esc(b.logo)}" alt="" style="max-height:50px">` : '<span class="muted">none</span>'} ${b.logo ? '<label class="chk"><input type="checkbox" name="rmlogo"> remove</label>' : ''}</div>
    <label>Paper<select name="width">${['58', '80', 'A5', 'A4'].map((w) => `<option value="${w}" ${String(b.print.width) === w ? 'selected' : ''}>${w === '58' || w === '80' ? `Thermal ${w} mm` : w}</option>`).join('')}<option value="custom" ${['58', '80', 'A5', 'A4'].includes(String(b.print.width)) ? '' : 'selected'}>Custom width (mm)</option></select></label>
    <label>Custom width in mm<input name="custom" inputmode="numeric" value="${['58', '80', 'A5', 'A4'].includes(String(b.print.width)) ? '' : esc(b.print.width)}"></label>
    <label>Layout<select name="template"><option value="standard" ${b.print.template === 'standard' ? 'selected' : ''}>Standard</option><option value="compact" ${b.print.template === 'compact' ? 'selected' : ''}>Compact</option></select></label>
    <label>Font size<input name="fontSize" inputmode="numeric" value="${esc(b.print.fontSize)}"></label>
    <div class="row-end"><span id="m" class="muted"></span><button class="btn" type="button" id="test">Test print</button><button class="btn primary">Save</button></div></form></div>`;
  const f = $('#f', c);
  const read = async () => {
    let logo = b.logo;
    if (f.rmlogo?.checked) logo = '';
    const file = f.logo.files[0];
    if (file) {
      if (file.size > 100000) throw new Error('The logo must be smaller than 100 KB.');
      logo = await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(file); });
    }
    const width = f.width.value === 'custom' ? String(Math.round(Number(f.custom.value) || 80)) : f.width.value;
    return { heading: f.heading.value.trim(), address: f.address.value.trim(), phone: f.phone.value.trim(), email: f.email.value.trim(), footer: f.footer.value.trim(),
      receiptNote: f.receiptNote.value.trim(), logo, print: { width, template: f.template.value, fontSize: Math.min(20, Math.max(8, Number(f.fontSize.value) || 12)) } };
  };
  $('#test', c).onclick = async () => {
    try {
      const nb = await read();
      printHtml(billReceiptHtml({ branding: nb }, { receiptNo: 'TEST-000001', patientName: 'Test Patient', age: 30, gender: 'Male', doctorName: 'Dr. Test', doctorId: 'x', rows: [{ name: 'Consultation', rate: 500, qty: 1, discount: 0, lineTotal: 500 }, { name: 'Dressing', rate: 150, qty: 2, discount: 0, lineTotal: 300 }],
        gross: 800, discount: 0, net: 800, received: 800, tendered: 800, outstanding: 0, paymentMethodName: 'Cash', receptionistName: 'Test', status: 'posted', clientAt: Date.now() }));
    } catch (e) { toast(e.message, true); }
  };
  f.onsubmit = async (e) => {
    e.preventDefault();
    try {
      const data = await read();
      const batch = writeBatch(db);
      batch.set(doc(db, 'settings', 'branding'), { ...data, ...stamp() });
      batch.set(doc(collection(db, 'auditLogs')), auditData(auth.currentUser.uid, 'developer', 'branding.update', 'settings', 'branding'));
      await batch.commit();
      invalidateConfig();
      brand(c);
      toast('Saved.');
    } catch (ex) { $('#m', c).className = 'error'; $('#m', c).textContent = ex.message || 'Could not save.'; }
  };
}

async function license(c) {
  let cur = null;
  try { const s = await getDoc(doc(db, 'settings', 'license')); cur = s.exists() ? s.data() : null; } catch { /* none */ }
  const exp = cur?.expiresAt?.toDate ? cur.expiresAt.toDate() : null;
  c.innerHTML = `<div class="card"><h2>Licence</h2><p>Current expiry: <strong>${exp ? exp.toLocaleDateString() : 'not set'}</strong> · When it expires: <strong>${cur?.mode === 'block' ? 'new slips and payments are blocked' : 'a warning is shown'}</strong></p>
    <form id="f" class="grid2"><label>Expiry date<input type="date" name="date" value="${exp ? exp.toISOString().slice(0, 10) : ''}" required></label>
    <label>When expired<select name="mode"><option value="warn" ${cur?.mode !== 'block' ? 'selected' : ''}>Show a warning only</option><option value="block" ${cur?.mode === 'block' ? 'selected' : ''}>Block new slips and payments</option></select></label>
    <div class="row-end"><span id="m" class="muted"></span><button class="btn" type="button" id="r">Renew +1 year</button><button class="btn" type="button" id="x">Extend +30 days</button><button class="btn primary">Save</button></div></form></div>`;
  const f = $('#f', c);
  const save = async (date, mode) => {
    const batch = writeBatch(db);
    batch.set(doc(db, 'settings', 'license'), { status: date.getTime() < Date.now() ? 'expired' : 'active', expiresAt: Timestamp.fromDate(date), mode, ...stamp() });
    batch.set(doc(collection(db, 'auditLogs')), auditData(auth.currentUser.uid, 'developer', 'license.update', 'settings', 'license', { mode }));
    try { await batch.commit(); invalidateConfig(); license(c); toast('Saved.'); } catch { $('#m', c).className = 'error'; $('#m', c).textContent = 'Could not save.'; }
  };
  const base = () => { const d = exp && exp.getTime() > Date.now() ? new Date(exp) : new Date(); return d; };
  f.onsubmit = (e) => { e.preventDefault(); const d = new Date(`${f.date.value}T23:59:59`); save(d, f.mode.value); };
  $('#r', c).onclick = () => { const d = base(); d.setFullYear(d.getFullYear() + 1); save(d, f.mode.value); };
  $('#x', c).onclick = () => { const d = base(); d.setDate(d.getDate() + 30); save(d, f.mode.value); };
}

async function install(c) {
  let inst = null, all = [];
  try { const s = await getDoc(doc(db, 'settings', 'installation')); inst = s.exists() ? s.data() : null; all = await list('installations'); } catch { /* none */ }
  c.innerHTML = `<div class="card"><h2>This installation</h2><p>Hospital ID: <strong>${esc(inst?.hospitalId || 'not set')}</strong> · Installation ID: <strong>${esc(inst?.installationId || 'not set')}</strong></p>
    ${inst ? '' : '<button class="btn primary" id="mk">Create IDs for this installation</button>'}</div>
    <div class="card"><h2>New hospital / installation</h2><p class="muted">Every hospital has its own separate database. In this free setup that means its own Firebase project: create the project, deploy this application to it, then import the package created here.</p>
    <form id="f" class="row-gap"><input name="n" class="inline" style="max-width:300px" placeholder="Hospital name" required minlength="2" maxlength="100"><button class="btn primary">Create installation</button></form>
    ${all.length ? `<table style="margin-top:10px"><thead><tr><th>Hospital</th><th>Hospital ID</th><th>Installation ID</th><th></th></tr></thead><tbody>${all.map((x) => `<tr><td>${esc(x.name)}</td><td>${esc(x.hospitalId)}</td><td>${esc(x.installationId)}</td><td><button class="btn small" data-p="${esc(x.id)}">Download package</button></td></tr>`).join('')}</tbody></table>` : ''}</div>`;
  const mk = $('#mk', c);
  if (mk) mk.onclick = async () => { const b = writeBatch(db); b.set(doc(db, 'settings', 'installation'), { hospitalId: `H-${hex(4).toUpperCase()}`, installationId: `I-${hex(6).toUpperCase()}`, name: 'This installation', ...stamp() }); try { await b.commit(); install(c); } catch { toast('Could not save.', true); } };
  $('#f', c).onsubmit = async (e) => {
    e.preventDefault();
    const id = hex(6);
    const b = writeBatch(db);
    b.set(doc(db, 'installations', id), { name: e.target.n.value.trim(), hospitalId: `H-${hex(4).toUpperCase()}`, installationId: `I-${hex(6).toUpperCase()}`, createdAt: serverTimestamp(), createdBy: auth.currentUser.uid });
    try { await b.commit(); install(c); } catch { toast('Could not create.', true); }
  };
  c.querySelectorAll('[data-p]').forEach((bt) => (bt.onclick = async () => {
    const x = all.find((y) => y.id === bt.dataset.p);
    const cfg = await getConfig('developer', true);
    download(`installation-${x.installationId}.json`, { app: 'clinic-pos', type: 'installation', hospitalId: x.hospitalId, installationId: x.installationId, name: x.name, branding: cfg.rawBranding || {} });
  }));
}

async function updates(c) {
  c.innerHTML = '<div class="card"><h2>Version and updates</h2><p>Running: <strong id="cur"></strong></p><p id="lat" class="muted">Checking…</p><div class="row-gap"><button class="btn" id="chk">Check now</button><button class="btn primary" id="app" style="display:none">Apply update</button></div></div>';
  $('#cur', c).textContent = `${version} (built ${buildTime})`;
  const check = async () => {
    try {
      const v = await (await fetch(`/version.json?t=${Date.now()}`, { cache: 'no-store' })).json();
      const newer = v.build !== buildTime;
      $('#lat', c).textContent = newer ? `An update is available: ${v.version} (built ${v.build}).` : 'You are running the latest version.';
      $('#app', c).style.display = newer ? '' : 'none';
    } catch { $('#lat', c).textContent = 'Could not check for updates.'; }
  };
  $('#chk', c).onclick = check;
  $('#app', c).onclick = () => { writeAudit(auth.currentUser.uid, 'developer', 'update.apply', 'system', 'app').finally(() => location.reload()); };
  check();
}

// Configuration only (never patient or money data).
const CONFIG_COLLECTIONS = ['doctors', 'services', 'paymentMethods'];
const CONFIG_SETTINGS = ['general', 'categories', 'shortcuts', 'branding', 'priceList'];
async function config(c) {
  c.innerHTML = `<div class="card"><h2>Export configuration</h2><p class="muted">Doctors, services, payment methods, settings and branding. No patient or financial data.</p><button class="btn primary" id="ex">Download configuration</button></div>
    <div class="card"><h2>Import configuration</h2><p class="muted">New items are added. Items that already exist are left as they are.</p><input type="file" id="fi" accept="application/json"><div id="im" class="muted" style="margin-top:8px"></div></div>`;
  const enc = (v) => { if (v instanceof Timestamp) return { __ts: v.toDate().toISOString() }; if (Array.isArray(v)) return v.map(enc); if (v && typeof v === 'object') return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, enc(x)])); return v; };
  $('#ex', c).onclick = async () => {
    try {
      const out = { app: 'clinic-pos', type: 'configuration', createdAt: new Date().toISOString(), collections: {}, settings: {} };
      for (const n of CONFIG_COLLECTIONS) out.collections[n] = (await list(n)).map(({ id, ...d }) => ({ id, data: enc(d) }));
      for (const s of CONFIG_SETTINGS) { const d = await getDoc(doc(db, 'settings', s)); if (d.exists()) out.settings[s] = enc(d.data()); }
      download('clinic-configuration.json', out);
      await writeAudit(auth.currentUser.uid, 'developer', 'config.export', 'system', 'config');
    } catch { toast('Could not export.', true); }
  };
  $('#fi', c).onchange = async (e) => {
    const im = $('#im', c);
    try {
      const data = JSON.parse(await e.target.files[0].text());
      if (data.app !== 'clinic-pos' || data.type !== 'configuration') throw new Error('This is not a configuration file.');
      const uid = auth.currentUser.uid;
      const have = { doctors: new Set((await list('doctors')).map((x) => x.id)), services: new Set((await list('services')).map((x) => x.id)), paymentMethods: new Set((await list('paymentMethods')).map((x) => x.id)) };
      const pl = { doctors: {}, services: {} };
      let n = 0;
      const batch = writeBatch(db);
      for (const coll of CONFIG_COLLECTIONS) {
        for (const it of data.collections?.[coll] || []) {
          if (have[coll].has(it.id)) continue;
          const d = { ...it.data }; delete d.createdAt; delete d.updatedAt; delete d.createdBy; delete d.updatedBy;
          batch.set(doc(db, coll, it.id), { ...d, createdAt: serverTimestamp(), createdBy: uid });
          const pe = data.settings?.priceList?.[coll]?.[it.id]; if (pe) pl[coll][it.id] = pe;
          n++;
        }
      }
      if (data.settings?.priceList && (Object.keys(pl.doctors).length || Object.keys(pl.services).length)) batch.set(doc(db, 'settings', 'priceList'), { ...pl, ...stamp() }, { merge: true });
      for (const s of ['general', 'categories', 'shortcuts']) if (data.settings?.[s]) { const d = { ...data.settings[s] }; delete d.updatedAt; delete d.updatedBy; batch.set(doc(db, 'settings', s), { ...d, ...stamp() }); }
      batch.set(doc(collection(db, 'auditLogs')), auditData(uid, 'developer', 'config.import', 'system', 'config', { added: n }));
      await batch.commit();
      invalidateConfig();
      im.className = 'muted'; im.textContent = `Imported. ${n} new item(s) added.`;
    } catch (ex) { im.className = 'error'; im.textContent = ex.message || 'Import failed.'; }
  };
}

async function diag(c) {
  c.innerHTML = '<p class="muted">Loading…</p>';
  writeAudit(auth.currentUser.uid, 'developer', 'diagnostics.view', 'system', 'errorLogs').catch(() => {});
  let rows;
  try { rows = await list('errorLogs', orderBy('createdAt', 'desc'), limit(50)); } catch { c.innerHTML = '<div class="card error">Could not load the error log.</div>'; return; }
  c.innerHTML = `<div class="card"><div class="row-gap"><h2 style="margin:0">Latest errors</h2><span class="grow"></span>${rows.length ? '<button class="btn small" id="clr">Clear log</button>' : ''}</div>
    ${rows.length ? `<table><thead><tr><th>Time</th><th>Role</th><th>Message</th><th>Source</th></tr></thead><tbody>${rows.map((r) => `<tr><td>${esc(fmtTime(r.createdAt))}</td><td>${esc(r.role)}</td><td>${esc(r.message)}</td><td>${esc(r.source)}</td></tr>`).join('')}</tbody></table>` : '<p class="muted">No errors recorded.</p>'}</div>`;
  const clr = $('#clr', c);
  if (clr) clr.onclick = async () => {
    const batch = writeBatch(db);
    rows.forEach((r) => batch.delete(doc(db, 'errorLogs', r.id)));
    try { await batch.commit(); diag(c); } catch { toast('Could not clear.', true); }
  };
}
