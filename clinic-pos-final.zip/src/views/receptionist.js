import { doc, writeBatch, serverTimestamp, where } from 'firebase/firestore';
import { db } from '../firebase.js';
import { mountPos } from '../shell.js';
import { getConfig, refreshIfChanged, ACTIONS } from '../config.js';
import { getOpenShift, shiftTotals, money, licenseInfo, list } from '../data.js';
import { changeOwnPassword, logout } from '../auth.js';
import { esc, $, modal, ask, toast, setBaseShortcuts } from '../util.js';
import { summary, onSyncChange, dismiss, reconcile, isOnline } from '../offline.js';
import { newBillPage, heldPage, heldCount } from './bill.js';
import { slipsPage } from './slips.js';
import { balancesPage } from './balances.js';
import { cashPage } from './cash.js';
import { currentShiftPage } from './shift.js';

export async function renderReceptionist(root, name, uid, profile) {
  const ctx = { uid, name, role: 'receptionist', profile, resume: null, bill: null, go: () => {} };
  ctx.cfgObj = await getConfig('receptionist');
  ctx.shiftObj = await getOpenShift(uid).catch(() => null);
  ctx.cfg = () => ctx.cfgObj;
  ctx.shift = () => ctx.shiftObj;
  const label = () => (ctx.shiftObj ? `Shift: ${ctx.shiftObj.shiftName} (open)` : 'Shift: not opened');
  ctx.setShift = (s) => { ctx.shiftObj = s; pos?.setShift(label()); };
  ctx.refreshShift = async () => { try { ctx.shiftObj = await getOpenShift(uid); } catch { /* keep */ } pos?.setShift(label()); };
  ctx.licenseBlocked = () => licenseInfo(ctx.cfgObj).blocked;
  let pos;

  const onBill = () => pos.current() === 'bill';
  const needBill = (fn) => () => { if (onBill() && ctx.bill) fn(); else { pos.go('bill'); setTimeout(() => ctx.bill && fn(), 350); } };
  const actions = {
    newSlip: needBill(() => ctx.bill.newSlip()), doctor: () => onBill() && ctx.bill.focus('doctor'), service: () => onBill() && ctx.bill.focus('service'),
    discount: () => onBill() && ctx.bill.focus('discount'), paid: () => onBill() && ctx.bill.focus('paid'),
    post: needBill(() => ctx.bill.post()), print: needBill(() => ctx.bill.print()), hold: needBill(() => ctx.bill.hold()), deleteRow: () => onBill() && ctx.bill.deleteRow(),
    held: () => pos.go('held'), slips: () => pos.go('slips'), outstanding: () => pos.go('outstanding'), search: () => pos.go('search'),
    help: () => helpDialog(), cashIn: () => pos.go('cash'), shift: () => pos.go('shift'),
  };
  const applyShortcuts = () => {
    const map = {};
    ctx.cfgObj.shortcuts.forEach((s) => { if (actions[s.action]) map[s.key] = actions[s.action]; });
    setBaseShortcuts(map);
  };
  function helpDialog() {
    const m = modal(`<h2>Shortcut Help</h2><table><tbody>${ctx.cfgObj.shortcuts.map((s) => `<tr><td><span class="kbd">${esc(s.key)}</span></td><td>${esc(ACTIONS[s.action] || s.action)}</td></tr>`).join('')}</tbody></table>
      <p class="hint">Esc closes a popup.</p><div class="row-gap" style="justify-content:flex-end"><button class="btn primary" id="ok">Close</button></div>`);
    $('#ok', m.el).onclick = m.close;
  }

  const rail = [
    { id: 'home', icon: 'home', label: 'Dashboard' }, { id: 'search', icon: 'search', label: 'Search' }, { sep: true },
    { id: 'bill', icon: 'plus', label: 'New Slip' }, { id: 'hold', icon: 'pause', label: 'Hold', act: actions.hold }, { id: 'held', icon: 'held', label: 'Held' },
    { id: 'deleteRow', icon: 'trash', label: 'Delete Row', act: actions.deleteRow }, { id: 'print', icon: 'printer', label: 'Print', act: actions.print },
    { id: 'post', icon: 'check', label: 'Post', act: actions.post }, { sep: true },
    { id: 'slips', icon: 'slips', label: "Today's Slips" }, { id: 'outstanding', icon: 'wallet', label: 'Outstanding' }, { id: 'cash', icon: 'cash', label: 'Cash In/Out' },
    { id: 'shift', icon: 'clock', label: 'Shift' }, { id: 'help', icon: 'help', label: 'Help', act: helpDialog },
  ];
  const tile = (n, l, page) => `<button class="tile" data-go="${page}"><span class="num">${n}</span>${l}</button>`;
  const pages = {
    home: async (c) => {
      c.innerHTML = `<div class="tiles">${tile('+', 'New Slip', 'bill')}${tile('', "Today's Slips", 'slips')}${tile('', 'Review / Reprint', 'search')}${tile('', 'Outstanding Balance', 'outstanding')}
        ${tile('', 'Cash In', 'cash')}${tile('', 'Cash Out', 'cash')}${tile('', 'Cancelled Slips', 'cancelled')}${tile('', 'Complimentary', 'comp')}${tile('', 'Held Invoices', 'held')}${tile('', 'Shift Status', 'shift')}</div>
        <div class="card" style="margin-top:14px"><h2>Till summary</h2><div id="till" class="muted">Loading…</div></div>`;
      c.querySelectorAll('[data-go]').forEach((b) => (b.onclick = () => pos.go(b.dataset.go)));
      const till = $('#till', c);
      if (!ctx.shiftObj) { till.textContent = 'Your shift is not open. Open it from Shift.'; return; }
      if (!isOnline()) { till.textContent = 'The till summary needs the internet.'; return; }
      try {
        const t = await shiftTotals(ctx.shiftObj);
        till.className = '';
        till.innerHTML = `<table><tbody><tr><td>Opening cash</td><td class="right">${money(ctx.shiftObj.openingCash)}</td></tr><tr><td>Cash received (slips + balances)</td><td class="right">${money(t.cashSales + t.cashOutstanding)}</td></tr>
          <tr><td>Cash In</td><td class="right">${money(t.cashIn)}</td></tr><tr><td>Cash Out</td><td class="right">${money(t.cashOut)}</td></tr><tr><td>Cash refunds</td><td class="right">${money(t.cashRefunds)}</td></tr>
          <tr style="font-weight:700"><td>Total cash</td><td class="right">${money(t.expected)}</td></tr></tbody></table>`;
      } catch { till.textContent = 'Could not load the till summary.'; }
    },
    bill: async (c) => { await refreshIfChanged('receptionist').then((cfg) => { if (cfg) ctx.cfgObj = cfg; applyShortcuts(); }).catch(() => {}); newBillPage(c, ctx); },
    search: (c) => slipsPage(c, ctx, 'search'), slips: (c) => slipsPage(c, ctx, 'today'), cancelled: (c) => slipsPage(c, ctx, 'cancelled'), comp: (c) => slipsPage(c, ctx, 'comp'),
    held: (c) => heldPage(c, ctx), outstanding: (c) => balancesPage(c, ctx), cash: (c) => cashPage(c, ctx), shift: (c) => currentShiftPage(c, ctx),
  };
  pos = mountPos(root, { name, rail, pages, start: 'bill', shiftLabel: label() });
  ctx.go = pos.go;
  applyShortcuts();
  reconcile();

  // The Admin sees who is online: a small "still here" signal once a minute.
  const beat = () => { if (isOnline()) { const b = writeBatch(db); b.set(doc(db, 'presence', uid), { name, lastSeen: serverTimestamp() }); b.commit().catch(() => {}); } };
  beat();
  const hb = setInterval(beat, 60000);

  // Entries that could not be saved stay visible until dismissed.
  onSyncChange((s) => {
    if (s.failed.length && !document.querySelector('.modal-bg')) {
      const m = modal(`<h2>Some entries were not saved</h2><p>These could not be saved. Please create them again.</p>
        <table><tbody>${s.failed.map((f) => `<tr><td>${esc(f.label)}</td><td><button class="btn small" data-d="${esc(f.id)}">Dismiss</button></td></tr>`).join('')}</tbody></table>`);
      m.el.querySelectorAll('[data-d]').forEach((b) => (b.onclick = () => { dismiss(b.dataset.d); b.closest('tr').remove(); if (!m.el.querySelector('[data-d]')) m.close(); }));
    }
  });

  pos.onChangePassword = () => {
    const m = modal(`<h2>Change password</h2><label>Current password<input id="o" type="password" autocomplete="current-password"></label>
      <label>New password (10+ characters)<input id="n" type="password" autocomplete="new-password"></label><label>Repeat new password<input id="r" type="password" autocomplete="new-password"></label>
      <div id="e" class="error"></div><div class="row-gap" style="justify-content:flex-end"><button class="btn" id="c">Cancel</button><button class="btn primary" id="s">Change</button></div>`);
    $('#c', m.el).onclick = m.close;
    $('#s', m.el).onclick = async () => {
      const n = $('#n', m.el).value;
      if (n.length < 10) { $('#e', m.el).textContent = 'The new password needs at least 10 characters.'; return; }
      if (n !== $('#r', m.el).value) { $('#e', m.el).textContent = 'The two new passwords are different.'; return; }
      try { await changeOwnPassword($('#o', m.el).value, n); m.close(); toast('Password changed.'); } catch { $('#e', m.el).textContent = 'The current password is not correct.'; }
    };
  };
  // Logging out: held invoices cannot carry into the next shift.
  pos.beforeLogout = async () => {
    const held = await heldCount(uid);
    if (held > 0) {
      const m = modal(`<h2>Held invoices</h2><p>You have ${held} held invoice(s). Continue and post them, or remove them, before you log out. Held invoices cannot carry into the next shift.</p>
        <div class="row-gap" style="justify-content:flex-end"><button class="btn" id="c">Stay</button><button class="btn" id="d">Remove all</button><button class="btn primary" id="v">View held invoices</button></div>`);
      $('#c', m.el).onclick = m.close;
      $('#v', m.el).onclick = () => { m.close(); pos.go('held'); };
      $('#d', m.el).onclick = async () => {
        if (!(await ask('Remove all held invoices?', 'They will be deleted.', 'Remove all'))) return;
        const hs = await list('heldBills', where('receptionistUid', '==', uid));
        const b = writeBatch(db); hs.forEach((h) => b.delete(doc(db, 'heldBills', h.id)));
        try { await b.commit(); m.close(); toast('Held invoices removed. You can log out now.'); } catch { toast('Could not remove them.', true); }
      };
      return;
    }
    if (summary().pending > 0 && !(await ask('Waiting to sync', 'Some entries are still waiting for the internet. They stay safe on this computer and will sync when you sign in again. Log out now?', 'Log out'))) return;
    clearInterval(hb);
    logout();
  };
  return pos;
}
